% LIBRARY for mitral valve toolbox
%
% This toolbox uses functions from GIBBON Toolbox (https://www.gibboncode.org/) by Kevin Mattheus Moerman
%
% Files
%   AL_parameterize_avg        - parameterize AL surface area (average)
%   AL_parameterize_PS         - parameterize AL surface area (patient)
%   AL_surf                    - sanity check for AL surface area
%   AL_surf2                   - sanity check for AL surface area
%   annular_param1             - parameterize AP diameter and CW
%   annular_param2             - parameterize AH
%   avg_dim                    - obtain average model dimensions
%   B_paracom_locate           - locate new paracommissural boundary
%   chordae_input_3D_3b        - create chordae distributions (3D PM)
%   chordae_input_split        - create chordae distributions (single tip)
%   create_FE                  - create free edge
%   define_beams               - define chordae beams for simulations
%   define_beams_3D_3b         - define chordae beams for simulations
%   define_concavity           - define annular ring concavity
%   define_PM                  - define PM tip coordinates
%   define_PM_displacement1    - displace PM
%   define_PM_displacement3D   - displace PM
%   define_strut2              - find insertion nodes for strut (single tip
%   define_strut2_3D           - find insertion nodes for strut (3D PM)
%   define_transition_el       - define transition elements for simulations
%   fit_AL_fe2                 - fit AL free edge
%   fit_PA1_fe                 - fit PA1 free edge
%   fit_PA1_fe2                - fit PA1 free edge
%   fit_PA2_fe                 - fit PA2 free edge
%   fit_PA2_fe2                - fit PA2 free edge
%   GUI_import                 - GUI to import dimensional data
%   GUI_interPM                - GUI to define inter-PM distance
%   GUI_LVdilation             - GUI to define PM displacements
%   GUI_output                 - GUI to define model outputs
%   GUI_output_mesh            - GUI to define mesh output
%   GUI_PMpos                  - GUI to define type of PM displacement
%   interparc                  - interpolate points along a curve
%   leaflet_define_boundaries0 - define needed model boundaries
%   leaflet_define_boundaries1 - define needed model boundaries
%   leaflet_meshinput          - define leaflet parts for simulations
%   LSDYNA_input_create        - GENERATE LS-DYNA INPUT (single tip PM)
%   LSDYNA_input_create_PM3D   - GENERATE LS-DYNA INPUT (3D PM)
%   meshing_model1             - create model mesh
%   model_output               - export model
%   MV_generator               - main toolbox script
%   number_chordae             - get leaflet insertion nodes for chordae
%   number_chordae_3D          - get leaflet insertion nodes for chordae
%   number_chordae_3D_3b       - get leaflet insertion nodes for chordae
%   number_chordae_3D_4b       - get leaflet insertion nodes for chordae
%   other_input1               - create boundary conditions
%   other_input2               - create boundary conditions
%   PL_parameterize_avg        - parameterize PL surface area (average)
%   PL_parameterize_PS         - parameterize PL surface area (patient)
%   PL_surf                    - sanity check for PL surface area
