function [PL_endpoint,annPA1_endpoint,paracom_endpoint,AL_endpoint,comm_endpoint] = leaflet_define_boundaries0(PL_length_w,ann_PA1_w,paracom_l_w,AL_length_w,ann_comm_w,ann_s)


% first, process again all point with x near 0
for i=1:length(ann_s)
       if abs(ann_s(i,1))<1e-1
          ann_s(i,1) = 0; 
       end
end

    
%%
AC_path = pathLength(ann_s);

% get vertex for each side (annulus)
a_post = [];
a_ant = [];

% use proportions from literature to obtain AAC and PAC
AC = 2*max(AC_path);
AAC_w = 2/5*AC;
AAC_w = 1/2*AAC_w;

i=1;
tol=1e-30;

while AC_path(i,:) < AAC_w
   a_ant=[a_ant; ann_s(i,:)];
i = i+1;
end

comm_pos = i-1;
ann_comm = ann_s(comm_pos,:);




for k=i:length(ann_s)
        a_post=[a_post; ann_s(k,:)];
end

% translate the model to have the commissural point at z coordinate = 0
z_comm = ann_comm(3);
ann_comm(3) = ann_comm(3) - z_comm;
a_ant(:,3) = a_ant(:,3) - z_comm; 
a_post(:,3) = a_post(:,3) - z_comm;
ann_s(:,3) = ann_s(:,3) - z_comm;



%% Trigones

% INVESTIGATE - Okamoto says that trigones should be located at 1/4 from
% normal mitral annulus...

% find left; right trigones based on distance of 28 mm (14mm on half model)

AC_totalpath = max(AC_path);
IT = 1/4*AC_totalpath;

IT_v = [];

i = 1;

% get vertex corresponding to IT distance
while i < length (AC_path)   
    if AC_path(i,1) < IT       
        IT_v = [IT_v; ann_s(i,:)];                        
    end    
    i=i+1;    
end

RT = IT_v(end,:);
LT = [-RT(1) RT(2) RT(3)];


%% get mid leaflet boundary starting annular coordinates

% find mid AAC point on quad mesh (greatest z coordinate)
% it will be the first on the list (x = 0)
i = 1;

mid_AL = ann_s(i,:);

i = i+1;

% find mid PAC point on quad mesh
% boundary will be the last piece on the list with x = 0

while ann_s(i,1) ~= 0
    i = i+1;              
end    

mid_PL = ann_s(i,:);



%%

AL_endpoint = [mid_AL(1) mid_AL(2) mid_AL(3)-AL_length_w];

comm_endpoint = [ann_comm(1) ann_comm(2) ann_comm(3)-ann_comm_w];

%%
%% wanted dimensions

PL_endpoint = [mid_PL(1) mid_PL(2) mid_PL(3)-PL_length_w];


% to find paracommissural location
a_post = [];

for k=comm_pos:length(ann_s)
        a_post=[a_post; ann_s(k,:)];
end

PAC = max(pathLength(a_post));

PA1_annl_w = 1/3*(2*PAC);


%PA1_annl_w = 0.2764*PAC;

PA2_annl_w = 1/3*(2*PAC); % we multiply by 2, because we have half PL
%PA2_annl_w = 1.618*PA1_annl_w;
%PA2_annl_w = 0.4472*PAC;

B_PA1 = 1/2*PA2_annl_w; % get back to half model

PA1_v = [];

for k=comm_pos:length(ann_s)
    
    PA1_v=[PA1_v; ann_s(k,:)];
    
    if max(pathLength(PA1_v)) > B_PA1
 
    break
    
    end
        
end

ann_PA1 = ann_s(k-1,:);


annPA1_endpoint = [ann_PA1(1) ann_PA1(2) ann_PA1(3)-ann_PA1_w];



PA1_v = [];

for k=comm_pos:length(ann_s)
    
    PA1_v=[PA1_v; ann_s(k,:)];
    
    if max(pathLength(PA1_v)) > PA1_annl_w
 
    break
    
    end
        
end

paracom = ann_s(k-1,:);


paracom_endpoint = [paracom(1) paracom(2) paracom(3)-paracom_l_w];


end

