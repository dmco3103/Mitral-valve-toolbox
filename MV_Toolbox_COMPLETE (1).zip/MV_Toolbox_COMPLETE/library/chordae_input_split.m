function [node_list,element_beam,ALPM_nodepos,PMPM_nodepos,transition_shell] = chordae_input_split(node_list,element_shell,V,fe_s,fe_comm1,fe_comm2,fe_comm1_pos,fe_comm2_pos,ALPM,PMPM,fe_el,point)

RT = point.RT;
LT = point.LT;


%% 
tol = 1e-30;

% split free edge nodes (positions) into AL and PL
fe_AL = [];
fe_PL = [];

for i=1:length(fe_el)
   
    if ismembertol(fe_el(i),fe_comm1_pos,tol)==0
        fe_AL = [fe_AL; fe_el(i)];
        
    else
        fe_AL = [fe_AL; fe_el(i)];
        break
    end
end




for k=i+1:length(fe_el)
      
    if ismembertol(V(fe_el(k),:),fe_comm2,tol)==0
   
        fe_PL = [fe_PL; fe_el(k)];   
   
    else
      %  fe_PL = [fe_PL; fe_el(k)];
        break
    end   
end


fe_AL1 = [];

for j = k:length(fe_el)
    fe_AL1 = [fe_AL1; fe_el(j)];
end

fe_AL = [fe_AL1;fe_AL];



%% Chordae definitions
[AL_insert,PL_insert,n_b] = number_chordae(V,fe_AL,fe_PL);


%% Create additional transition elements for chordae insertion (AL)
[transition_shell,node_list,insert2,insertion_nodes] = define_transition_el(V,element_shell,node_list,fe_AL,fe_PL,AL_insert,PL_insert);

%insertion_nodes = [AL_insert; PL_insert];
%insert2 = insertion_nodes;


%% Fing branching nodes
AL_midway1 = [];
PL_midway1 = [];
AL_branch = [];
PL_branch = [];


% for AL chordae
for i=n_b:n_b:length(AL_insert)
    
    node2 = V(AL_insert(i),:);
    node1 = V(AL_insert(i-2),:);
    
    AL_midway1 = [AL_midway1; (node2(:) + node1(:)).'/2];
end


for i=1:length(AL_midway1)
    
    node = AL_midway1(i,:); 
    
    if node(1) >= 0
    PM = ALPM;
    mid_d = PM(:).'*(1/2) + node(:).'*(1/2);
    
    AL_branch = [AL_branch; mid_d];  
    
    else
    PM = PMPM;
    mid_d = PM(:).'*(1/2) + node(:).'*(1/2);

    AL_branch = [AL_branch; mid_d];  
    
    end
        
end
    

% for PL chordae
for i=n_b:n_b:length(PL_insert)
    
    node2 = V(PL_insert(i),:);
    node1 = V(PL_insert(i-2),:);
    
    PL_midway1 = [PL_midway1; (node2(:) + node1(:)).'/2];
end


for i=1:length(PL_midway1)
    
    node = PL_midway1(i,:); 
    
    if node(1) >= 0
    PM = ALPM;
    mid_d = PM(:).'*(1/2) + node(:).'*(1/2);

    PL_branch = [PL_branch; mid_d];  
    
    else
    PM = PMPM;
    mid_d = PM(:).'*(1/2) + node(:).'*(1/2);

    PL_branch = [PL_branch; mid_d];  
    
    end
        
end



%% Define inputs for LS-DYNA

% add chordae branching nodes to node list
i = length(node_list);
i = i+1;
AL_branch_nodepos = [];
PL_branch_nodepos = [];
ALPM_nodepos = [];
PMPM_nodepos = [];

for j=1:length(AL_branch)
   node_list(i,:) = [i AL_branch(j,1) AL_branch(j,2) AL_branch(j,3)];
   AL_branch_nodepos = [AL_branch_nodepos; i];
   i = i+1;
end

for j=1:length(PL_branch)
   node_list(i,:) = [i PL_branch(j,1) PL_branch(j,2) PL_branch(j,3)];
   PL_branch_nodepos = [PL_branch_nodepos; i];
   i = i+1;
end


% add PM nodes to node list
   node_list(i,:) = [i ALPM(1) ALPM(2) ALPM(3)];
   ALPM_nodepos = [ALPM_nodepos; i];
   i = i+1;
   node_list(i,:) = [i PMPM(1) PMPM(2) PMPM(3)];
   PMPM_nodepos = [PMPM_nodepos; i];

   
   
%% Create beam element list   

[element_list,node_list] = define_beams(node_list,n_b,ALPM_nodepos,PMPM_nodepos,AL_branch_nodepos,PL_branch_nodepos,element_shell,insert2);
  
element_beam = element_list;


%% Create strut chordae

%[transition_shell,node_list,element_beam] = define_strut(V,element_beam,transition_shell,node_list,RT,LT,fe_comm1_pos,fe_comm2_pos,ALPM_nodepos,PMPM_nodepos);

[transition_shell,node_list,element_beam] = define_strut2(V,element_beam,transition_shell,node_list,RT,LT,fe_comm1_pos,fe_comm2_pos,ALPM_nodepos,PMPM_nodepos);

%[transition_shell,node_list,element_beam] = define_strut2(V,element_beam,node_list,RT,fe_comm1_pos,ALPM_nodepos,PMPM_nodepos);


%% PLOTS
%plot settings
fontSize=20;
%markerSize1=45;
%lineWidth1=4;
%faceAlpha=0.5;

hf1=cFigure;
title('Chordal points','FontSize',fontSize);
xlabel('X axis','FontSize',fontSize);ylabel('Y axis','FontSize',fontSize); zlabel('Z axis','FontSize',fontSize);

hold on;

%scatter3(ALPM_3D(:,1),ALPM_3D(:,2),ALPM_3D(:,3),'filled');
%scatter3(PMPM_3D(:,1),PMPM_3D(:,2),PMPM_3D(:,3),'filled');

%scatter3(ann_s(:,1),ann_s(:,2),ann_s(:,3));
scatter3(fe_s(:,1),fe_s(:,2),fe_s(:,3));


scatter3(ALPM(:,1),ALPM(:,2),ALPM(:,3),'g','filled');
scatter3(PMPM(:,1),PMPM(:,2),PMPM(:,3),'k','filled');


for i=1:length(AL_branch)
if i==1
    scatter3(AL_branch(i,1),AL_branch(i,2),AL_branch(i,3),'r','filled');
else
    h = scatter3(AL_branch(i,1),AL_branch(i,2),AL_branch(i,3),'r','filled');
    h.Annotation.LegendInformation.IconDisplayStyle = 'off';
end
end

for i=1:length(PL_branch)
if i==1
scatter3(PL_branch(i,1),PL_branch(i,2),PL_branch(i,3),'b','filled');
else
    h = scatter3(PL_branch(i,1),PL_branch(i,2),PL_branch(i,3),'b','filled');
    h.Annotation.LegendInformation.IconDisplayStyle = 'off';
end
end


for i=1:length(insertion_nodes)
    if i == 1
scatter3(V(insertion_nodes(i),1),V(insertion_nodes(i),2),V(insertion_nodes(i),3),'m','filled');
    else
    h = scatter3(V(insertion_nodes(i),1),V(insertion_nodes(i),2),V(insertion_nodes(i),3),'m','filled');
    h.Annotation.LegendInformation.IconDisplayStyle = 'off';
    end
end


lgd = legend;
lgd.FontSize = 20;
legend(...
    'Free edge',...
    'Anterolateral PM',...
    'Posteromedial PM',...
    'AL chordae branching',...
    'PL chordae branching',...
    'Free edge insertion nodes');


axis equal; view(3); axis tight;  grid on;  set(gca,'FontSize',fontSize);
camlight headlight;
drawnow;


end

