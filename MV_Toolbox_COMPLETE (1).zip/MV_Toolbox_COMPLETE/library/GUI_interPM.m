%% GUI for the MV toolbox
% - Input all dimensions needed to build the model

%clc; clear all; close all;

function [inter_PM_w] = GUI_interPM()

dlg_title = 'Inter-papillary muscle distance';

prompt = {'Inter-PM distance [mm]'};
num_lines = 1;
defaultans = {'17'};
answer2 = inputdlg(prompt,dlg_title,num_lines,defaultans);

    inter_PM_w = str2num(answer2{1,1});

end



