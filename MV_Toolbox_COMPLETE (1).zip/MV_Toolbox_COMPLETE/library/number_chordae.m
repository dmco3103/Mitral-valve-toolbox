function [AL_insert,PL_insert,n_b] = number_chordae(V,fe_AL,fe_PL)

%% get leaflet insertion nodes for chordae

fe_AL2 = [];

for i=1:length(fe_AL)
   if abs(V(fe_AL(i),1))>0.1
fe_AL2 = [fe_AL2; fe_AL(i)];
   end
end

fe_PL2 = [];

for i=1:length(fe_PL)
   if abs(V(fe_PL(i),1))>0.1
fe_PL2 = [fe_PL2; fe_PL(i)];
   end
end

fe_AL = fe_AL2;
fe_PL = fe_PL2;



n_start_PM = 12;

n_start_AL = 9;
%n_start_AL = 17;
n_start_PL = 15;
%n_start_PL = 24;

% how many branches from each chord?
n_b = 3;

total = n_b*n_start_PM*2;


% split free edge nodes (positions) into AL and PL
AL_insert = [];
PL_insert = [];


n_insert_AL = n_b*n_start_AL;
n_insert_PL = n_b*n_start_PL;

n_AL = floor(length(fe_AL)/n_insert_AL);
n_PL = ceil(length(fe_PL)/n_insert_PL);

AL_insert = [];
PL_insert = [];

for i=1:n_AL:length(fe_AL)
    AL_insert = [AL_insert; fe_AL(i)];
end

for i=1:n_PL:length(fe_PL)
    PL_insert = [PL_insert; fe_PL(i)];
end


%PL_insert = PL_insert(1:end-3,:);

end

