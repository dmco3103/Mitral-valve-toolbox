function [AL_insert,PL_insert,n_b,PM_3D] = number_chordae_3D_3b(V,fe_AL,fe_PL,ALPM_3D,PMPM_3D)

%% get leaflet insertion nodes for chordae

fe_AL2 = [];

for i=1:length(fe_AL)
   if abs(V(fe_AL(i),1))>0.1
fe_AL2 = [fe_AL2; fe_AL(i)];
   end
end

fe_PL2 = [];

for i=1:length(fe_PL)
   if abs(V(fe_PL(i),1))>0.1
fe_PL2 = [fe_PL2; fe_PL(i)];
   end
end

fe_AL = fe_AL2;
fe_PL = fe_PL2;

%%

n_start_PM = 12;

n_start_AL = 9;
%n_start_AL = 17;
n_start_PL = 15;
%n_start_PL = 24;

% how many branches from each chord?
n_b = 3;

total = n_b*n_start_PM*2;

n_insert_AL = n_b*n_start_AL;
n_insert_PL = n_b*n_start_PL;

n_AL = floor(length(fe_AL)/n_insert_AL);
n_PL = ceil(length(fe_PL)/n_insert_PL);


AL_insert = [];
PL_insert = [];

PL_insert3 = [];

for i=1:n_AL:length(fe_AL)
    AL_insert = [AL_insert; fe_AL(i)];
end

for i=1:n_PL:length(fe_PL)/2-9
    PL_insert = [PL_insert; fe_PL(i)];
end

for i=1:length(fe_PL)
    if fe_PL(i)==PL_insert(end)
        PL_insert(end) = fe_PL(i+5);
        break
    end
end

PL_insert = [PL_insert; fe_PL(ceil(length(fe_PL)/2+9))];

for i=1:length(fe_PL)
    if fe_PL(i)==PL_insert(end)
        PL_insert(end) = fe_PL(i-5);
        break
    end
end


for k=ceil(length(fe_PL)/2+15):n_PL:length(fe_PL)
    PL_insert = [PL_insert; fe_PL(k)];
end

%PL_insert = [PL_insert; PL_insert3];

%AL_insert = AL_insert(1:end-3,:);



%tol = 0.1;

%AL_insert2 = [];
%PL_insert2 = [];

%for i=1:length(AL_insert)
 %  if ismembertol(V(AL_insert(i),1),0,tol)==0
%AL_insert2 = [AL_insert2; AL_insert(i)];
 %  end
%end

%for i=1:length(PL_insert)
 %  if ismembertol(V(PL_insert(i),1),0,tol)==0
%PL_insert2 = [PL_insert2; PL_insert(i)];
 %  end
%end


%AL_insert = AL_insert2;

%p = AL_insert(1);
%AL_insert = AL_insert(2:end);

%PL_insert = PL_insert2;

%PL_insert = [PL_insert; p];



%% reorder 3D PM insertions for matching with leaflet insertions
PMPM_3D2 = PMPM_3D(1:end-1,:);

ALPM_3D2 = ALPM_3D(1:end-1,:);
ALPM_3D2 = flipud(ALPM_3D2);

PM_3D = [ALPM_3D2(8:end,:); PMPM_3D2; ALPM_3D2(1:7,:)];



%% PLOTS
%figure;
%hold on;

%for i=1:length(AL_insert)
%scatter3(V(AL_insert(i),1),V(AL_insert(i),2),V(AL_insert(i),3),'r','filled');
%end


%for i=1:length(PL_insert)
%scatter3(V(PL_insert(i),1),V(PL_insert(i),2),V(PL_insert(i),3),'b','filled');
%end


%for i=1:length(fe_AL)
%scatter3(V(fe_AL(i),1),V(fe_AL(i),2),V(fe_AL(i),3),'r');
%end

%for i=1:length(fe_PL)
%scatter3(V(fe_PL(i),1),V(fe_PL(i),2),V(fe_PL(i),3),'b');
%end


end

