function [dimensions] = avg_dim(AP_w)

%% Golden Proportions (Deorsola) and regressions

% Annular dimensions
CW_w = 1.236*AP_w;

%CW_w = 4/3*AP_w;

radius = CW_w/2;


%CW_w = 1.49*AP_w;


AH_LD = 0.236*AP_w; %AH at beginning of systole

%AH_w = radius/2;

% convert to mid-diastolic values based on data from (Tang, 2019)
%AH_w = (100*AH_LD)/(5.9+100);
%CW_w = (100*CW_w)/(-0.9+100);

AH_w = AH_LD;

% Leaflet lengths 

%AL_length_w = 0.9764*AP_w+3.2061; % correlation from (Deorsola, 2019)
%PL_length_w = 0.6626*AP_w+0.5344; % correlation from (Deorsola, 2019)

AL_length_w = AP_w;
PL_length_w = radius;

ann_PA1_w = 0.618*PL_length_w;



% Leaflet areas

%c1 = 114.83;
%c2 = 10.63;

%c3 = 65.75;
%c4 = 4.262;
    
%AC = 6.28*radius;
%AAC = (2/5)*AC;
    
%AL_area_w = c1+c2*AAC;

%PL_area_w = c3+c4*AC;


% final conversion for AP diameter
%AP_w = (100*AP_w)/(-2.1+100);

% Create strut with all dimensions
dimensions.answer = 'average';
    
    dimensions.AP_w = AP_w ;
    dimensions.CW_w = CW_w ;
    dimensions.AH_w = AH_w ;
   
    dimensions.AL_length_w = AL_length_w;
    dimensions.PL_length_w = PL_length_w;
    dimensions.ann_PA1_w = ann_PA1_w;
    
    %dimensions.AL_area = AL_area_w;
    %dimensions.PL_area = PL_area_w;
    
    dimensions.radius = radius;

    dimensions.ann_comm_w = 8;
    dimensions.paracom_l_w = 8; % just for initial parameterization


end

