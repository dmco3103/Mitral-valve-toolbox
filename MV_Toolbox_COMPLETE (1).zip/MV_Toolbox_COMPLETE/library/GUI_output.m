%% GUI for the MV toolbox
% - Input all dimensions needed to build the model

%clc; clear all; close all;

function [answer,answer_PM,mat] = GUI_output()

dlg_title = 'MV output';

% 1. select the type of model
prompt = {'Select the type of output: 0 for creation of simulation file, 1 for model export as .stl'};
num_lines = 1;
defaultans = {'0'};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);

if(str2num(answer{1,1})==0)

  answer = 0;

  
  dlg_title = 'Papillary muscle definition';

% 2. select type of papillary muscle representation for simulations
prompt = {'Select the type of papillary muscle representation: 0 for one tip point insertion, 1 for 3D insertion point cloud'};
num_lines = 1;
defaultans = {'0'};
answer_PM = inputdlg(prompt,dlg_title,num_lines,defaultans);

if(str2num(answer_PM{1,1})==0)

  answer_PM = 0;

 
elseif str2num(answer_PM{1,1})==1 

  answer_PM = 1;

end
  
  
% 3. select material properties and element thickness

dlg_title = 'Computational simulation: choose material properties and element thicknesses';

prompt = {'AL E(x) [MPa]','AL E(y) [MPa]',...
          'PL E(x) [MPa]','PL E(y) [MPa]',...
          'AL thickness [mm]', 'PL thickness [mm]'};

    num_lines = 1;
    
    defaultans = {'6.23','2.09',...
                  '2.35','1.887',...
                  '1','1'};


    answer_mat = inputdlg(prompt,dlg_title,num_lines,defaultans);
    
    mat.AL_Ex = str2num(answer_mat{1,1});
    mat.AL_Ey = str2num(answer_mat{2,1});
    mat.PL_Ex = str2num(answer_mat{3,1});
    mat.PL_Ey = str2num(answer_mat{4,1});
    mat.AL_T = str2num(answer_mat{5,1});
    mat.PL_T = str2num(answer_mat{6,1});



 
elseif str2num(answer{1,1})==1 

  answer = 1;
  answer_PM = '';
  mat = [];  
  
else
     error('Assign the flag for average dimensions (0) or subject-specific dimensions (1)');
end 

end
