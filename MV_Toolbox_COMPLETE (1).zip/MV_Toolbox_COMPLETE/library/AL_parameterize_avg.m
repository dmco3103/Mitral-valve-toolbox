function [boundary,point] = AL_parameterize_avg(boundary,point,radius)

%% parameterize
    
AL_area_w =  0.5 * pi*(4.236*radius^2)/4;

AL_area_w_minus = AL_area_w - AL_area_w*0.15;
AL_area_w_plus = AL_area_w + AL_area_w*0.15;


%% function to calculate current AL surface area
AL_area_m = AL_surf(boundary);

if AL_area_m >= AL_area_w_minus && AL_area_m <= AL_area_w_plus
return
end


tol=1e-1;

%B_comm_m = max(pathLength(boundary.B_comm));
%B_comm_w = 7;
%comm_f = B_comm_w/B_comm_m;

comm_f = 1;

% commissure - rotate to get (y,z)
Br_comm = rot90(boundary.B_comm); 
Br_comm = Br_comm';

p_comm = polyfit(Br_comm(:,1),Br_comm(:,2),2);
z4 = Br_comm(:,1);
y4 = polyval(p_comm,z4);

%%
if AL_area_w_minus > AL_area_m
  
while AL_area_m < AL_area_w_minus

B_comm2 = boundary.B_comm;    
       
% commissural boundary treatment
y44 = y4; z44 = z4;

y44 = comm_f*y44;
z44 = comm_f*z44;

%rotate all back
B_comm2 = rot90([z44 y44 comm_f*Br_comm(:,3)]); 
B_comm2 = B_comm2';

% translate points to match annular beginning
t_vector2 = [point.ann_comm(1)-B_comm2(1,1)...
    point.ann_comm(2)-B_comm2(1,2)...
    point.ann_comm(3)-B_comm2(1,3)];

B_comm2(:,1) = t_vector2(1) + B_comm2(:,1);
B_comm2(:,2) = t_vector2(2) + B_comm2(:,2);
B_comm2(:,3) = t_vector2(3) + B_comm2(:,3);


% fit anterior free edge between predefined boundaries
[boundary] = fit_AL_fe2(boundary,B_comm2);

% create temporary quad mesh for the AL and calculate surface area
AL_area_m = AL_surf2(boundary,B_comm2);


% change scaling factor for commissural boundary and start again
comm_f = comm_f + tol;

end
    
elseif AL_area_w_plus < AL_area_m
   
while AL_area_m > AL_area_w_plus

B_comm2 = boundary.B_comm;    
       
% commissural boundary treatment
y44 = y4; z44 = z4;

y44 = comm_f*y44;
z44 = comm_f*z44;

%rotate all back
B_comm2 = rot90([z44 y44 comm_f*Br_comm(:,3)]); 
B_comm2 = B_comm2';

% translate points to match annular beginning
t_vector2 = [point.ann_comm(1)-B_comm2(1,1)...
    point.ann_comm(2)-B_comm2(1,2)...
    point.ann_comm(3)-B_comm2(1,3)];

B_comm2(:,1) = t_vector2(1) + B_comm2(:,1);
B_comm2(:,2) = t_vector2(2) + B_comm2(:,2);
B_comm2(:,3) = t_vector2(3) + B_comm2(:,3);


% fit anterior free edge between predefined boundaries
[boundary] = fit_AL_fe2(boundary,B_comm2);

% create temporary quad mesh for the AL and calculate surface area
AL_area_m = AL_surf2(boundary,B_comm2);


% change scaling factor for commissural boundary and start again
comm_f = comm_f - tol;
     
end

end

boundary.B_comm = B_comm2;
%point.fe_comm = boundary.B_comm(end,:);

end
