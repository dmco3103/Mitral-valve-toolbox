
function [annode_ID,ann_vector,annular_disp2,ann_CW] = other_input1(node_list,ann_s,AH_w)


% define group of annular nodes for manipulation
annode_ID = [node_list(1,1)];

for i=2:length(node_list)

    if abs(node_list(i,4)-node_list(i-1,4)) > 3
 
        annode_ID = [annode_ID; i];
        
    end
end      


%% finding annular saddle-horn height (Votta 2009)
      
      PL_c = ann_s(201,2:3);
      CW_c = ann_s(80,2:3);
      AL_c = ann_s(1,2:3);
      
      c = [[1; 1]  CW_c(:)]\PL_c(:);
      slope_m = c(2);
      intercept_b = c(1);
      
      
     d1 = pdist([AL_c(1),AL_c(2);PL_c(1),PL_c(2)],'euclidean');
     d2 = pdist([AL_c(1),AL_c(2);CW_c(1),CW_c(2)],'euclidean');
     
     A = pdist([PL_c(1),PL_c(2);CW_c(1),CW_c(2)],'euclidean');
      
syms x1 y1;
      

eqn1 = d1 == sqrt((sqrt((PL_c(1)-x1)^2+(PL_c(2)-y1)^2))^2 + (sqrt((AL_c(1)-x1)^2+(AL_c(2)-y1)^2))^2);

eqn2 = d2 == sqrt((sqrt((CW_c(1)-x1)^2+(CW_c(2)-y1)^2))^2 + (sqrt((AL_c(1)-x1)^2+(AL_c(2)-y1)^2))^2);

[sx1, sy1] = vpasolve(eqn1,eqn2);

P = [double(sx1) double(sy1)];

H = pdist([AL_c(1),AL_c(2);P(1),P(2)],'euclidean'); %horn height


% find final horn height (mid-systole)
H_final = 1.09*H;



%% Change y and z annular coordinates until new H is obtained

tol=1e-2;
f_y = 1;
f_z = 1;
H_temp = H;

if H_temp < H_final
  
while H_temp < H_final

y = ann_s(:,2);
z = ann_s(:,3);

    y = f_y*y;
    z = f_z*z;
    
%for i=1:length(z)
 %   if z(i) > 0
  %  z(i) = f_z*z(i);
  %  end
%end

% find temporary H
 PL_c = [y(201) z(201)];
 CW_c = [y(80) z(80)];
 AL_c = [y(1) z(1)];
      
      c = [[1; 1]  CW_c(:)]\PL_c(:);
      slope_m = c(2);
      intercept_b = c(1);
      
      
     d1 = pdist([AL_c(1),AL_c(2);PL_c(1),PL_c(2)],'euclidean');
     d2 = pdist([AL_c(1),AL_c(2);CW_c(1),CW_c(2)],'euclidean');
     
     A = pdist([PL_c(1),PL_c(2);CW_c(1),CW_c(2)],'euclidean');
      
syms x1 y1;
      

eqn1 = d1 == sqrt((sqrt((PL_c(1)-x1)^2+(PL_c(2)-y1)^2))^2 + (sqrt((AL_c(1)-x1)^2+(AL_c(2)-y1)^2))^2);

eqn2 = d2 == sqrt((sqrt((CW_c(1)-x1)^2+(CW_c(2)-y1)^2))^2 + (sqrt((AL_c(1)-x1)^2+(AL_c(2)-y1)^2))^2);

[sx1, sy1] = vpasolve(eqn1,eqn2);

P = [double(sx1) double(sy1)];

H_temp = pdist([AL_c(1),AL_c(2);P(1),P(2)],'euclidean'); %horn height


% change scaling factor for y,z coordinates and start again
f_y = f_y - 0.95*tol;
f_z = f_z + 0.85*tol;

end
end


%% change z to match proper annular height variation
%height = max(z)-min(z);
%var = (height-AH_w)/AH_w;
%var_final = 0.12;
%f = var-var_final;
%f1 = 1-f;

%for i=1:length(y)
 %  if y(i)<0 
  %  z(i) = z(i).*f1;
 %  end    
%end




%%
ann_horn = [ann_s(:,1) y z];



%% Increase CW 

%factor to apply
CW_f = 0.95; %decrease 5% 

%CW_f = 1.05;

ann_CW = [CW_f.*ann_horn(:,1) ann_horn(:,2) ann_horn(:,3)];



%% Prescribe direction vector for annulus (diastole --> peak systole)

ann_vector = [];

for i=1:length(annode_ID)

    ann_vector = [ann_vector; node_list(annode_ID(i),2) node_list(annode_ID(i),3) node_list(annode_ID(i),4)...
         ann_CW(i,1) ann_CW(i,2) ann_CW(i,3)];
    
end

annular_disp2 = [];

for i=1:length(annode_ID)
   
    annular_disp2 = [annular_disp2; norm([ann_vector(i,4) ann_vector(i,5) ann_vector(i,6)]-[ann_vector(i,1) ann_vector(i,2) ann_vector(i,3)])]; 
    
end



%% figure

%AC_path1 = max(pathLength(ann_s));
%AC_path2 = max(pathLength(ann_CW));



%figure;

%scatter3(ann_s(:,1),ann_s(:,2),ann_s(:,3));
%hold on;
%scatter3(ann_horn(:,1),ann_horn(:,2),ann_horn(:,3));
%scatter3(ann_CW(:,1),ann_CW(:,2),ann_CW(:,3));


 %  for i=1:length(ann_s)
        %  if ann_s(i,2)<0
     % ann_s(i,2) = 0.8*ann_s(i,2);
     % ann_s(i,3) = 1.2*ann_s(i,3);

      %    end
       %   end

       
       
%% find dimensions

%CW_1 = -2*ann_s(80,1);
%CW_2 = -2*ann_CW(80,1);
%CW_diff = 100*(CW_2-CW_1)/CW_1;


%AP_2 = ann_CW(201,2)-ann_CW(1,2);
%AP_diff = 100*(AP_2-AP_w)/AP_w;

%AH_2 = max(ann_CW(:,3))-min(ann_CW(:,3));
%AH_diff = 100*(AH_2-AH_w)/AH_w;
   
%ann_per1 = max(pathLength(ann_s));
%ann_per2 = max(pathLength(ann_CW));
%ann_per_diff = 100*(ann_per2-ann_per1)/ann_per1;

end