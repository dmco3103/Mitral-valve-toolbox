function [boundary] = fit_PA1_fe(boundary)
%% PA1 free edge

% first, translate points to match end of parameterized commissural boundary
t_vector3 = [boundary.B_comm(end,1)-boundary.fe_PA1(1,1) boundary.B_comm(end,2)-boundary.fe_PA1(1,2) boundary.B_comm(end,3)-boundary.fe_PA1(1,3)];

boundary.fe_PA1(:,1) = t_vector3(1) + boundary.fe_PA1(:,1);
boundary.fe_PA1(:,2) = t_vector3(2) + boundary.fe_PA1(:,2);
boundary.fe_PA1(:,3) = t_vector3(3) + boundary.fe_PA1(:,3);


% adaptive transformation in all axis:

% distance between free edge at paracommissural level and paracommissural end point
d = [boundary.B_paracom(end,1)-boundary.fe_PA1(end,1) boundary.B_paracom(end,2)-boundary.fe_PA1(end,2) boundary.B_paracom(end,3)-boundary.fe_PA1(end,3)];


% x transformation

divisory = d(1)/(length(boundary.fe_PA1)-1);
v = [0];

for i=1:length(boundary.fe_PA1)-1
   v = [v; v(i) + divisory]; 
end

% adaptive transform of PA1 free edge
for i=1:length(boundary.fe_PA1)
boundary.fe_PA1(i,1) = v(i) + boundary.fe_PA1(i,1);
end


% y transformation

divisory = d(2)/(length(boundary.fe_PA1)-1);
v = [0];

for i=1:length(boundary.fe_PA1)-1
   v = [v; v(i) + divisory]; 
end

% adaptive transform of PA1 free edge
for i=1:length(boundary.fe_PA1)
boundary.fe_PA1(i,2) = v(i) + boundary.fe_PA1(i,2);
end


% z transformation

divisorz = d(3)/(length(boundary.fe_PA1)-1);
v = [0];

for i=1:length(boundary.fe_PA1)-1
   v = [v; v(i) + divisorz]; 
end

% adaptive transform of PA1 free edge
for i=1:length(boundary.fe_PA1)
boundary.fe_PA1(i,3) = v(i) + boundary.fe_PA1(i,3);
end


end

