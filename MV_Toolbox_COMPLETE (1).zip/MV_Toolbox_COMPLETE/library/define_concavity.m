function [ann_s] = define_concavity(ann_s,concave_parameter)

% invert node order of free edge so it matches anterior mid-point start
%fe_s = flipud(fe_s);

% concavity fit

%fight right trigone

%get perimeter of AC (HALF MODEL)
AC_1 = pathLength(ann_s);

% find right trigone based on distance of 28 mm (14mm on half model)
AC_totalpath = max(AC_1);
IT = 1/4*AC_totalpath;

IT_v = [];

i = 1;

% get vertex corresponding to IT distance
while i < length (AC_1)   
    if AC_1(i,1) < IT       
        IT_v = [IT_v; ann_s(i,:)];                        
    end    
    i=i+1;    
end

%%
x1 = IT_v(:,1);
y1 = IT_v(:,2);

% parameterization itself
%factor choice: 1 keeps shape intact; 0 alters shape to maximum
%concave_parameter = 0.01;

if concave_parameter == 0
    factor = 1;
elseif concave_parameter == 1
    factor = 0;
else
    factor = 1-concave_parameter;
    
end




if factor < 1
    
v = (1-factor)/length(IT_v);
v = factor:v:1;
v = v';

for i=1:length(IT_v)
y1(i,1) = v(i,:)*y1(i,1);
end


elseif factor == 1
    
    i = length(y1);
    while y1(i)~= min(y1)
        i = i-1;
    end
    
    while i>=1
        y1(i) = min(y1);
        i = i-1;
    end

end
    
    

%save points
ann_s = [x1 y1 IT_v(:,3); ann_s(length(IT_v)+1:end,1) ann_s(length(IT_v)+1:end,2) ann_s(length(IT_v)+1:end,3)];

%[ann_s] = evenlySampleCurve(ann_s,200,'pchip',0);

end

