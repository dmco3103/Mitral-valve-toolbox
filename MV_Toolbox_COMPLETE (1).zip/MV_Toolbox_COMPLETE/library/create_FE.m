function [fe_s] = create_FE(ann_s,FE_source,AL_endpoint, comm_endpoint, annPA1_endpoint, paracom_endpoint, PL_endpoint)


fe_p = [AL_endpoint; comm_endpoint; annPA1_endpoint; paracom_endpoint; PL_endpoint];

[fe_s] = evenlySampleCurve(fe_p,200,'pchip',0);
%[fe_s] = evenlySampleCurve(fe_p,200,0.995,0);


% positions of landmarks which must not change
fe_s_pos = [1; 78; 113; 153; 200];



%% transform AL free edge
[FE_source_AL] = evenlySampleCurve(FE_source,185,'pchip',0);

h1 = fe_s(78,3)-fe_s(1,3);
h2 = FE_source_AL(78,2)-FE_source_AL(1,2);

scale = h1/h2;
FE_source_AL(:,2) = FE_source_AL(:,2)*scale;

%fe_s2 = [fe_s];

for i=2:78
   
   h1 = FE_source_AL(i,2)-FE_source_AL(i-1,2);
      
   fe_s(i,3) = fe_s(i-1,3)+h1;
   
 %  h2 = fe_s(i,3)-fe_s(i-1,3);
    
end


%% transform PA2 free edge
[FE_source_PL] = evenlySampleCurve(FE_source,207,'pchip',0);

h1 = fe_s(200,3)-fe_s(156,3);
h2 = FE_source_PL(207,2)-FE_source_PL(156,2);

scale = h1/h2;
FE_source_PL(:,2) = FE_source_PL(:,2)*scale;

for i=157:200
   
   h1 = FE_source_PL(i,2)-FE_source_PL(i-1,2);
      
   fe_s(i,3) = fe_s(i-1,3)+h1;
   
 %  h2 = fe_s(i,3)-fe_s(i-1,3);
    
end


%% transform PA1 free edge (1)
[FE_source_PA1] = evenlySampleCurve(FE_source,185,'pchip',0);

h1 = fe_s(113,3)-fe_s(78,3);
h2 = FE_source_PA1(113,2)-FE_source_PA1(78,2);

scale = h1/h2;
FE_source_PA1(:,2) = FE_source_PA1(:,2)*scale;

for i=79:113
   
   h1 = FE_source_PA1(i,2)-FE_source_PA1(i-1,2);
      
   fe_s(i,3) = fe_s(i-1,3)+h1;
   
 %  h2 = fe_s(i,3)-fe_s(i-1,3);
    
end


%% transform PA1 free edge (2)
[FE_source_PA1] = evenlySampleCurve(FE_source,207,'pchip',0);

h1 = fe_s(156,3)-fe_s(113,3);
h2 = FE_source_PA1(156,2)-FE_source_PA1(125,2);

scale = h1/h2;
FE_source_PA1(:,2) = FE_source_PA1(:,2)*scale;

FE_source_PA1_s = FE_source_PA1(125:156,:);
s = 156-113;

[FE_source_PA1_s] = evenlySampleCurve(FE_source_PA1_s,s,'pchip',0);


for i=114:155
    
   h1 = FE_source_PA1_s(i-112,2)-FE_source_PA1_s(i-112-1,2);
      
   fe_s(i,3) = fe_s(i-1,3)+h1;
   
 %  h2 = fe_s(i,3)-fe_s(i-1,3);
    
end




%%

fe_s(:,1) = ann_s(:,1);
fe_s(:,2) = ann_s(:,2);

%[fe_s] = evenlySampleCurve(fe_s,200,0.95,0);


    fe_s(1,1) = 0;
    fe_s(end,1) = 0;

%fe_s(:,1) = 0.98*fe_s(:,1);
%fe_s(:,2) = 0.98*fe_s(:,2);

    
end

