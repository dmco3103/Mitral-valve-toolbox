%----------- GENERATE LS-DYNA INPUT -------------------------------------------

part(1) = cellstr('AL');
part(2) = cellstr('PL');
part(3) = cellstr('Chordae_pre');
part(4) = cellstr('Chordae_post');

%part(5) = cellstr('AL chordae_post');
%part(6) = cellstr('PL chordae_post');

part(5) = cellstr('Transition elements');

part(6) = cellstr('AL free edge');
part(7) = cellstr('PL free edge');

part(8) = cellstr('Chordae_strut');


%start writing file
savefile = ['LSDyna_inputfile_MV.k'];
fid = fopen(savefile, 'wt');

fprintf(fid, '*KEYWORD\n');
fprintf(fid, '$\n');


% FILE TITLE

fprintf(fid, '$ (1) TITLE CARD\n');
fprintf(fid, '$\n');
fprintf(fid, '*TITLE\n');
fprintf(fid, 'MV\n');
fprintf(fid, '$\n');


% DEFINE SIMULATION CONTROLS

fprintf(fid, '$ (2) CONTROL DEFINITIONS\n');
fprintf(fid, '$\n');

% cycle is scaled 1/10, so will finish at 0.1 s
fprintf(fid, '*CONTROL_TERMINATION\n');
fprintf(fid, '$ ENDTIM ENDCYC DTMIN ENDNEG ENDMAS\n');
fprintf(fid, ' 0.700E+00 0 0.000E+00 0.000E+00 0.000E+00\n');

fprintf(fid, '$\n');

%scaling factor for step size (default = 0.9, but smaller is better)
fprintf(fid, '*CONTROL_TIMESTEP\n');
fprintf(fid, '$ DTINIT SCFT ISDO TSLIMT DTMS LCTM ERODE MS1ST\n');
fprintf(fid, ' 0.000E+00 0.2500E+00 0\n');

fprintf(fid, '$\n');

% control large element deformation
fprintf(fid, '*CONTROL_HOURGLASS\n');
fprintf(fid, '$ IHQ QH\n');
fprintf(fid, ' 4,0.03\n');

fprintf(fid, '$\n');


% control shell warping (and other things)
fprintf(fid, '*CONTROL_SHELL\n');
fprintf(fid, '$ WRPANG ESORT IRNXX ISTUPD THEORY BWC MITER PROJ\n');
fprintf(fid, ' 20.0,0,-2,0,5,2,1,1\n');

fprintf(fid, '$\n');


% control results accuracy
fprintf(fid, '*CONTROL_ACCURACY\n');
fprintf(fid, '$ OSU INN PIDOSU IACC\n');
fprintf(fid, ' 1,4\n');

fprintf(fid, '$\n');


% control shock wave propagation
fprintf(fid, '*CONTROL_BULK_VISCOSITY\n');
fprintf(fid, '$ Q2 Q1 TYPE\n');
fprintf(fid, ' 0.150E+01 0.600E-01 -2\n');

fprintf(fid, '$\n');


% control energy dissipation
fprintf(fid, '*CONTROL_ENERGY\n');
fprintf(fid, '$ HGEN RWEN SLNTEN RYLEN\n');
fprintf(fid, ' 2,1,2,1\n');

fprintf(fid, '$\n');

fprintf(fid, '*CONTROL_OUTPUT\n');
fprintf(fid, '$ NPOPT NEECHO NREFUP IACCOP OPIFS IPNINT IKEDIT\n');
fprintf(fid, ' 0 0 0 0 0.000E+00 0 0\n');

fprintf(fid, '$\n');

% Ignore initial contact, but penetration warnings are still printed
fprintf(fid, '*CONTROL_CONTACT\n');
fprintf(fid, '\n\n\n 2,1\n'); 


% Prescribe nodal velocity dampening
fprintf(fid, '*CONTROL_DYNAMIC_RELAXATION\n');
fprintf(fid, '$ NRCYCK DRTOL DRFCTR DRTERM TSSFDR IRELAL EDTTL IDRFLG\n');
fprintf(fid, ' , , , ,0.9965\n');




fprintf(fid, '$\n');


% DEFINE DATABASE CONTROLS

% obtain global and interface forces, with time interval = 0.00012
fprintf(fid, '*DATABASE_GLSTAT\n');
fprintf(fid, ' 0.120E-03\n');

fprintf(fid, '$\n');

fprintf(fid, '*DATABASE_RCFORC\n');
fprintf(fid, ' 0.120E-03\n');

fprintf(fid, '$\n');

fprintf(fid, '*DATABASE_SLEOUT\n');
fprintf(fid, ' 0.120E-03\n');

fprintf(fid, '$\n');



% cards for binary file definition
fprintf(fid, '*DATABASE_BINARY_D3PLOT\n');
fprintf(fid, '$ DT/CYCL LCDT NOBEAM\n');
fprintf(fid, ' 0.100E-02\n');

fprintf(fid, '$\n');

fprintf(fid, '*DATABASE_BINARY_D3THDT\n');
fprintf(fid, '$ DT/CYCL LCDT NOBEAM\n');
fprintf(fid, ' 0.100E-02\n');

fprintf(fid, '$\n');

fprintf(fid, '*DATABASE_BINARY_INTFOR\n');
fprintf(fid, '$ DT/CYCL LCDT BEAM NPLTC PSETID\n');
fprintf(fid, ' 0.100E-02,0,0,0,1\n');

fprintf(fid, '$\n');


fprintf(fid, '*DATABASE_HISTORY_BEAM\n');
fprintf(fid, '$ ID1 ID2 ID3...\n');

for i = 1:size(element_beam,1)
    fprintf(fid, '%8i\n',element_beam(i,1));
end

fprintf(fid, '$\n');

% further control of outputs:
% - write number of shell integration points
% - include stress tensor for shells
% - include effective palstic strains for shells
% - include stress resultants in shell
% - include internal energy density and shell thickness
fprintf(fid, '*DATABASE_EXTENT_BINARY\n');

fprintf(fid, '$ NEIPH NEIPS MAXINT STRFLG SIGFLG EPSFLG RLTFLG ENGFLG\n');
fprintf(fid, ' 0,0,3,0,1,1,1,1\n');
fprintf(fid, ' 1,0,0,0,0,0\n');
fprintf(fid, ' 0,1,1\n');




% DEFINE PARTS (AL = 1; PL = 2; AL chordae = 3; PL chordae = 4)

fprintf(fid, '$ (3) PART DEFINITIONS\n');
fprintf(fid, '$\n');

for i = 1:8
fprintf(fid, '*PART\n');
fprintf(fid, '$ HEADING\n');
fprintf(fid, ' PART PID = %2i PART NAME : %s\n', i,char(part(i)));
fprintf(fid, '$ PID SID MID EOSID HGID GRAV ADPOPT TMID\n');
fprintf(fid, '%10i %9i %9i\n', i,i,i);
end

fprintf(fid, '$\n');



% MATERIAL PROPERTIES

fprintf(fid, '$ (4) DEFINE MATERIAL PROPERTIES\n');

% for leaflets

% AL
fprintf(fid, '*MAT_SOFT_TISSUE\n');
fprintf(fid, '$MATERIAL NAME: Anterior leaflet - circumferential\n');
fprintf(fid, '$ MID RO C1 C2 C3 C4 C5\n');
fprintf(fid, ' 1,1.000E-09,1E-03,0,1.5E-03,25,0\n');
fprintf(fid, '$ XK XLAM FANG XLAM0 FAILSF FAILSM FAILSHR\n');
fprintf(fid, ' 10,1.4,0\n');


%fprintf(fid, '*MAT_NONLINEAR_ORTHOTROPIC\n');
%fprintf(fid, '$MATERIAL NAME: Anterior leaflet\n');
%fprintf(fid, '$ MID RO EA EB EC PRBA PRCA PRCB\n');
%fprintf(fid, ' 1,1.000E-09,17.1,6.7,20,0.45\n');
%fprintf(fid, '$ GAB GBC GCA DT TRAMP ALPHA\n');
%fprintf(fid, ' 1.37,1.37,1.37,0\n');
%fprintf(fid, '$ LCIDA LCIDB EFAIL DTFAIL CDAMP AOPT MACF\n');
%fprintf(fid, ' 10,11,0.5\n');



fprintf(fid, '\n');


%fprintf(fid, '*MAT_ELASTIC\n');
%fprintf(fid, '$MATERIAL NAME: Anterior leaflet\n');
%fprintf(fid, '$ MID RO E PR\n');
%fprintf(fid, ' 1,1.000E-09,3,0.45\n');

%fprintf(fid, '\n');



% AL free edge
fprintf(fid, '*MAT_SOFT_TISSUE\n');
fprintf(fid, '$MATERIAL NAME: Anterior leaflet - circumferential\n');
fprintf(fid, '$ MID RO C1 C2 C3 C4 C5\n');
fprintf(fid, ' 6,1.000E-09,1E-03,0,1.5E-03,25,0\n');
fprintf(fid, '$ XK XLAM FANG XLAM0 FAILSF FAILSM FAILSHR\n');
fprintf(fid, ' 10,1.4,0\n');

%fprintf(fid, '*MAT_NONLINEAR_ORTHOTROPIC\n');
%fprintf(fid, '$MATERIAL NAME: Anterior leaflet\n');
%fprintf(fid, '$ MID RO EA EB EC PRBA PRCA PRCB\n');
%fprintf(fid, ' 6,1.000E-09,17.1,6.7,20,0.45\n');
%fprintf(fid, '$ GAB GBC GCA DT TRAMP ALPHA\n');
%fprintf(fid, ' 1.37,1.37,1.37,0\n');
%fprintf(fid, '$ LCIDA LCIDB EFAIL DTFAIL CDAMP AOPT MACF\n');
%fprintf(fid, ' 10,11,0.5\n');


fprintf(fid, '\n');


%fprintf(fid, '*MAT_ELASTIC\n');
%fprintf(fid, '$MATERIAL NAME: Anterior leaflet\n');
%fprintf(fid, '$ MID RO E PR\n');
%fprintf(fid, ' 6,1.000E-09,3,0.45\n');

%fprintf(fid, '\n');


% PL
fprintf(fid, '*MAT_SOFT_TISSUE\n');
fprintf(fid, '$MATERIAL NAME: Anterior leaflet - circumferential\n');
fprintf(fid, '$ MID RO C1 C2 C3 C4 C5\n');
fprintf(fid, ' 2,1.000E-09,4E-02,0,3E-03,16,0\n');
fprintf(fid, '$ XK XLAM FANG XLAM0 FAILSF FAILSM FAILSHR\n');
fprintf(fid, ' 10,1.4,0\n');


%fprintf(fid, '*MAT_NONLINEAR_ORTHOTROPIC\n');
%fprintf(fid, '$MATERIAL NAME: Posterior leaflet\n');
%fprintf(fid, '$ MID RO EA EB EC PRBA PRCA PRCB\n');
%fprintf(fid, ' 2,1.000E-09,5.6,3.4,20,0.45\n');
%fprintf(fid, '$ GAB GBC GCA DT TRAMP ALPHA\n');
%fprintf(fid, ' 1.37,1.37,1.37,0\n');
%fprintf(fid, '$ LCIDA LCIDB EFAIL DTFAIL CDAMP AOPT MACF\n');
%fprintf(fid, ' 12,13,0.5\n');

fprintf(fid, '\n');




%fprintf(fid, '*MAT_ELASTIC\n');
%fprintf(fid, '$MATERIAL NAME: Posterior leaflet\n');
%fprintf(fid, '$ MID RO E PR\n');
%fprintf(fid, ' 2,1.000E-09,3,0.45\n');

%fprintf(fid, '\n');


% PL free edge
fprintf(fid, '*MAT_SOFT_TISSUE\n');
fprintf(fid, '$MATERIAL NAME: Anterior leaflet - circumferential\n');
fprintf(fid, '$ MID RO C1 C2 C3 C4 C5\n');
fprintf(fid, ' 7,1.000E-09,4E-02,0,3E-03,16,0\n');
fprintf(fid, '$ XK XLAM FANG XLAM0 FAILSF FAILSM FAILSHR\n');
fprintf(fid, ' 10,1.4,0\n');
fprintf(fid, '\n');

%fprintf(fid, '*MAT_NONLINEAR_ORTHOTROPIC\n');
%fprintf(fid, '$MATERIAL NAME: Posterior leaflet\n');
%fprintf(fid, '$ MID RO EA EB EC PRBA PRCA PRCB\n');
%fprintf(fid, ' 7,1.000E-09,5.6,3.4,20,0.45\n');
%fprintf(fid, '$ GAB GBC GCA DT TRAMP ALPHA\n');
%fprintf(fid, ' 1.37,1.37,1.37,0\n');
%fprintf(fid, '$ LCIDA LCIDB EFAIL DTFAIL CDAMP AOPT MACF\n');
%fprintf(fid, ' 12,13,0.5\n');
%fprintf(fid, '\n');


%fprintf(fid, '*MAT_ELASTIC\n');
%fprintf(fid, '$MATERIAL NAME: Posterior leaflet\n');
%fprintf(fid, '$ MID RO E PR\n');
%fprintf(fid, ' 7,1.000E-09,3,0.45\n');

%fprintf(fid, '\n');



% transition elements
fprintf(fid, '*MAT_ELASTIC\n');
fprintf(fid, '$MATERIAL NAME: Transition elements\n');
fprintf(fid, '$ MID RO E PR\n');
fprintf(fid, ' 5,1.000E-09,60,0.488\n');

fprintf(fid, '\n');



% for chordae

fprintf(fid, '*MAT_CABLE_DISCRETE_BEAM\n');
fprintf(fid, '$MATERIAL NAME:AL chordae \n');
fprintf(fid, '$MATERIAL NAME:AChordae\n');
fprintf(fid, '$ MID RO E LCID F0\n');
fprintf(fid, ' 3,1.000E-09, ,3\n');

fprintf(fid, '$\n');


fprintf(fid, '*MAT_CABLE_DISCRETE_BEAM\n');
fprintf(fid, '$MATERIAL NAME:PL Chordae \n');
fprintf(fid, '$ MID RO E LCID F0\n');
fprintf(fid, ' 4,1.000E-09, ,3\n');

fprintf(fid, '$\n');


% strut chordae
fprintf(fid, '*MAT_CABLE_DISCRETE_BEAM\n');
fprintf(fid, '$MATERIAL NAME:Strut Chordae \n');
fprintf(fid, '$ MID RO E LCID F0\n');
fprintf(fid, ' 8,1.000E-09, ,4\n');

fprintf(fid, '$\n');




% SECTION PROPERTIES (AL_SECID = 1; PL_SECID = 2; AL chordae_SECID = 3; PL chordae_SECID = 4)

% for leaflets (define shell)
fprintf(fid, '$ (5) SECTION PROPERTIES\n');
fprintf(fid, '$\n');
fprintf(fid, '*SECTION_SHELL\n');
fprintf(fid, '$ SECID ELFORM SHRF NIP PROPT QR/IRID ICOMP SETYP\n');
fprintf(fid, '%10i %9i %9.5f %9i %9i %9i %9i %9i\n', 1,5,0.833,1,1,0,0,1);
fprintf(fid, '$ T1 T2 T3 T4 NLOC MAREA IDOF EDGSET\n');
fprintf(fid, '%10.5f %9.5f %9.5f %9.5f %9.5f\n', 1,1,1,1,0.);

fprintf(fid, '$\n');


fprintf(fid, '*SECTION_SHELL\n');
fprintf(fid, '$ SECID ELFORM SHRF NIP PROPT QR/IRID ICOMP SETYP\n');
fprintf(fid, '%10i %9i %9.5f %9i %9i %9i %9i %9i\n', 2,5,0.833,1,1,0,0,1);
fprintf(fid, '$ T1 T2 T3 T4 NLOC MAREA IDOF EDGSET\n');
fprintf(fid, '%10.5f %9.5f %9.5f %9.5f %9.5f\n', 1,1,1,1,0.);

fprintf(fid, '$\n');


% free edge elements
fprintf(fid, '*SECTION_SHELL\n');
fprintf(fid, '$ SECID ELFORM SHRF NIP PROPT QR/IRID ICOMP SETYP\n');
fprintf(fid, '%10i %9i %9.5f %9i %9i %9i %9i %9i\n', 6,5,0.833,1,1,0,0,1);
fprintf(fid, '$ T1 T2 T3 T4 NLOC MAREA IDOF EDGSET\n');
fprintf(fid, '%10.5f %9.5f %9.5f %9.5f %9.5f\n', 1,1,1,1,0.);

fprintf(fid, '$\n');


fprintf(fid, '*SECTION_SHELL\n');
fprintf(fid, '$ SECID ELFORM SHRF NIP PROPT QR/IRID ICOMP SETYP\n');
fprintf(fid, '%10i %9i %9.5f %9i %9i %9i %9i %9i\n', 7,5,0.833,1,1,0,0,1);
fprintf(fid, '$ T1 T2 T3 T4 NLOC MAREA IDOF EDGSET\n');
fprintf(fid, '%10.5f %9.5f %9.5f %9.5f %9.5f\n', 1,1,1,1,0.);

fprintf(fid, '$\n');




% transition elements
fprintf(fid, '*SECTION_SHELL\n');
fprintf(fid, '$ SECID ELFORM SHRF NIP PROPT QR/IRID ICOMP SETYP\n');
fprintf(fid, '%10i %9i %9.5f %9i %9i %9i %9i %9i\n', 5,2,0.833,3,1,0,0,1);
fprintf(fid, '$ T1 T2 T3 T4 NLOC MAREA IDOF EDGSET\n');
fprintf(fid, '%10.5f %9.5f %9.5f %9.5f %9.5f\n', 1,1,1,1,0.);

%fprintf(fid, '$\n');


% for chordae (define beams)

fprintf(fid, '*SECTION_BEAM\n');
fprintf(fid, '$ SECID ELFORM SHRF QR/IRID CST SCOOR NSM\n');
fprintf(fid, '%10i %9i %9i %9i %9i %9i\n', 3,6,1,2,0,2);
fprintf(fid, '$ VOL INER CID CA OFFSET\n');
fprintf(fid, '%10.5f %9.5f %9i %9.5f\n', 0,0.64,0,0.4);

fprintf(fid, '$\n');

fprintf(fid, '*SECTION_BEAM\n');
fprintf(fid, '$ SECID ELFORM SHRF QR/IRID CST SCOOR NSM\n');
fprintf(fid, '%10i %9i %9i %9i %9i %9i\n', 4,6,1,2,0,2);
fprintf(fid, '$ VOL INER CID CA OFFSET\n');
fprintf(fid, '%10.5f %9.5f %9i %9.5f\n', 0,0.64,0,0.4);

fprintf(fid, '$\n');


% strut chordae
fprintf(fid, '*SECTION_BEAM\n');
fprintf(fid, '$ SECID ELFORM SHRF QR/IRID CST SCOOR NSM\n');
fprintf(fid, '%10i %9i %9i %9i %9i %9i\n', 8,6,1,2,0,2);
fprintf(fid, '$ VOL INER CID CA OFFSET\n');
fprintf(fid, '%10.5f %9.5f %9i %9.5f\n', 0,0.64,0,2.05);

fprintf(fid, '$\n');




% MESH NODES

fprintf(fid, '$ (6) NODE DEFINITIONS\n');
fprintf(fid, '$\n');
fprintf(fid, '*NODE\n');
fprintf(fid, '$ NODE X Y Z\n');

for i = 1:length(node_list)   
fprintf(fid, '%8i %15.4f %15.4f %15.4f\n',node_list(i,1),node_list(i,2),node_list(i,3),node_list(i,4));
end
fprintf(fid, '$\n');


% MESH ELEMENTS

fprintf(fid, '$ (7) ELEMENT DEFINITIONS\n');
fprintf(fid, '$\n');

% for leaflet elements
fprintf(fid, '*ELEMENT_SHELL\n');
fprintf(fid, '$ EID PID\n');
fprintf(fid, '$ N1 N2 N3 N4 N5 N6 N7 N8\n');

for i = 1:size(element_shell,1)
fprintf(fid, '%8i %7i %7i %7i %7i %7i %7i %7i %7i %7i\n',element_shell(i,1),element_shell(i,2),element_shell(i,3),element_shell(i,4),element_shell(i,5),element_shell(i,6),0,0,0,0);
end

fprintf(fid, '$\n');


% for chordal elements
fprintf(fid, '*ELEMENT_BEAM\n');
fprintf(fid, '$ EID PID N1 N2 N3\n');

for i = 1:size(element_beam,1)
    fprintf(fid, '%8i %7i %7i %7i\n',element_beam(i,1),element_beam(i,2),element_beam(i,3),element_beam(i,4));
end

fprintf(fid, '$\n');


% for transition elements
fprintf(fid, '*ELEMENT_SHELL\n');
fprintf(fid, '$ EID PID\n');
fprintf(fid, '$ N1 N2 N3 N4 N5 N6 N7 N8\n');

for i = 1:size(transition_shell,1)
fprintf(fid, '%8i %7i %7i %7i %7i %7i %7i %7i %7i %7i\n',transition_shell(i,1),transition_shell(i,2),...
    transition_shell(i,3),transition_shell(i,4),transition_shell(i,5),transition_shell(i,6),0,0,0,0);
end

fprintf(fid, '$\n');




% DEFINE BOUNDARY CONDITIONS

fprintf(fid, '$ (16) BOUNDARY CONDITIONS\n');
fprintf(fid, '$\n');


% ANNULAR DISPLACEMENT

%fprintf(fid, '*BOUNDARY_SPC_NODE\n');
%fprintf(fid, '$ NID/NSID CID DOFX DOFY DOFZ DOFRX DOFRY DOFRZ\n');

%for i=1:length(annode_ID)

%fprintf(fid, '%10i %9i %9i %9i %9i \n',annode_ID(i),0,1,1,1); % no displacements
%end

fprintf(fid, '*BOUNDARY_PRESCRIBED_MOTION_NODE\n');
fprintf(fid, '$ NID DOF VAD LCID SF VID DEATH BIRTH\n');

for i = 1:size(annode_ID,1)
fprintf(fid, '%10i %9i %9i %9i %9f %9i\n',annode_ID(i),-4,2,i+9,1,i);
end


%Define radial vectors for each node of the annulus
fprintf(fid, '*DEFINE_VECTOR\n');
fprintf(fid, '$ VID XT YT ZT XH YH ZH\n');

for i = 1:size(ann_vector,1)
    fprintf(fid, '%10i %9.4f %9.4f %9.4f %9.4f %9.4f %9.4f\n',i,ann_vector(i,1),...
    ann_vector(i,2),ann_vector(i,3),ann_vector(i,4),ann_vector(i,5),ann_vector(i,6));
end


%Define annular displacements

for i=1:length(annular_disp2)


fprintf(fid, '*DEFINE_CURVE\n');
fprintf(fid, '$ LCID SIDR SCLA SCLO OFFA OFFO\n');


fprintf(fid, '%10i %9i\n',i+9,0);
fprintf(fid, '$ A1 O1\n');

%cycle 1
fprintf(fid, '%10.9f %9.1f\n', .000000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .540000000E-02,0.0);
fprintf(fid, '%11.9f %13.3f\n', .400000000E-01,annular_disp2(i));
fprintf(fid, '%10.9f %9.1f\n', .740000000E-01,0.0);

%cycle2
fprintf(fid, '%10.9f %9.1f\n', .100000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .105400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .140000000E+00,annular_disp2(i));
fprintf(fid, '%10.9f %9.1f\n', .174000000E+00,0.0);

%cycle3
fprintf(fid, '%10.9f %9.1f\n', .200000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .205400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .240000000E+00,annular_disp2(i));
fprintf(fid, '%10.9f %9.1f\n', .274000000E+00,0.0);

%cycle4
fprintf(fid, '%10.9f %9.1f\n', .300000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .305400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .340000000E+00,annular_disp2(i));
fprintf(fid, '%10.9f %9.1f\n', .374000000E+00,0.0);

%cycle5
fprintf(fid, '%10.9f %9.1f\n', .400000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .405400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .440000000E+00,annular_disp2(i));
fprintf(fid, '%10.9f %9.1f\n', .474000000E+00,0.0);

%cycle6
fprintf(fid, '%10.9f %9.1f\n', .500000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .505400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .540000000E+00,annular_disp2(i));
fprintf(fid, '%10.9f %9.1f\n', .574000000E+00,0.0);


%cycle7
fprintf(fid, '%10.9f %9.1f\n', .600000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .605400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .640000000E+00,annular_disp2(i));
fprintf(fid, '%10.9f %9.1f\n', .674000000E+00,0.0);

fprintf(fid, '%10.9f %9.1f\n', .700000000E+00,0.0);



end


% PAPILLARY MUSCLE DISPLACEMENT

fprintf(fid, '*BOUNDARY_PRESCRIBED_MOTION_NODE\n');
fprintf(fid, '$ NID DOF VAD LCID SF VID DEATH BIRTH\n');

fprintf(fid, '%10i %9i %9i %9i %9f %9i\n',ALPM_nodepos,-4,2,6,1,length(annode_ID)+1);

fprintf(fid, '%10i %9i %9i %9i %9f %9i\n',PMPM_nodepos,-4,2,7,1,length(annode_ID)+2);

fprintf(fid, '$\n');

%Define direction vectors for PM
fprintf(fid, '*DEFINE_VECTOR\n');
fprintf(fid, '$ VID XT YT ZT XH YH ZH\n');

fprintf(fid, '%10i %9.4f %9.4f %9.4f %9.4f %9.4f %9.4f\n',length(annode_ID)+1,ALPM_vector(1),...
ALPM_vector(2),ALPM_vector(3),ALPM_vector(4),ALPM_vector(5),ALPM_vector(6));

fprintf(fid, '%10i %9.4f %9.4f %9.4f %9.4f %9.4f %9.4f\n',length(annode_ID)+2,PMPM_vector(1),...
PMPM_vector(2),PMPM_vector(3),PMPM_vector(4),PMPM_vector(5),PMPM_vector(6));


%Define ALPM displacements
fprintf(fid, '*DEFINE_CURVE\n');
fprintf(fid, '$ LCID SIDR SCLA SCLO OFFA OFFO\n');
fprintf(fid, '%10i %9i\n',6,0);
fprintf(fid, '$ A1 O1\n');

%cycle 1
fprintf(fid, '%10.9f %9.1f\n', .000000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .540000000E-02,0.0);
fprintf(fid, '%11.9f %13.3f\n', .400000000E-01,ALPM_mag);
fprintf(fid, '%10.9f %9.1f\n', .740000000E-01,0.0);

%cycle2
fprintf(fid, '%10.9f %9.1f\n', .100000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .105400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .140000000E+00,ALPM_mag);
fprintf(fid, '%10.9f %9.1f\n', .174000000E+00,0.0);

%cycle3
fprintf(fid, '%10.9f %9.1f\n', .200000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .205400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .240000000E+00,ALPM_mag);
fprintf(fid, '%10.9f %9.1f\n', .274000000E+00,0.0);

%cycle4
fprintf(fid, '%10.9f %9.1f\n', .300000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .305400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .340000000E+00,ALPM_mag);
fprintf(fid, '%10.9f %9.1f\n', .374000000E+00,0.0);

%cycle5
fprintf(fid, '%10.9f %9.1f\n', .400000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .405400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .440000000E+00,ALPM_mag);
fprintf(fid, '%10.9f %9.1f\n', .474000000E+00,0.0);

%cycle6
fprintf(fid, '%10.9f %9.1f\n', .500000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .505400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .540000000E+00,ALPM_mag);
fprintf(fid, '%10.9f %9.1f\n', .574000000E+00,0.0);


%cycle7
fprintf(fid, '%10.9f %9.1f\n', .600000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .605400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .640000000E+00,ALPM_mag);
fprintf(fid, '%10.9f %9.1f\n', .674000000E+00,0.0);

fprintf(fid, '%10.9f %9.1f\n', .700000000E+00,0.0);




%Define PMPM displacements
fprintf(fid, '*DEFINE_CURVE\n');
fprintf(fid, '$ LCID SIDR SCLA SCLO OFFA OFFO\n');
fprintf(fid, '%10i %9i\n',7,0);
fprintf(fid, '$ A1 O1\n');

%cycle 1
fprintf(fid, '%10.9f %9.1f\n', .000000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .540000000E-02,0.0);
fprintf(fid, '%11.9f %13.3f\n', .400000000E-01,PMPM_mag);
fprintf(fid, '%10.9f %9.1f\n', .740000000E-01,0.0);

%cycle2
fprintf(fid, '%10.9f %9.1f\n', .100000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .105400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .140000000E+00,PMPM_mag);
fprintf(fid, '%10.9f %9.1f\n', .174000000E+00,0.0);

%cycle3
fprintf(fid, '%10.9f %9.1f\n', .200000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .205400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .240000000E+00,PMPM_mag);
fprintf(fid, '%10.9f %9.1f\n', .274000000E+00,0.0);

%cycle4
fprintf(fid, '%10.9f %9.1f\n', .300000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .305400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .340000000E+00,PMPM_mag);
fprintf(fid, '%10.9f %9.1f\n', .374000000E+00,0.0);

%cycle5
fprintf(fid, '%10.9f %9.1f\n', .400000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .405400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .440000000E+00,PMPM_mag);
fprintf(fid, '%10.9f %9.1f\n', .474000000E+00,0.0);

%cycle6
fprintf(fid, '%10.9f %9.1f\n', .500000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .505400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .540000000E+00,PMPM_mag);
fprintf(fid, '%10.9f %9.1f\n', .574000000E+00,0.0);


%cycle7
fprintf(fid, '%10.9f %9.1f\n', .600000000E+00,0.0);
fprintf(fid, '%10.9f %9.1f\n', .605400000E+00,0.0);
fprintf(fid, '%11.9f %13.3f\n', .640000000E+00,PMPM_mag);
fprintf(fid, '%10.9f %9.1f\n', .674000000E+00,0.0);

fprintf(fid, '%10.9f %9.1f\n', .700000000E+00,0.0);





% VENTRICULAR PRESSURE

% define elements for pressure load
fprintf(fid, '*LOAD_SEGMENT\n');
fprintf(fid, '$ LCID SF AT N1 N2 N3 N4\n');
for i = 1:size(element_shell,1)
fprintf(fid, '%10i %9.1i %9.1i %9i %9i %9i %9i\n',1,1,0,element_shell(i,3),element_shell(i,4),element_shell(i,5),element_shell(i,6));
end


% Define ventricular pressure
fprintf(fid, '*DEFINE_CURVE\n');
fprintf(fid, '$ LCID SIDR SCLA SCLO OFFA OFFO\n');
fprintf(fid, '%10i %9i\n',1,0);
fprintf(fid, '$ A1 O1\n');

% profile from Baxter

%fprintf(fid, '      .000000000E+00      0.0\n');
%fprintf(fid, '      .500000024E-03      0.000066\n');
%fprintf(fid, '      .130000000E-02      0.0\n');
%fprintf(fid, '      .270000007E-02      -0.0001197\n');
%fprintf(fid, '      .439999998E-02      -0.0012236\n');
%fprintf(fid, '      .620000018E-02      -0.0060914\n');
%fprintf(fid, '      .800000038E-02      -0.0106\n');
%fprintf(fid, '      .980000012E-02      -0.0131\n');
%fprintf(fid, '      .147000002E-01      -0.01523\n');
%fprintf(fid, '      .199999996E-01      -0.01608\n');
%fprintf(fid, '      .256999992E-01      -0.01523\n');
%fprintf(fid, '      .302000009E-01      -0.013526\n');
%fprintf(fid, '      .315999985E-01      -0.011145\n');
%fprintf(fid, '      .368999988E-01      0.000306\n');
%fprintf(fid, '      .399999991E-01      0.00036\n');
%fprintf(fid, '      .430999994E-01      0.0000665\n');
%fprintf(fid, '      .500000007E-01      0.0000665\n');


% profile from Lau, 2010

% cycle 1
fprintf(fid, '      .000000000E+00      0.0\n');
fprintf(fid, '      .459326000E-02      -0.000245433\n');
fprintf(fid, '      .813215600E-02      -0.00048484\n');
fprintf(fid, '      .116252650E-01      -0.00097283\n');
fprintf(fid, '      .144748200E-01      -0.00124905\n');
fprintf(fid, '      .178756890E-01      -0.0012859\n');
fprintf(fid, '      .205412086E-01      -0.0012767\n');
fprintf(fid, '      .226093818E-01      -0.001405646\n');
fprintf(fid, '      .257057481E-01      -0.00663914\n');
fprintf(fid, '      .297827882E-01      -0.01227032\n');
fprintf(fid, '      .339030220E-01      -0.014812928\n');
fprintf(fid, '      .373648563E-01      -0.015959975\n');
fprintf(fid, '      .407834190E-01      -0.01635375\n');
fprintf(fid, '      .437743886E-01      -0.01631955\n');
fprintf(fid, '      .477049963E-01      -0.01574608\n');
fprintf(fid, '      .556509040E-01      -0.0135377\n');
fprintf(fid, '      .590677461E-01      -0.01154333\n');
fprintf(fid, '      .638739087E-01      -0.00342279\n');
fprintf(fid, '      .663630691E-01      -0.00123435\n');
fprintf(fid, '      .688968097E-01      -0.00027145\n');
fprintf(fid, '      .726107453E-01      0.000174957\n');
fprintf(fid, '      .801705027E-01      -0.000035209\n');

% cycle 2
fprintf(fid, '      .100000000E+00      -0.001007081\n');
fprintf(fid, '      .111625265E+00      -0.00097283\n');
fprintf(fid, '      .114474820E+00      -0.00124905\n');
fprintf(fid, '      .117875689E+00      -0.0012859\n');
fprintf(fid, '      .120541208E+00      -0.0012767\n');
fprintf(fid, '      .122609381E+00      -0.001405646\n');
fprintf(fid, '      .125705748E+00      -0.00663914\n');
fprintf(fid, '      .129782788E+00      -0.01227032\n');
fprintf(fid, '      .133903022E+00      -0.014812928\n');
fprintf(fid, '      .137364856E+00      -0.015959975\n');
fprintf(fid, '      .140783419E+00      -0.01635375\n');
fprintf(fid, '      .143774388E+00      -0.01631955\n');
fprintf(fid, '      .147704996E+00      -0.01574608\n');
fprintf(fid, '      .155650904E+00      -0.0135377\n');
fprintf(fid, '      .159067746E+00      -0.01154333\n');
fprintf(fid, '      .163873908E+00      -0.00342279\n');
fprintf(fid, '      .166363069E+00      -0.00123435\n');
fprintf(fid, '      .168896809E+00      -0.00027145\n');
fprintf(fid, '      .172610745E+00      0.000174957\n');
fprintf(fid, '      .180170502E+00      -0.000035209\n');

% cycle 3
fprintf(fid, '      .200000000E+00      -0.001007081\n');
fprintf(fid, '      .211625265E+00      -0.00097283\n');
fprintf(fid, '      .214474820E+00      -0.00124905\n');
fprintf(fid, '      .217875689E+00      -0.0012859\n');
fprintf(fid, '      .220541208E+00      -0.0012767\n');
fprintf(fid, '      .222609381E+00      -0.001405646\n');
fprintf(fid, '      .225705748E+00      -0.00663914\n');
fprintf(fid, '      .229782788E+00      -0.01227032\n');
fprintf(fid, '      .233903022E+00      -0.014812928\n');
fprintf(fid, '      .237364856E+00      -0.015959975\n');
fprintf(fid, '      .240783419E+00      -0.01635375\n');
fprintf(fid, '      .243774388E+00      -0.01631955\n');
fprintf(fid, '      .247704996E+00      -0.01574608\n');
fprintf(fid, '      .255650904E+00      -0.0135377\n');
fprintf(fid, '      .259067746E+00      -0.01154333\n');
fprintf(fid, '      .263873908E+00      -0.00342279\n');
fprintf(fid, '      .266363069E+00      -0.00123435\n');
fprintf(fid, '      .268896809E+00      -0.00027145\n');
fprintf(fid, '      .272610745E+00      0.000174957\n');
fprintf(fid, '      .280170502E+00      -0.000035209\n');

% cycle 4
fprintf(fid, '      .300000000E+00      -0.001007081\n');
fprintf(fid, '      .311625265E+00      -0.00097283\n');
fprintf(fid, '      .314474820E+00      -0.00124905\n');
fprintf(fid, '      .317875689E+00      -0.0012859\n');
fprintf(fid, '      .320541208E+00      -0.0012767\n');
fprintf(fid, '      .322609381E+00      -0.001405646\n');
fprintf(fid, '      .325705748E+00      -0.00663914\n');
fprintf(fid, '      .329782788E+00      -0.01227032\n');
fprintf(fid, '      .333903022E+00      -0.014812928\n');
fprintf(fid, '      .337364856E+00      -0.015959975\n');
fprintf(fid, '      .340783419E+00      -0.01635375\n');
fprintf(fid, '      .343774388E+00      -0.01631955\n');
fprintf(fid, '      .347704996E+00      -0.01574608\n');
fprintf(fid, '      .355650904E+00      -0.0135377\n');
fprintf(fid, '      .359067746E+00      -0.01154333\n');
fprintf(fid, '      .363873908E+00      -0.00342279\n');
fprintf(fid, '      .366363069E+00      -0.00123435\n');
fprintf(fid, '      .368896809E+00      -0.00027145\n');
fprintf(fid, '      .372610745E+00      0.000174957\n');
fprintf(fid, '      .380170502E+00      -0.000035209\n');

% cycle 5
fprintf(fid, '      .400000000E+00      -0.001007081\n');
fprintf(fid, '      .411625265E+00      -0.00097283\n');
fprintf(fid, '      .414474820E+00      -0.00124905\n');
fprintf(fid, '      .417875689E+00      -0.0012859\n');
fprintf(fid, '      .420541208E+00      -0.0012767\n');
fprintf(fid, '      .422609381E+00      -0.001405646\n');
fprintf(fid, '      .425705748E+00      -0.00663914\n');
fprintf(fid, '      .429782788E+00      -0.01227032\n');
fprintf(fid, '      .433903022E+00      -0.014812928\n');
fprintf(fid, '      .437364856E+00      -0.015959975\n');
fprintf(fid, '      .440783419E+00      -0.01635375\n');
fprintf(fid, '      .443774388E+00      -0.01631955\n');
fprintf(fid, '      .447704996E+00      -0.01574608\n');
fprintf(fid, '      .455650904E+00      -0.0135377\n');
fprintf(fid, '      .459067746E+00      -0.01154333\n');
fprintf(fid, '      .463873908E+00      -0.00342279\n');
fprintf(fid, '      .466363069E+00      -0.00123435\n');
fprintf(fid, '      .468896809E+00      -0.00027145\n');
fprintf(fid, '      .472610745E+00      0.000174957\n');
fprintf(fid, '      .480170502E+00      -0.000035209\n');

% cycle 6
fprintf(fid, '      .500000000E+00      -0.001007081\n');
fprintf(fid, '      .511625265E+00      -0.00097283\n');
fprintf(fid, '      .514474820E+00      -0.00124905\n');
fprintf(fid, '      .517875689E+00      -0.0012859\n');
fprintf(fid, '      .520541208E+00      -0.0012767\n');
fprintf(fid, '      .522609381E+00      -0.001405646\n');
fprintf(fid, '      .525705748E+00      -0.00663914\n');
fprintf(fid, '      .529782788E+00      -0.01227032\n');
fprintf(fid, '      .533903022E+00      -0.014812928\n');
fprintf(fid, '      .537364856E+00      -0.015959975\n');
fprintf(fid, '      .540783419E+00      -0.01635375\n');
fprintf(fid, '      .543774388E+00      -0.01631955\n');
fprintf(fid, '      .547704996E+00      -0.01574608\n');
fprintf(fid, '      .555650904E+00      -0.0135377\n');
fprintf(fid, '      .559067746E+00      -0.01154333\n');
fprintf(fid, '      .563873908E+00      -0.00342279\n');
fprintf(fid, '      .566363069E+00      -0.00123435\n');
fprintf(fid, '      .568896809E+00      -0.00027145\n');
fprintf(fid, '      .572610745E+00      0.000174957\n');
fprintf(fid, '      .580170502E+00      -0.000035209\n');

% cycle 7
fprintf(fid, '      .600000000E+00      -0.001007081\n');
fprintf(fid, '      .611625265E+00      -0.00097283\n');
fprintf(fid, '      .614474820E+00      -0.00124905\n');
fprintf(fid, '      .617875689E+00      -0.0012859\n');
fprintf(fid, '      .620541208E+00      -0.0012767\n');
fprintf(fid, '      .622609381E+00      -0.001405646\n');
fprintf(fid, '      .625705748E+00      -0.00663914\n');
fprintf(fid, '      .629782788E+00      -0.01227032\n');
fprintf(fid, '      .633903022E+00      -0.014812928\n');
fprintf(fid, '      .637364856E+00      -0.015959975\n');
fprintf(fid, '      .640783419E+00      -0.01635375\n');
fprintf(fid, '      .643774388E+00      -0.01631955\n');
fprintf(fid, '      .647704996E+00      -0.01574608\n');
fprintf(fid, '      .655650904E+00      -0.0135377\n');
fprintf(fid, '      .659067746E+00      -0.01154333\n');
fprintf(fid, '      .663873908E+00      -0.00342279\n');
fprintf(fid, '      .666363069E+00      -0.00123435\n');
fprintf(fid, '      .668896809E+00      -0.00027145\n');
fprintf(fid, '      .672610745E+00      0.000174957\n');
fprintf(fid, '      .680170502E+00      -0.000035209\n');

fprintf(fid, '      .700000000E+00      -0.001007081\n');



% ATRIAL PRESSURE

% define elements for pressure load
fprintf(fid, '*LOAD_SEGMENT\n');
fprintf(fid, '$ LCID SF AT N1 N2 N3 N4\n');
for i = 1:size(element_shell,1)
fprintf(fid, '%10i %9.1i %9.1i %9i %9i %9i %9i\n',2,1,0,element_shell(i,3),element_shell(i,4),element_shell(i,5),element_shell(i,6));
end


% Define atrial pressure
fprintf(fid, '*DEFINE_CURVE\n');
fprintf(fid, '$ LCID SIDR SCLA SCLO OFFA OFFO\n');
fprintf(fid, '%10i %9i\n',2,0);
fprintf(fid, '$ A1 O1\n');


% profile from Lau, 2010

%cycle 1
fprintf(fid, '      .000000000E+00      0.0006865642\n');
fprintf(fid, '      .489783363E-02      0.0007365468\n');
fprintf(fid, '      .863712132E-02      0.0011194244\n');
fprintf(fid, '      .129998055E-01      0.001818568\n');
fprintf(fid, '      .177360071E-01      0.001985067\n');
fprintf(fid, '      .212256555E-01      0.001851939\n');
fprintf(fid, '      .231778848E-01      0.001344278\n');
fprintf(fid, '      .258371394E-01      0.0019019201\n');
fprintf(fid, '      .290359339E-01      0.001710531\n');
fprintf(fid, '      .329819610E-01      0.0007285\n');
fprintf(fid, '      .356403881E-01      0.00013762\n');
fprintf(fid, '      .356403881E-01      0.000137619\n');
fprintf(fid, '      .411243621E-01      0.000262512\n');
fprintf(fid, '      .468992800E-01      0.000570506\n');
fprintf(fid, '      .510212593E-01      0.0006807138\n');
fprintf(fid, '      .553547480E-01      0.0008924874\n');
fprintf(fid, '      .599525330E-01      0.0011995426\n');
fprintf(fid, '      .649202828E-01      0.001570121\n');
fprintf(fid, '      .676154446E-01      0.00162308\n');
fprintf(fid, '      .700985605E-01      0.000755007\n');
fprintf(fid, '      .727934096E-01      0.0003739173\n');
fprintf(fid, '      .770739611E-01      0.000458652\n');
fprintf(fid, '      .831513913E-01      0.000723375\n');

%cycle 2
fprintf(fid, '      .100000000E+00      0.001655156\n');
fprintf(fid, '      .112999805E+00      0.001818568\n');
fprintf(fid, '      .117736007E+00      0.001985067\n');
fprintf(fid, '      .121225655E+00      0.001851939\n');
fprintf(fid, '      .123177884E+00      0.001344278\n');
fprintf(fid, '      .125837139E+00      0.0019019201\n');
fprintf(fid, '      .129035933E+00      0.001710531\n');
fprintf(fid, '      .132981961E+00      0.0007285\n');
fprintf(fid, '      .135640388E+00      0.00013762\n');
fprintf(fid, '      .135640388E+00      0.000137619\n');
fprintf(fid, '      .141124362E+00      0.000262512\n');
fprintf(fid, '      .146899280E+00      0.000570506\n');
fprintf(fid, '      .151021259E+00      0.0006807138\n');
fprintf(fid, '      .155354748E+00      0.0008924874\n');
fprintf(fid, '      .159952533E+00      0.0011995426\n');
fprintf(fid, '      .164920282E+00      0.001570121\n');
fprintf(fid, '      .167615444E+00      0.00162308\n');
fprintf(fid, '      .170098560E+00      0.000755007\n');
fprintf(fid, '      .172793409E+00      0.0003739173\n');
fprintf(fid, '      .177073961E+00      0.000458652\n');
fprintf(fid, '      .183151391E+00      0.000723375\n');


%cycle 3
fprintf(fid, '      .200000000E+00      0.001655156\n');
fprintf(fid, '      .212999805E+00      0.001818568\n');
fprintf(fid, '      .217736007E+00      0.001985067\n');
fprintf(fid, '      .221225655E+00      0.001851939\n');
fprintf(fid, '      .223177884E+00      0.001344278\n');
fprintf(fid, '      .225837139E+00      0.0019019201\n');
fprintf(fid, '      .229035933E+00      0.001710531\n');
fprintf(fid, '      .232981961E+00      0.0007285\n');
fprintf(fid, '      .235640388E+00      0.00013762\n');
fprintf(fid, '      .235640388E+00      0.000137619\n');
fprintf(fid, '      .241124362E+00      0.000262512\n');
fprintf(fid, '      .246899280E+00      0.000570506\n');
fprintf(fid, '      .251021259E+00      0.0006807138\n');
fprintf(fid, '      .255354748E+00      0.0008924874\n');
fprintf(fid, '      .259952533E+00      0.0011995426\n');
fprintf(fid, '      .264920282E+00      0.001570121\n');
fprintf(fid, '      .267615444E+00      0.00162308\n');
fprintf(fid, '      .270098560E+00      0.000755007\n');
fprintf(fid, '      .272793409E+00      0.0003739173\n');
fprintf(fid, '      .277073961E+00      0.000458652\n');
fprintf(fid, '      .283151391E+00      0.000723375\n');


%cycle 4
fprintf(fid, '      .300000000E+00      0.001655156\n');
fprintf(fid, '      .312999805E+00      0.001818568\n');
fprintf(fid, '      .317736007E+00      0.001985067\n');
fprintf(fid, '      .321225655E+00      0.001851939\n');
fprintf(fid, '      .323177884E+00      0.001344278\n');
fprintf(fid, '      .325837139E+00      0.0019019201\n');
fprintf(fid, '      .329035933E+00      0.001710531\n');
fprintf(fid, '      .332981961E+00      0.0007285\n');
fprintf(fid, '      .335640388E+00      0.00013762\n');
fprintf(fid, '      .335640388E+00      0.000137619\n');
fprintf(fid, '      .341124362E+00      0.000262512\n');
fprintf(fid, '      .346899280E+00      0.000570506\n');
fprintf(fid, '      .351021259E+00      0.0006807138\n');
fprintf(fid, '      .355354748E+00      0.0008924874\n');
fprintf(fid, '      .359952533E+00      0.0011995426\n');
fprintf(fid, '      .364920282E+00      0.001570121\n');
fprintf(fid, '      .367615444E+00      0.00162308\n');
fprintf(fid, '      .370098560E+00      0.000755007\n');
fprintf(fid, '      .372793409E+00      0.0003739173\n');
fprintf(fid, '      .377073961E+00      0.000458652\n');
fprintf(fid, '      .383151391E+00      0.000723375\n');


%cycle 5
fprintf(fid, '      .400000000E+00      0.001655156\n');
fprintf(fid, '      .412999805E+00      0.001818568\n');
fprintf(fid, '      .417736007E+00      0.001985067\n');
fprintf(fid, '      .421225655E+00      0.001851939\n');
fprintf(fid, '      .423177884E+00      0.001344278\n');
fprintf(fid, '      .425837139E+00      0.0019019201\n');
fprintf(fid, '      .429035933E+00      0.001710531\n');
fprintf(fid, '      .432981961E+00      0.0007285\n');
fprintf(fid, '      .435640388E+00      0.00013762\n');
fprintf(fid, '      .435640388E+00      0.000137619\n');
fprintf(fid, '      .441124362E+00      0.000262512\n');
fprintf(fid, '      .446899280E+00      0.000570506\n');
fprintf(fid, '      .451021259E+00      0.0006807138\n');
fprintf(fid, '      .455354748E+00      0.0008924874\n');
fprintf(fid, '      .459952533E+00      0.0011995426\n');
fprintf(fid, '      .464920282E+00      0.001570121\n');
fprintf(fid, '      .467615444E+00      0.00162308\n');
fprintf(fid, '      .470098560E+00      0.000755007\n');
fprintf(fid, '      .472793409E+00      0.0003739173\n');
fprintf(fid, '      .477073961E+00      0.000458652\n');
fprintf(fid, '      .483151391E+00      0.000723375\n');


%cycle 6
fprintf(fid, '      .500000000E+00      0.001655156\n');
fprintf(fid, '      .512999805E+00      0.001818568\n');
fprintf(fid, '      .517736007E+00      0.001985067\n');
fprintf(fid, '      .521225655E+00      0.001851939\n');
fprintf(fid, '      .523177884E+00      0.001344278\n');
fprintf(fid, '      .525837139E+00      0.0019019201\n');
fprintf(fid, '      .529035933E+00      0.001710531\n');
fprintf(fid, '      .532981961E+00      0.0007285\n');
fprintf(fid, '      .535640388E+00      0.00013762\n');
fprintf(fid, '      .535640388E+00      0.000137619\n');
fprintf(fid, '      .541124362E+00      0.000262512\n');
fprintf(fid, '      .546899280E+00      0.000570506\n');
fprintf(fid, '      .551021259E+00      0.0006807138\n');
fprintf(fid, '      .555354748E+00      0.0008924874\n');
fprintf(fid, '      .559952533E+00      0.0011995426\n');
fprintf(fid, '      .564920282E+00      0.001570121\n');
fprintf(fid, '      .567615444E+00      0.00162308\n');
fprintf(fid, '      .570098560E+00      0.000755007\n');
fprintf(fid, '      .572793409E+00      0.0003739173\n');
fprintf(fid, '      .577073961E+00      0.000458652\n');
fprintf(fid, '      .583151391E+00      0.000723375\n');

% cycle 7
fprintf(fid, '      .600000000E+00      0.001655156\n');
fprintf(fid, '      .612999805E+00      0.001818568\n');
fprintf(fid, '      .617736007E+00      0.001985067\n');
fprintf(fid, '      .621225655E+00      0.001851939\n');
fprintf(fid, '      .623177884E+00      0.001344278\n');
fprintf(fid, '      .625837139E+00      0.0019019201\n');
fprintf(fid, '      .629035933E+00      0.001710531\n');
fprintf(fid, '      .632981961E+00      0.0007285\n');
fprintf(fid, '      .635640388E+00      0.00013762\n');
fprintf(fid, '      .635640388E+00      0.000137619\n');
fprintf(fid, '      .641124362E+00      0.000262512\n');
fprintf(fid, '      .646899280E+00      0.000570506\n');
fprintf(fid, '      .651021259E+00      0.0006807138\n');
fprintf(fid, '      .655354748E+00      0.0008924874\n');
fprintf(fid, '      .659952533E+00      0.0011995426\n');
fprintf(fid, '      .664920282E+00      0.001570121\n');
fprintf(fid, '      .667615444E+00      0.00162308\n');
fprintf(fid, '      .670098560E+00      0.000755007\n');
fprintf(fid, '      .672793409E+00      0.0003739173\n');
fprintf(fid, '      .677073961E+00      0.000458652\n');
fprintf(fid, '      .683151391E+00      0.000723375\n');

fprintf(fid, '      .700000000E+00      0.001655156\n');



%%%%%%%%%%%

%define engineering stress-strain curve for marginal chordae
fprintf(fid, '*DEFINE_CURVE\n');
fprintf(fid, '$ LCID SIDR SCLA SCLO OFFA OFFO\n');
fprintf(fid, '%10i %9i\n',3,0);
fprintf(fid, '$ A1 O1\n');


% data from Millard, 2011 (porcine MV, marginal chordae)
%fprintf(fid, '      .000000000E+00      0.0\n');
%fprintf(fid, '      .100000000E+00      0.0\n');
%fprintf(fid, '      .150000000E+00      0.5\n');
%fprintf(fid, '      .200000000E+00      2.0\n');
%fprintf(fid, '      .250000000E+00      3.5\n');


% data from Kunzelman (porcine MV, marginal chordae)
fprintf(fid, '      .000000000E+00      0.0\n');
fprintf(fid, '      .250000000E-01      0.08\n');
fprintf(fid, '      .500000000E-01      0.5\n');
fprintf(fid, '      .750000000E-01      1.2\n');
fprintf(fid, '      .100000000E+00      2.0\n');





% data from Zuo, 2014 (human MV, marginal chordae, master thesis)
%fprintf(fid, '      .000000000E+00      0.0\n');
%fprintf(fid, '      .921000000E-02      0.264\n');
%fprintf(fid, '      .184000000E-01      0.738\n');
%fprintf(fid, '      .301000000E-01      1.74\n');
%fprintf(fid, '      .394000000E-01      2.63\n');
%fprintf(fid, '      .480000000E-01      3.79\n');
%fprintf(fid, '      .561000000E-01      5.15\n');
%fprintf(fid, '      .666000000E-01      7.15\n');
%fprintf(fid, '      .740000000E-01      8.56\n');
%fprintf(fid, '      .808000000E-01      9.98\n');
%fprintf(fid, '      .908000000E-01      12.0\n');
%fprintf(fid, '      .113800000E+00      18.0\n');
%fprintf(fid, '      .124000000E+00      20.2\n');
%fprintf(fid, '      .130500000E+00      22.2\n');
%fprintf(fid, '      .136000000E+00      24.1\n');



%define engineering stress-strain curve for strut chordae
fprintf(fid, '*DEFINE_CURVE\n');
fprintf(fid, '$ LCID SIDR SCLA SCLO OFFA OFFO\n');
fprintf(fid, '%10i %9i\n',4,0);
fprintf(fid, '$ A1 O1\n');

% data from Kunzelman (porcine MV, marginal chordae - scaled by 0.76)
fprintf(fid, '      .000000000E+00      0.0\n');
fprintf(fid, '      .250000000E-01      0.0608\n');
fprintf(fid, '      .500000000E-01      0.38\n');
fprintf(fid, '      .750000000E-01      0.912\n');
fprintf(fid, '      .100000000E+00      1.52\n');




% PM tip displacement constraint

%fprintf(fid, '*BOUNDARY_SPC_NODE\n');
%fprintf(fid, '$ NID/NSID CID DOFX DOFY DOFZ DOFRX DOFRY DOFRZ\n');
%fprintf(fid, '%10i %9i %9i %9i %9i\n',ALPM_nodepos,0,1,1,1); % no displacements

%fprintf(fid, '*BOUNDARY_SPC_NODE\n');
%fprintf(fid, '$ NID/NSID CID DOFX DOFY DOFZ DOFRX DOFRY DOFRZ\n');
%fprintf(fid, '%10i %9i %9i %9i %9i\n',PMPM_nodepos,0,1,1,1); % no displacements



% Contact for leaflets
fprintf(fid, '*SET_PART_LIST\n');
fprintf(fid, ' 1\n');
fprintf(fid, ' 1,2,5,6,7\n');

%fprintf(fid, '*CONTACT_AUTOMATIC_GENERAL\n');
%fprintf(fid, '$ SSID MSID SSTYP\n');
%fprintf(fid, '%10i %9i %9i\n',1,0,2);
%fprintf(fid, '$ FS FD DC VC VDC PENCHK BT DT\n');
%fprintf(fid, '%10i %9i %9i %9i %9i %9i %9i %9.2E\n\n',0,0,0,0,20,0,0,1E+20);

%fprintf(fid, '*SET_SEGMENT\n');
%fprintf(fid, '$ SID\n');
%fprintf(fid, '%10i\n',1);
%for i = 1:length(element_shell)
%fprintf(fid, '%10i %9i %9i %9i \n',element_shell(i,3),element_shell(i,4),element_shell(i,5),element_shell(i,6));
%end

%Contact management between atrial surfaces
fprintf(fid, '*CONTACT_AUTOMATIC_SINGLE_SURFACE\n');
fprintf(fid, '$ SSID MSID SSTYP MSTYP SBOXID MBOXID SPR MPR\n');
fprintf(fid, '%10i %9i %9i %9i %9i %9i %9i %9i \n',1,0,2,0,0,0,1,0);
fprintf(fid, '%10i %9i %9i %9i %9i %9i %9i %9.2E \n\n',0,0,0,0,20,0,0,1E+20);
fprintf(fid, '$\n');
fprintf(fid, '$\n');
fprintf(fid, '$\n');
fprintf(fid, '$ SOFT SOFSCL LCIDAB MAXPAR SBOPT DEPTH BSORT FRCFRQ\n');
fprintf(fid, ' 2,0.1,0,1.025,2,3, ,1\n');



%fprintf(fid, '*CONTACT_AUTOMATIC_SURFACE_TO_SURFACE\n');
%fprintf(fid, '$ SSID MSID SSTYP MSTYP SBOXID MBOXID SPR MPR\n');
%fprintf(fid, '%10i %9i %9i %9i %9i %9i %9i %9i \n',1,1,2,2,0,0,1,1);
%fprintf(fid, '%10i %9i %9i %9i %9i %9i %9i %9.2E \n\n',0,0,0,0,20,0,0,1E+20);
%fprintf(fid, '$\n');
%fprintf(fid, '$\n');
%fprintf(fid, '$\n');
%fprintf(fid, '$ SOFT SOFSCL LCIDAB MAXPAR SBOPT DEPTH BSORT FRCFRQ\n');
%fprintf(fid, ' 0,0.1,0,1.025,2,3, ,1\n');

% Create contact condition to measure contact forces as output
fprintf(fid, '*CONTACT_FORCE_TRANSDUCER_PENALTY\n');
fprintf(fid, '$ SSID MSID SSTYP MSTYP SBOXID MBOXID SPR MPR\n');
fprintf(fid, '%10i %9i %9i %9i %9i %9i %9i %9i \n',1,1,2,2,0,0,1,1);
fprintf(fid, '%10i %9i %9i %9i %9i %9i %9i %9.2E \n\n',0,0,0,0,20,0,0,1E+20);



% Contact between chordae insertion nodes and leaflet mesh

% set of free edge elements
%fprintf(fid, '*SET_SEGMENT\n');
%fprintf(fid, '$ SID\n');
%fprintf(fid, '%10i\n',2);
%for i = 1:length(fe_el)
%fprintf(fid, '%10i %9i %9i %9i \n',element_shell(fe_el(i),3),element_shell(fe_el(i),4),element_shell(fe_el(i),5),element_shell(fe_el(i),6));
%end

% set of insertion nodes
%fprintf(fid, '*SET_NODE\n');
%fprintf(fid, '$ SID\n');
%fprintf(fid, '%10i\n',3);

%for i = 1:length(attach_pos_AL)   
%fprintf(fid, '%8i\n',attach_pos_AL(i));
%end

%for i = 1:length(attach_pos_PL)   
%fprintf(fid, '%8i\n',attach_pos_PL(i));
%end


%fprintf(fid, '$\n');

%fprintf(fid, '*CONTACT_SPOTWELD\n');
%fprintf(fid, '$ SSID MSID SSTYP MSTYP SBOXID MBOXID SPR MPR\n');
%fprintf(fid, '%10i %9i %9i %9i %9i %9i %9i %9i \n',3,2,4,0,0,0,0,1);
%fprintf(fid, '%10i %9i %9i %9i %9i %9i %9i %9.2E \n\n',0,0,0,0,20,0,0,1E+20);



% end writing file
fprintf(fid, '*END\n');

fclose('all');

%----------- END ----------------------------------------------------------