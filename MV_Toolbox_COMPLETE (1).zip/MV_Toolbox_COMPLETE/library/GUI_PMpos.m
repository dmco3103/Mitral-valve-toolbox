%% GUI for the MV toolbox
% - Input all dimensions needed to build the model

%clc; clear all; close all;

function [answer] = GUI_PMpos()

dlg_title = 'Papillary muscle displacement';

% 1. select the type of model
prompt = {'Do you want to recreate papillary muscle displacement? Y or N'};
num_lines = 1;
defaultans = {'N'};
answer2 = inputdlg(prompt,dlg_title,num_lines,defaultans);

if(answer2{1,1}=='N')

    answer = 'no displacement';
      
elseif(answer2{1,1}=='Y')

dlg_title = 'Type of displacement';

prompt = {'Select the type of papilary muscle displacement: 0 for medial/lateral, 1 for apical and 2 for left ventricular dilation derived'};
num_lines = 1;
defaultans = {'0'};
answer4 = inputdlg(prompt,dlg_title,num_lines,defaultans);
  

if str2num(answer4{1,1})==0

prompt = {'Select 0 for symmetric tethering, 1 for PMPM tethering and 2 for ALPM tethering'};
num_lines = 1;
defaultans = {'0'};
answer5 = inputdlg(prompt,dlg_title,num_lines,defaultans);

if str2num(answer5{1,1})==0
  
      answer = 'symmetric medial';
          
      
elseif str2num(answer5{1,1})==1
  
      answer = 'posterior medial';
      
elseif str2num(answer5{1,1})==2
  
answer = 'anterior medial';
    
end        
 


elseif str2num(answer4{1,1})==1

prompt = {'Select 1 for posterior tethering and 2 for anterior tethering'};
num_lines = 1;
defaultans = {'0'};
answer6 = inputdlg(prompt,dlg_title,num_lines,defaultans);

          
if str2num(answer6{1,1})==1
  
      answer = 'posterior apical';
      
elseif str2num(answer6{1,1})==2
 
      answer = 'anterior apical';

end       
  

elseif str2num(answer4{1,1})==2

prompt = {'Select 0 for posterior dilation, 1 for anterior dilation and 2 for dilation on both sides'};
num_lines = 1;
defaultans = {'0'};
answer7 = inputdlg(prompt,dlg_title,num_lines,defaultans);

if str2num(answer7{1,1})==0
  
      answer = 'posterior dilation';

    
elseif str2num(answer7{1,1})==1

      answer = 'anterior dilation';


elseif str2num(answer7{1,1})==2
  
      answer = 'total dilation';
 
end
      
else
     error('Assign the flag for average dimensions (0) or subject-specific dimensions (1)');
end
end
end



