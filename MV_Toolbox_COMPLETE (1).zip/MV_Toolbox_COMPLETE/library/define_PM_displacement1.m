function [ALPM,PMPM] = define_PM_displacement1(answer,ALPM,PMPM,inter_PM_w)

if strcmpi(answer, 'no displacement')

ALPM = ALPM;
PMPM = PMPM;


elseif strcmpi(answer, 'symmetric medial') || strcmpi(answer, 'posterior medial') || strcmpi(answer, 'anterior medial')

    % control equations to check model inter-PM distance
i_PM_m = sqrt((ALPM(1) - PMPM(1))^2 +...
    (ALPM(2) - PMPM(2))^2 +...
    (ALPM(3) - PMPM(3))^2);
    
    
%% for medial PM displacement - symmetric tethering (no dilation)

i_PM_w = inter_PM_w; 
i_PM_f = 1;
tol = 1e-2 ;


% choose which PM suffers medial displacement

model_type = answer;

switch model_type 
    
     case 'symmetric medial'
        PM_medial1 = ALPM;
        PM_medial2 = PMPM;
    
     case 'anterior medial'
        PM_medial = ALPM;
        PM_other = PMPM;
        
     case 'posterior medial' 
        PM_medial = PMPM;
        PM_other = ALPM;
end


% symmetric medial displacement
if strcmpi(answer, 'symmetric medial')

if i_PM_w > i_PM_m
  
while i_PM_m < i_PM_w

x_m1 = PM_medial1(1);
y_m1 = PM_medial1(2);
x_m2 = PM_medial2(1);
y_m2 = PM_medial2(2);


x_m1 = i_PM_f*x_m1;
%y_m1 = i_PM_f*y_m1;
x_m2 = i_PM_f*x_m2;
%y_m2 = i_PM_f*y_m2;

   
% calculate inter-PM distance now
i_PM_m = sqrt((x_m1 - x_m2)^2 +...
    (y_m1 - y_m2)^2 +...
    (PM_medial1(3) - PM_medial2(3))^2);


% change scaling factor for inter-PM distance and start again
i_PM_f = i_PM_f + tol;

end


elseif i_PM_w < i_PM_m
   
while i_PM_m > i_PM_w

x_m1 = PM_medial1(1);
y_m1 = PM_medial1(2);
x_m2 = PM_medial2(1);
y_m2 = PM_medial2(2);


x_m1 = i_PM_f*x_m1;
%y_m1 = i_PM_f*y_m1;
x_m2 = i_PM_f*x_m2;
%y_m2 = i_PM_f*y_m2;

   
% calculate inter-PM distance now
i_PM_m = sqrt((x_m1 - x_m2)^2 +...
    (y_m1 - y_m2)^2 +...
    (PM_medial1(3) - PM_medial2(3))^2);
    
% change scaling factor for commissural boundary and start again
i_PM_f = i_PM_f - tol;
     
end

end


end



% asymmetric medial displacement
if strcmpi(answer, 'posterior medial') || strcmpi(answer, 'anterior medial')
    
if i_PM_w > i_PM_m
  
while i_PM_m < i_PM_w

x = PM_medial(1);
y = PM_medial(2);
    
x = i_PM_f*x;
%y = i_PM_f*y;


% calculate inter-PM distance now
i_PM_m = sqrt((PM_other(1) - x)^2 +...
    (PM_other(2) - y)^2 +...
    (PM_other(3) - PM_medial(3))^2);


% change scaling factor for inter-PM distance and start again
i_PM_f = i_PM_f + tol;

end


elseif i_PM_w < i_PM_m
   
while i_PM_m > i_PM_w

x = PM_medial(1);
y = PM_medial(2);
    
x = i_PM_f*x;
%y = i_PM_f*y;


% calculate inter-PM distance now
i_PM_m = sqrt((PM_other(1) - x)^2 +...
    (PM_other(2) - y)^2 +...
    (PM_other(3) - PM_medial(3))^2);

% change scaling factor for commissural boundary and start again
i_PM_f = i_PM_f - tol;
     
end

end

end


if strcmpi(model_type, 'symmetric medial')

        ALPM(1) = x_m1;
        ALPM(2) = y_m1; 
        PMPM(1) = x_m2;
        PMPM(2) = y_m2; 


elseif strcmpi(model_type, 'anterior medial')

        ALPM(1) = x;
        ALPM(2) = y; 
        
elseif strcmpi(model_type, 'posterior medial')
    
        PMPM(1) = x;
        PMPM(2) = y;   
end
    
    



elseif strcmpi(answer, 'posterior apical') || strcmpi(answer, 'anterior apical')

    % control equations to check model inter-PM distance
i_PM_m = sqrt((ALPM(1) - PMPM(1))^2 +...
    (ALPM(2) - PMPM(2))^2 +...
    (ALPM(3) - PMPM(3))^2);

%% for apical PM displacement - apical tethering (no dilation)
% - variation of z coordinate

i_PM_w = inter_PM_w;
i_PM_f = 1;
tol = 1e-2 ;


% choose which PM suffers apical displacement

model_type = answer;

switch model_type 
    
     case 'anterior apical'
        PM_apical = ALPM;
        PM_other = PMPM;
        
     case 'posterior apical' 
        PM_apical = PMPM;
        PM_other = ALPM;
end


    
if i_PM_w > i_PM_m
  
while i_PM_m < i_PM_w

z = PM_apical(3);     
    
z = i_PM_f*z;

% calculate inter-PM distance now
i_PM_m = sqrt((PM_other(1) - PM_apical(1))^2 +...
    (PM_other(2) - PM_apical(2))^2 +...
    (PM_other(3) - z)^2);


% change scaling factor for inter-PM distance and start again
i_PM_f = i_PM_f + tol;

end


elseif i_PM_w < i_PM_m
   
while i_PM_m > i_PM_w

z = PM_apical(3); 
      
z = i_PM_f*z;

% calculate inter-PM distance now
i_PM_m = sqrt((PM_other(1) - PM_apical(1))^2 +...
    (PM_other(2) - PM_apical(2))^2 +...
    (PM_other(3) - z)^2);

% change scaling factor for commissural boundary and start again
i_PM_f = i_PM_f - tol;
     
end

end

end


if strcmpi(model_type, 'anterior apical')

        ALPM(3) = z;
        
elseif strcmpi(model_type, 'posterior apical')
    
        PMPM(3) = z;

end


end


