function [ALPM,PMPM] = define_PM_displacement3D(answer,ALPM,PMPM,LV,w_w,l_w,CW_w,ann_s)

ALPM_bef = ALPM;
PMPM_bef = PMPM;


%% for LV dilation (medial + apical PM displacement)

LV(:,2) = ALPM(2);

% LV length is measured from MV annular plane to apex
z1 = max(LV(:,3));
z2 = mean(ann_s(:,3));

if z1<z2
LV(:,3) = LV(:,3)+abs(z2-z1);
else
LV(:,3) = LV(:,3)-abs(z2-z1);
end

max_z = max(LV(:,3));
min_z = min(LV(:,3));

% respect width from MV
x1 = LV(1,1);
x2 = LV(end,1);
x_m = abs(x1-x2);

%LV(:,1) = LV(:,1)*(CW_w/x_m);


% LV width (find scaling factor)

%w_location = l_w/2; % based on info from (Donato et al., 2009)
%w_points = [];

%for i=1:length(LV)
 %  if abs(LV(i,3)-LV(1,3))>w_location
  %     w_points = [w_points; LV(i,:)];
  % end
%end

%w_points = [w_points(1,:); w_points(end,:)];

%w_m = abs(w_points(1,1) - w_points(end,1));

% accounting for misalignment of MV plane with LV plane...
w_f = (0.8*w_w)/x_m; %assuming this width is at the equatorial plane diameter (i.e., beginning of LV shape)


% LV length (find scaling factor)
l_m = abs(max_z-min_z);

l_f = l_w/l_m;



%% Locate PM base range
% locate PM base (Park, 2019 - NOT SURE IF CORRECT...)
d = l_w/5;
line_up = -d;

ALPM_base = [];
PMPM_base = [];

% Define range of PM normal lengths (Saha, 2018)
l_PM_min = 26 - 8.8;
l_PM_max = 26 + 8.8;


% Obtain acceptable range for PM base
for i=1:length(LV)/2
   if LV(i,3) < line_up && norm(LV(i,:)-ALPM) > l_PM_min && norm(LV(i,:)-ALPM) < l_PM_max 
    ALPM_base = [ALPM_base; LV(i,:)];
   end
end

for i=length(LV)/2:length(LV)
   if LV(i,3) < line_up && norm(LV(i,:)-PMPM) > l_PM_min && norm(LV(i,:)-PMPM) < l_PM_max 
    PMPM_base = [PMPM_base; LV(i,:)];
   end
end

ALPM_base1 = ALPM_base(ceil(length(ALPM_base)/2),:);
PMPM_base1 = PMPM_base(ceil(length(PMPM_base)/2),:);





%% Create 3D baseline shape of the LV

LV = LV(1:100,:);

cPar.closeLoopOpt=1;
cPar.numSteps=[]; %If empty the number of steps is derived from point spacing of input curve
cPar.w=[0 0 1];
[F_LV,V_LV,C_LV]=polyRevolve(LV,cPar);

% save initial LV shape for plotting
F_LV_i = F_LV;
V_LV_i = V_LV;
C_LV_i = C_LV;


% find PM base on the 3D shape
ALPM_base3D_pos = []; % I just need one, because ALPM and PMPM are symmetrical

ALPM_base3D_pos_all = []; 

for i=1:length(V_LV)
    if norm(V_LV(i,:)-ALPM_base1) < 0.0001
    ALPM_base3D_pos = [ALPM_base3D_pos; i];
    end
end

for k=1:length(ALPM_base)
for i=1:length(V_LV)
    if norm(V_LV(i,:)-ALPM_base(k,:)) < 0.0001
    ALPM_base3D_pos_all = [ALPM_base3D_pos_all; i];
    end
end
end

ALPM_base3D_pos_all2 = [];

for i=1:2:length(ALPM_base3D_pos_all)
    
ALPM_base3D_pos_all2 = [ALPM_base3D_pos_all2; ALPM_base3D_pos_all(i)];
end
    
    

ALPM_base3D_pos = ALPM_base3D_pos(1,:);

%% Parameterize

% place top LV at the x,y,z origin
top_LV = [];

for i=1:length(V_LV)
    if V_LV(i,3) == V_LV(1,3)
        top_LV = [top_LV; V_LV(i,:)];
    end
end

% centroid and translation vector
C = [mean(top_LV(:,1)) mean(top_LV(:,2)) mean(top_LV(:,3))];

t_C = [-C(1) -C(2) -C(3)];

V_LV(:,1) = t_C(1) + V_LV(:,1);
V_LV(:,2) = t_C(2) + V_LV(:,2);
V_LV(:,3) = t_C(3) + V_LV(:,3);


%% Transform the complete LV (width and length)
V_LV(:,1) = V_LV(:,1)*w_f;
V_LV(:,2) = V_LV(:,2)*w_f;
V_LV(:,3) = V_LV(:,3)*l_f;

t_C2 = [C(1) C(2) C(3)];

V_LV(:,1) = t_C2(1) + V_LV(:,1);
V_LV(:,2) = t_C2(2) + V_LV(:,2);
V_LV(:,3) = t_C2(3) + V_LV(:,3);


% change in PM base coordinates after scaling the LV
ALPM_base_after = V_LV(ALPM_base3D_pos,:);

ALPM_base_after_all = V_LV(ALPM_base3D_pos_all2,:);

PMPM_base_after = [-ALPM_base_after_all(:,1) ALPM_base_after_all(:,2) ALPM_base_after_all(:,3)];

%% Choose the wanted case

t = [ALPM_base_after(1)-ALPM_base1(1) ALPM_base_after(2)-ALPM_base1(2) ALPM_base_after(3)-ALPM_base1(3)];

n1 = norm(t);


%%
if n1 > 8.8 % value based on average PM length by (Saha, 2018); only proceed if displacement is stronger than SD for PM length

% then, adapt to each case

model_type = answer;

switch model_type 
    
     case 'anterior dilation' % ALPM suffers displacement

ALPM(1) = t(1) + ALPM(1);
ALPM(2) = t(2) + ALPM(2);
ALPM(3) = t(3) + ALPM(3);
    
    
     case 'posterior dilation' % PMPM suffers displacement

t(1) = -t(1);
         
PMPM(1) = t(1) + PMPM(1);
PMPM(2) = t(2) + PMPM(2);
PMPM(3) = t(3) + PMPM(3);
 

     case 'total dilation' % PMPM and ALPM suffer equal displacement
        
ALPM(1) = t(1) + ALPM(1);
ALPM(2) = t(2) + ALPM(2);
ALPM(3) = t(3) + ALPM(3);

t(1) = -t(1);

PMPM(1) = t(1) + PMPM(1);
PMPM(2) = t(2) + PMPM(2);
PMPM(3) = t(3) + PMPM(3);

end

end

%% plots
ann_include = [-ann_s(:,1) ann_s(:,2) ann_s(:,3)];
ann_include = flipud(ann_include);
ann_s2 = [ann_s; ann_include];

LV_include = [-LV(:,1) LV(:,2) LV(:,3)];
LV_include = flipud(LV_include);
LV_2 = [LV; LV_include];


fontSize=20;

if strcmpi(answer, 'anterior dilation') 
    
figure;
title('Papillary muscle displacement (2D display)','FontSize',fontSize);
xlabel('X axis','FontSize',fontSize);ylabel('Y axis','FontSize',fontSize); zlabel('Z axis','FontSize',fontSize);

hold on;

scatter3(ann_s2(:,1),ann_s2(:,2),ann_s2(:,3),'k','filled');

scatter3(PMPM_bef(:,1),PMPM_bef(:,2),PMPM_bef(:,3),'k','LineWidth',2);
scatter3(ALPM_bef(:,1),ALPM_bef(:,2),ALPM_bef(:,3),'r','LineWidth',2);
scatter3(ALPM(:,1),ALPM(:,2),ALPM(:,3),'filled','m');

%scatter3(LV_bef(:,1),LV_bef(:,2),LV_bef(:,3));
scatter3(LV_2(:,1),LV_2(:,2),LV_2(:,3));

scatter3(ALPM_base(:,1),ALPM_base(:,2),ALPM_base(:,3),'filled');

scatter3(ALPM_base_after_all(:,1),ALPM_base_after_all(:,2),ALPM_base_after_all(:,3),'filled');


scatter3(PMPM_base(:,1),PMPM_base(:,2),PMPM_base(:,3),'filled');


lgd = legend;
lgd.FontSize = 20;
legend(...
    'Mitral annulus',...
    'PMPM tip',...
    'ALPM tip: before',...
    'ALPM tip: after',...
    'LV 2D profile: before',...
    'ALPM base: before',...
    'ALPM base: after',...
    'PMPM base');


axis equal; view(3); axis tight;  grid on;  set(gca,'FontSize',fontSize);
camlight headlight;
drawnow;
    
   
elseif strcmpi(answer, 'posterior dilation') 

 figure;
title('Papillary muscle displacement (2D display)','FontSize',fontSize);
xlabel('X axis','FontSize',fontSize);ylabel('Y axis','FontSize',fontSize); zlabel('Z axis','FontSize',fontSize);

hold on;

scatter3(ann_s2(:,1),ann_s2(:,2),ann_s2(:,3),'k','filled');

scatter3(PMPM_bef(:,1),PMPM_bef(:,2),PMPM_bef(:,3),'k','LineWidth',2);
scatter3(PMPM(:,1),PMPM(:,2),PMPM(:,3),'filled','g');
scatter3(ALPM_bef(:,1),ALPM_bef(:,2),ALPM_bef(:,3),'r','LineWidth',2);

%scatter3(LV_bef(:,1),LV_bef(:,2),LV_bef(:,3));
scatter3(LV_2(:,1),LV_2(:,2),LV_2(:,3));

scatter3(ALPM_base(:,1),ALPM_base(:,2),ALPM_base(:,3),'filled');

scatter3(PMPM_base(:,1),PMPM_base(:,2),PMPM_base(:,3),'filled');

scatter3(PMPM_base_after(:,1),PMPM_base_after(:,2),PMPM_base_after(:,3),'filled');


lgd = legend;
lgd.FontSize = 20;
legend(...
    'Mitral annulus',...
    'PMPM tip: before',...
    'PMPM tip: after',...
    'ALPM tip: before',...
    'LV 2D profile: before',...
    'ALPM base',...
    'PMPM base: before',...
    'PMPM base: after');


axis equal; view(3); axis tight;  grid on;  set(gca,'FontSize',fontSize);
camlight headlight;
drawnow;
         

elseif strcmpi(answer, 'total dilation') 
        
figure;
title('Papillary muscle displacement (2D display)','FontSize',fontSize);
xlabel('X axis','FontSize',fontSize);ylabel('Y axis','FontSize',fontSize); zlabel('Z axis','FontSize',fontSize);

hold on;

scatter3(ann_s2(:,1),ann_s2(:,2),ann_s2(:,3),'k','filled');

scatter3(PMPM_bef(:,1),PMPM_bef(:,2),PMPM_bef(:,3),'k','LineWidth',2);
scatter3(PMPM(:,1),PMPM(:,2),PMPM(:,3),'filled','g');
scatter3(ALPM_bef(:,1),ALPM_bef(:,2),ALPM_bef(:,3),'r','LineWidth',2);
scatter3(ALPM(:,1),ALPM(:,2),ALPM(:,3),'filled','m');

%scatter3(LV_bef(:,1),LV_bef(:,2),LV_bef(:,3));
scatter3(LV_2(:,1),LV_2(:,2),LV_2(:,3));

scatter3(ALPM_base(:,1),ALPM_base(:,2),ALPM_base(:,3),'filled');

scatter3(ALPM_base_after_all(:,1),ALPM_base_after_all(:,2),ALPM_base_after_all(:,3),'filled');


scatter3(PMPM_base(:,1),PMPM_base(:,2),PMPM_base(:,3),'filled');

scatter3(PMPM_base_after(:,1),PMPM_base_after(:,2),PMPM_base_after(:,3),'filled');


lgd = legend;
lgd.FontSize = 20;
legend(...
    'Mitral annulus',...
    'PMPM tip: before',...
    'PMPM tip: after',...
    'ALPM tip: before',...
    'ALPM tip: after',...
    'LV 2D profile: before',...
    'ALPM base: before',...
    'ALPM base: after',...
    'PMPM base: before',...
    'PMPM base: after');


axis equal; view(3); axis tight;  grid on;  set(gca,'FontSize',fontSize);
camlight headlight;
drawnow;

end



%%
figure;
fontSize=20;
lineWidth=8;
title('3D left ventricular shape','FontSize',fontSize);
hold on;


hp2=gpatch(F_LV_i,V_LV_i,'b');
hp3=gpatch(F_LV,V_LV,'r');
patchNormPlot(F_LV,V_LV);

hp4 = scatter3(ann_s2(:,1),ann_s2(:,2),ann_s2(:,3),'k','filled');


axisGeom(gca,fontSize);
%camlight headlight;
legend([hp2 hp3 hp4],'Before scaling','After scaling','Mitral annulus');
drawnow;



end
