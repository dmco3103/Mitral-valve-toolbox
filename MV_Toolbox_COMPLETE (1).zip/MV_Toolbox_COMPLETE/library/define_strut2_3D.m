function [transition_shell,node_list,element_beam,ALPM_nodepos,PMPM_nodepos] = define_strut2_3D(V,element_beam,transition_shell,node_list,RT,LT,fe_comm1_pos,fe_comm2_pos,strut_PMALPM,strut_PMPMPM)

% Find insertion node for strut from PMPM
x_strut = RT(1)+3;
dz_strut = 14;


M_z = [];

for i=1:length(V)
    
    dz = abs(max(V(:,3)) - V(i,3));
  
    if ismembertol(dz,dz_strut,1e-1)==1
        M_z = [M_z; i];
    end
    
    if i == fe_comm1_pos
        break
    end
    
end



M_x = [];

for i=1:length(M_z)
    if ismembertol(V(M_z(i),1),x_strut,1e-1)==1
        M_x = [M_x; M_z(i)];
    end
    
end


% position for the strut chordae from PMPM side
strut_PMPM = M_x(2);

strutPMPM_node_up = M_x(1);
strutPMPM_node_down = M_x(3);


% Find insertion node for strut from ALPM
ALPM_find = [-V(strut_PMPM,1) V(strut_PMPM,2) V(strut_PMPM,3)];
pos = [];

for i=1:length(V)
    if ismembertol(ALPM_find,V(i,:),1e-3)==1
        pos = [pos; i];
    end  
end


% position for the strut chordae from ALPM side
strut_ALPM = pos;

strutALPM_node_up = pos-1;
strutALPM_node_down = pos+1;



%%

t_id = transition_shell(end,1)+1;
l = length(node_list)+1;


%PMPM STRUT INSERTION

new_insert = [V(strut_PMPM,1) V(strut_PMPM,2)-0.2 V(strut_PMPM,3)];

    % create up and down nodes
node_up = [V(strutPMPM_node_up,1) V(strutPMPM_node_up,2)-0.2 V(strutPMPM_node_up,3)];

node_down = [V(strutPMPM_node_down,1) V(strutPMPM_node_down,2)-0.2 V(strutPMPM_node_down,3)]; 

% add new nodes to the node_list and new elements to the element list       
node_list(l,:) = [l new_insert(1) new_insert(2) new_insert(3)];

PMPM_s_insert = l;


l = l+1;
    
node_list(l,:) = [l node_up(1) node_up(2) node_up(3)];          

     % element up
transition_shell = [transition_shell; t_id 5 strut_PMPM l-1 l strutPMPM_node_up];
    
    t_id = t_id+1;
    
    l = l+1;
    
node_list(l,:) = [l node_down(1) node_down(2) node_down(3)];

    % element down
transition_shell = [transition_shell; t_id 5 strutPMPM_node_down l l-2 strut_PMPM];  
    



t_id = t_id+1;
l = l+1;
        
        
%ALPM STRUT INSERTION

new_insert = [V(strut_ALPM,1) V(strut_ALPM,2)-0.2 V(strut_ALPM,3)];


    % create left and right nodes
node_up = [V(strutALPM_node_up,1) V(strutALPM_node_up,2)-0.2 V(strutALPM_node_up,3)];

node_down = [V(strutALPM_node_down,1) V(strutALPM_node_down,2)-0.2 V(strutALPM_node_down,3)]; 

% add new nodes to the node_list and new elements to the element list       
node_list(l,:) = [l new_insert(1) new_insert(2) new_insert(3)];

ALPM_s_insert = l;


l = l+1;
    
node_list(l,:) = [l node_up(1) node_up(2) node_up(3)];          

     % element up
transition_shell = [transition_shell; t_id 5 strut_ALPM l-1 l strutALPM_node_up];
    
    t_id = t_id+1;
    
    l = l+1;
    
node_list(l,:) = [l node_down(1) node_down(2) node_down(3)];

    % element down
transition_shell = [transition_shell; t_id 5 strutALPM_node_down l l-2 strut_ALPM];  


%%

% create beam elements for strut (PART 8)

position = length(node_list)+1;

node_list(position,:) = [position strut_PMALPM(1) strut_PMALPM(2) strut_PMALPM(3)];
ALPM_nodepos = position;

position = position+1;
node_list(position,:) = [position strut_PMPMPM(1) strut_PMPMPM(2) strut_PMPMPM(3)];
PMPM_nodepos = position;

position = position+1;
extra_nodes_position = [];
el_PMPM =[];
el_ALPM =[];

%PMPM
 % interpolate to create beams between coordinates
         x = [node_list(PMPM_nodepos,2); node_list(PMPM_s_insert,2)];
         y = [node_list(PMPM_nodepos,3); node_list(PMPM_s_insert,3)];
         z = [node_list(PMPM_nodepos,4); node_list(PMPM_s_insert,4)];
         
         xyz = interparc(7,x,y,z,'linear');
         
         % add extra nodes to node list
         for j=2:length(xyz)-1
             
         node_list(position,:) = [position xyz(j,1) xyz(j,2) xyz(j,3)];
         extra_nodes_position = [extra_nodes_position; position];
         position = position + 1;
         
         end
         
       
         el_PMPM = [el_PMPM; PMPM_nodepos extra_nodes_position(1);...
               extra_nodes_position(1) extra_nodes_position(2);...
            extra_nodes_position(2) extra_nodes_position(3);...
             extra_nodes_position(3) extra_nodes_position(4);...
              extra_nodes_position(4) extra_nodes_position(5);...
               extra_nodes_position(5) PMPM_s_insert];


         extra_nodes_position = [];


%ALPM
           
    % interpolate to create beams between coordinates
         x = [node_list(ALPM_nodepos,2); node_list(ALPM_s_insert,2)];
         y = [node_list(ALPM_nodepos,3); node_list(ALPM_s_insert,3)];
         z = [node_list(ALPM_nodepos,4); node_list(ALPM_s_insert,4)];
         
         xyz = interparc(7,x,y,z,'linear');
         
         % add extra nodes to node list
         for j=2:length(xyz)-1
             
         node_list(position,:) = [position xyz(j,1) xyz(j,2) xyz(j,3)];
         extra_nodes_position = [extra_nodes_position; position];
         position = position + 1;
         
         end
         
       
         el_ALPM = [el_ALPM; ALPM_nodepos extra_nodes_position(1);...
               extra_nodes_position(1) extra_nodes_position(2);...
            extra_nodes_position(2) extra_nodes_position(3);...
             extra_nodes_position(3) extra_nodes_position(4);...
              extra_nodes_position(4) extra_nodes_position(5);...
               extra_nodes_position(5) ALPM_s_insert];       
           
           


%%

el_ID = element_beam(end,1) + 1;

for i=1:length(el_PMPM)
element_beam = [element_beam; el_ID 8 el_PMPM(i,1) el_PMPM(i,2)];
el_ID = el_ID+1;
end

for i=1:length(el_ALPM)
element_beam = [element_beam; el_ID 8 el_ALPM(i,1) el_ALPM(i,2)];
el_ID = el_ID+1;
end



end

