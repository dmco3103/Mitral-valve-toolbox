function [AL_area_m] = AL_surf2(boundary,B_comm2)

% sanity check for AL surface area

%make sure all points are in the edge order
boundary.fe_ant = flipud(boundary.fe_ant);
boundary.B_midAL = flipud(boundary.B_midAL);

AL_boundaries = [boundary.a_ant(:,1) boundary.a_ant(:,2) boundary.a_ant(:,3);...
    B_comm2(2:end,1) B_comm2(2:end,2) B_comm2(2:end,3);...
    boundary.fe_ant(2:end,1) boundary.fe_ant(2:end,2) boundary.fe_ant(2:end,3);... 
    boundary.B_midAL(2:end-1,1) boundary.B_midAL(2:end-1,2) boundary.B_midAL(2:end-1,3)];

%sample before creating surface
[AL_surface] = evenlySampleCurve(AL_boundaries,300,'linear',1);

%create surface
pointSpacing=0.2; %Desired point spacing
resampleCurveOpt=0;
interpMethod='linear'; %or 'natural'
regionCell={AL_surface};
[AL_F,AL_V]=regionTriMesh3D(regionCell,pointSpacing,resampleCurveOpt,interpMethod);

%calculate total element area
AL_area_m=sum(patch_area(AL_F,AL_V));

end

