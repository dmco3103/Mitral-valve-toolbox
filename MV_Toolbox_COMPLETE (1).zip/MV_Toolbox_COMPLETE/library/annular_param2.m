function [ann_s] = annular_param2(ann_s,AH_w)

% use correlation from literature to parameterize AH
%(AH/ALPM vs AH/AP distances, linear)
%ALPM_m = abs(min(ann_s(:,1)));
%AP_m = max(ann_s(:,2)) - min(ann_s(:,2));

%c1 = 0.02705;
%c2 = 0.9703;
%ALPM_m = ALPM_m*2;

% define syms
%syms AH_eq;

% equation
%eqn1 = AH_eq == AP_m*(c1+c2*AH_eq/ALPM_m);

%[AH_p] = vpasolve(eqn1);

%AH_w = double(AH_p);


%AH_w = (AP_m*(ALPM_m)*c1)/((ALPM_m)-AP_m*c2);
%%
% provide value for AH
%(check van Wijngaarden for data for all cycle) 


% using value from Topilsky
%AH_w = 4.2; % mm


%find model current height
AH_m = max(ann_s(:,3)) - min(ann_s(:,3));

%factor to apply (z coordinate)
AH_f = AH_w/AH_m;


% FITS

% we need to split the annulus into 4 portions - 2 for fit in (x,z) plane
% and 2 for fit in (y,z) plane 

%find splitting point
split = -14;

%if CW_f < 0
 %   split = split + split*(1-CW_f);
%else
 %   split = split - (CW_f-1);    
%end

%%
%split into 4 parts (splitting point for different fits depends on previous parameterization)
ann_1 = ann_s((ann_s(:,2) >= 0 & ann_s(:,1) >= split),:);
ann_2 = ann_s((ann_s(:,2) <= 0 &  ann_s(:,1) >= split),:);
ann_3 = ann_s((ann_s(:,2) >= 0 & ann_s(:,1) <= split),:);
ann_4 = ann_s((ann_s(:,2) <= 0 & ann_s(:,1) <= split),:);


ann_1 = flipud(ann_1);
ann_3 = flipud(ann_3);
ann_4 = flipud(ann_4);
ann_2 = flipud(ann_2);



%% from param1
%split into 4 parts
%ann_1 = ann_s((ann_s(:,2) > 0 & ann_s(:,1) >= -14),:);
%ann_2 = ann_s((ann_s(:,2) < 0 & ann_s(:,1) >= -15),:);
%ann_3 = ann_s((ann_s(:,2) > 0 & ann_s(:,2) < 6 & ann_s(:,1) < -14),:);
%ann_4 = ann_s((ann_s(:,2) > 6.5 & ann_s(:,1) < -14),:);

%%

%reorder points according to continuous curve description before fittings
%[a1_sorted, a1_order] = sort(ann_1(:,1),'descend');
%[a3_sorted, a3_order] = sort(ann_3(:,1),'descend');
%[a2_sorted, a2_order] = sort(ann_2(:,1),'ascend');
%[a4_sorted, a4_order] = sort(ann_4(:,1),'ascend');

%ann_1 = ann_1(a1_order,:); 
%ann_2 = ann_2(a2_order,:); 
%ann_3 = ann_3(a3_order,:); 
%ann_4 = ann_4(a4_order,:); 


% AH1 and AH2 (x,z)

p_AH1 = polyfit(ann_1(:,1),ann_1(:,3),3);
p_AH2 = polyfit(ann_2(:,1),ann_2(:,3),3);

x1 = ann_1(:,1);
z1 = polyval(p_AH1,x1);
z1 = AH_f*z1;
x1 = x1;

x2 = ann_2(:,1);
z2 = polyval(p_AH2,x2);
z2 = AH_f*z2;
x2 = x2;



% ann_3 and ann_4 (get y,z)

AH3r = rot90(ann_3); 
AH3r = AH3r';

AH4r = rot90(ann_4); 
AH4r = AH4r';


%%
% problems with change of direction... have to split this group again
AH3r_1 = AH3r((AH3r(:,2) < 5),:);
AH3r_2 = AH3r((AH3r(:,2) > 5),:);



p_AH3r_1 = polyfit(AH3r_1(:,1),AH3r_1(:,2),3);
p_AH3r_2 = polyfit(AH3r_2(:,1),AH3r_2(:,2),3);





p_AH4 = polyfit(AH4r(:,1),AH4r(:,2),2);


%%

z3_1 = AH3r_1(:,1);
y3_1 = polyval(p_AH3r_1,z3_1);
y3_1 = y3_1;
z3_1 = AH_f*z3_1;

z3_2 = AH3r_2(:,1);
y3_2 = polyval(p_AH3r_2,z3_2);
y3_2 = y3_2;
z3_2 = AH_f*z3_2;





z4 = AH4r(:,1);
y4 = polyval(p_AH4,z4);
y4 = y4;
z4 = AH_f*z4;


%rotate all back
ann_3_1 = rot90([z3_1 y3_1 AH3r_1(:,3)]); 
ann_3_1 = ann_3_1';

ann_3_2 = rot90([z3_2 y3_2 AH3r_2(:,3)]); 
ann_3_2 = ann_3_2';



ann_4 = rot90([z4 y4 AH4r(:,3)]); 
ann_4 = ann_4';



%%
%save points after transformation and smooth final curve

ann_s = [x1 ann_1(:,2) z1;... 
    ann_3_2(:,1) ann_3_2(:,2) ann_3_2(:,3);...
    ann_4(:,1) ann_4(:,2) ann_4(:,3);...
     x2 ann_2(:,2) z2];

 
[ann_s] = evenlySampleCurve(ann_s,200,0.95,0);


%save curve with anterior midpoint as starting point
%ann_s = flipud(ann_s);



%% PLOT
%figure;
%scatter3(ann_s(:,1),ann_s(:,2),ann_s(:,3));
%hold on;
%scatter3(x1, ann_1(:,2), z1,'filled');
%scatter3(ann_3_2(:,1), ann_3_2(:,2), ann_3_2(:,3));
%scatter3(ann_3_1(:,1), ann_3_1(:,2), ann_3_1(:,3));
%scatter3(ann_4(:,1), ann_4(:,2), ann_4(:,3));
%scatter3(x2, ann_2(:,2), z2);

end

