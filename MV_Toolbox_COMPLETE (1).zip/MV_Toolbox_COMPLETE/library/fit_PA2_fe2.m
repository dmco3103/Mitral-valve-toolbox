function [boundary] = fit_PA2_fe2(boundary,B_paracom2)
%% PA2 free edge

% first, translate points to match end of paracommissural boundary
t_vector3 = [B_paracom2(end,1)-boundary.fe_PA2(1,1)...
    B_paracom2(end,2)-boundary.fe_PA2(1,2)...
    B_paracom2(end,3)-boundary.fe_PA2(1,3)];

boundary.fe_PA2(:,1) = t_vector3(1) + boundary.fe_PA2(:,1);
boundary.fe_PA2(:,2) = t_vector3(2) + boundary.fe_PA2(:,2);
boundary.fe_PA2(:,3) = t_vector3(3) + boundary.fe_PA2(:,3);


% adaptive transformation in all axis:

% distance between free edge (PA2) and mid PL end points
d = [boundary.B_midPL(end,1)-boundary.fe_PA2(end,1)...
    boundary.B_midPL(end,2)-boundary.fe_PA2(end,2)...
    boundary.B_midPL(end,3)-boundary.fe_PA2(end,3)];


% x transformation

divisory = d(1)/(length(boundary.fe_PA2)-1);
v = [0];

for i=1:length(boundary.fe_PA2)-1
   v = [v; v(i) + divisory]; 
end

% adaptive transform of PA2 free edge
for i=1:length(boundary.fe_PA2)
boundary.fe_PA2(i,1) = v(i) + boundary.fe_PA2(i,1);
end


% y transformation

divisory = d(2)/(length(boundary.fe_PA2)-1);
v = [0];

for i=1:length(boundary.fe_PA2)-1
   v = [v; v(i) + divisory]; 
end

% adaptive transform of PA2 free edge
for i=1:length(boundary.fe_PA2)
boundary.fe_PA2(i,2) = v(i) + boundary.fe_PA2(i,2);
end


% z transformation

divisorz = d(3)/(length(boundary.fe_PA2)-1);
v = [0];

for i=1:length(boundary.fe_PA2)-1
   v = [v; v(i) + divisorz]; 
end

% adaptive transform of PA2 free edge
for i=1:length(boundary.fe_PA2)
boundary.fe_PA2(i,3) = v(i) + boundary.fe_PA2(i,3);
end

end

