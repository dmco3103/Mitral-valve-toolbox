function [] = model_output(ann_s,fe_s,ALPM,PMPM,ALPM_3D,PMPM_3D,n_sampling)

% final processing of all points with x near zero
    for i=1:length(ann_s)
       if abs(ann_s(i,1))<1e-1
          ann_s(i,1) = 0; 
       end
    end
    
   
% include remaining half of the boundaries

ann_include = [-ann_s(:,1) ann_s(:,2) ann_s(:,3)];
ann_include = flipud(ann_include);

fe_include = [-fe_s(:,1) fe_s(:,2) fe_s(:,3)];
fe_include = flipud(fe_include);

ann_s2 = [ann_s; ann_include];
fe_s2 = [fe_s; fe_include];   


  % Remove repetitions
ann_s2 = ann_s2(1:end-1,:);
fe_s2 = fe_s2(1:end-1,:);

  
  
%% Meshing process

n_divisions = n_sampling;

% MAKE SURE TO SAMPLE AT A LARGE RATE - otherwise, the loft feature does
% not work properly - this will define how spaced the mesh elements are
[ann_s2] = evenlySampleCurve(ann_s2,n_divisions,0.01,1);

[fe_s2] = evenlySampleCurve(fe_s2,n_divisions,0.01,1);

fe_s2(:,1) = 0.95*fe_s2(:,1);
fe_s2(:,2) = 0.95*fe_s2(:,2);



ann_s = ann_s2;
fe_s = fe_s2;

% final processing of all points with x near zero
    for i=1:length(ann_s)
       if abs(ann_s(i,1))<1e-1
          ann_s(i,1) = 0; 
       end
    end
    
    for i=1:length(fe_s)
       if abs(fe_s(i,1))<1e-1
          fe_s(i,1) = 0; 
       end
    end
    
   % ann_s = ann_s(1:end-1,:);
   % fe_s = fe_s(1:end-1,:);
   
    
    % create mesh surface
cPar.closeLoopOpt=1;
cPar.patchType='tri';
[F,V]=polyLoftLinear(ann_s,fe_s,cPar);



%% visualize the final model
%plot settings
fontSize=20;
markerSize1=45;
lineWidth1=4;
faceAlpha=0.5;

hf1=cFigure;
title('The meshed model','FontSize',fontSize);
xlabel('X axis','FontSize',fontSize);ylabel('Y axis','FontSize',fontSize); zlabel('Z axis','FontSize',fontSize);
hold on;

%scatter3(ALPM_3D(:,1),ALPM_3D(:,2),ALPM_3D(:,3),'filled');
%scatter3(PMPM_3D(:,1),PMPM_3D(:,2),PMPM_3D(:,3),'filled');


scatter3(ALPM(:,1),ALPM(:,2),ALPM(:,3),'filled');
scatter3(PMPM(:,1),PMPM(:,2),PMPM(:,3),'filled');


%for i=1:length(AL_branch)
%scatter3(AL_branch(i,1),AL_branch(i,2),AL_branch(i,3),'r','filled');
%end

%for i=1:length(PL_branch)
%scatter3(PL_branch(i,1),PL_branch(i,2),PL_branch(i,3),'b','filled');
%end

%for i=1:length(AL_insert)
%scatter3(V(AL_insert(i),1),V(AL_insert(i),2),V(AL_insert(i),3),'m','filled');
%end


%for i=1:length(PL_insert)
%scatter3(V(PL_insert(i),1),V(PL_insert(i),2),V(PL_insert(i),3),'k','filled');
%end


patch('Faces',F,'Vertices',V,'FaceColor','g');


lgd = legend;
lgd.FontSize = 20;
legend(...
    'Anterolateral PM tip',...
    'Posteromedial PM tip',...
    'Leaflet surface mesh');

%chleg = get(lgd,'children');

%set(chleg(1),'color','g')
%set(chleg(2),'color','g')
%set(chleg(3),'color','r')
%set(chleg(4),'color','b')
%set(chleg(5),'color','m')
%set(chleg(6),'color','k')

%plotV(V_newmesh,'b-','LineWidth',2);

axis equal; view(3); axis tight;  grid on;  set(gca,'FontSize',fontSize);
camlight headlight;
drawnow;



%% export the MV leaflet surfaces as an .stl file (triangular mesh surface)
% create the stl Struct to export
stlStruct.solidNames={'mesh'};
stlStruct.solidVertices={V};
stlStruct.solidFaces={F};
stlStruct.solidNormals={[]};

%Set main folder and fileName
defaultFolder = fileparts(fileparts(mfilename('fullpath')));
pathName=fullfile(defaultFolder,'library','Exported_files');
fileName=fullfile(pathName,'Mitral_valve_model.stl');

export_STL_txt(fileName,stlStruct);



%%
% Add strut chordae and translate 3D point cloud of insertions to the correct position

strut_PMALPM = ALPM;
strut_PMPMPM = PMPM;


% translate to correct position
xALPM_3D = mean(ALPM_3D(:,1));
yALPM_3D = mean(ALPM_3D(:,2));

ALPM_3D(end,1) = xALPM_3D;
ALPM_3D(end,2) = yALPM_3D;


xPMPM_3D = mean(PMPM_3D(:,1));
yPMPM_3D = mean(PMPM_3D(:,2));

PMPM_3D(end,1) = xPMPM_3D;
PMPM_3D(end,2) = yPMPM_3D;



t_vectorALPM = [strut_PMALPM(1)-ALPM_3D(end,1)...
    strut_PMALPM(2)-ALPM_3D(end,2)...
    strut_PMALPM(3)-ALPM_3D(end,3)];

ALPM_3D(:,1) = t_vectorALPM(1) + ALPM_3D(:,1);
ALPM_3D(:,2) = t_vectorALPM(2) + ALPM_3D(:,2);
ALPM_3D(:,3) = t_vectorALPM(3) + ALPM_3D(:,3);

t_vectorPMPM = [strut_PMPMPM(1)-PMPM_3D(end,1)...
    strut_PMPMPM(2)-PMPM_3D(end,2)...
    strut_PMPMPM(3)-PMPM_3D(end,3)];

PMPM_3D(:,1) = t_vectorPMPM(1) + PMPM_3D(:,1);
PMPM_3D(:,2) = t_vectorPMPM(2) + PMPM_3D(:,2);
PMPM_3D(:,3) = t_vectorPMPM(3) + PMPM_3D(:,3);


[z_max,pos_z] = max(ALPM_3D(:,3));
diff_z = z_max-strut_PMALPM(3);
ALPM_3D(1:end-1,3) = ALPM_3D(1:end-1,3)-diff_z;

[z_max,pos_z] = max(PMPM_3D(:,3));
diff_z = z_max-strut_PMPMPM(3);

PMPM_3D(1:end-1,3) = PMPM_3D(1:end-1,3)-diff_z;


%% export ALPM and PMPM coordinates (tips and 3D shape) as text file
%start writing file

savefile = ['Papillary_muscle_coordinates','.txt'];
fid = fopen(savefile, 'wt');
%fid = fopen(fileName, 'wt');

fprintf(fid, 'ALPM: single point tip\n');
fprintf(fid, '%15.4f %15.4f %15.4f\n',ALPM(1),ALPM(2),ALPM(3));
fprintf(fid, '$\n');
fprintf(fid, 'PMPM: single point tip\n');
fprintf(fid, '%15.4f %15.4f %15.4f\n',PMPM(1),PMPM(2),PMPM(3));
fprintf(fid, '$\n');

fprintf(fid, 'ALPM: 3D insertion point cloud\n');
for i=1:length(ALPM_3D)-1
fprintf(fid, '%15.4f %15.4f %15.4f\n',ALPM_3D(i,1),ALPM_3D(i,2),ALPM_3D(i,3));
end

fprintf(fid, 'strut point\n');
fprintf(fid, '%15.4f %15.4f %15.4f\n',ALPM_3D(end,1),ALPM_3D(end,2),ALPM_3D(end,3));
fprintf(fid, '$\n');

fprintf(fid, 'PMPM: 3D insertion point cloud\n');
for i=1:length(PMPM_3D)-1
fprintf(fid, '%15.4f %15.4f %15.4f\n',PMPM_3D(i,1),PMPM_3D(i,2),PMPM_3D(i,3));
end
fprintf(fid, 'strut point\n');
fprintf(fid, '%15.4f %15.4f %15.4f\n',PMPM_3D(end,1),PMPM_3D(end,2),PMPM_3D(end,3));

fclose(fid);


%%
%Set main folder and fileName
defaultFolder = fileparts(fileparts(mfilename('fullpath')));
pathName_source=fullfile(defaultFolder,'library');
source=fullfile(pathName_source,'Papillary_muscle_coordinates.txt');
pathName_destination=fullfile(defaultFolder,'library','Exported_files');
destination=fullfile(pathName_destination,'Papillary_muscle_coordinates.txt');

movefile(source,destination);
end

