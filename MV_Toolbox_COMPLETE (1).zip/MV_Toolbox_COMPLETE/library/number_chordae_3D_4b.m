function [AL_insert,PL_insert,n_b,PM_3D] = number_chordae_3D_4b(fe_AL,fe_PL,ALPM_3D,PMPM_3D)

%% get leaflet insertion nodes for chordae

% 5 from each PM for AL (apart from strut) and 7 from each PM for PL
n_start_AL = 10;
n_start_PL = 14;


% how many branches from each chord?
n_b = 4;

n_insert_AL = n_b*n_start_AL;
n_insert_PL = n_b*n_start_PL;

n_AL = floor(length(fe_AL)/n_insert_AL);
n_PL = ceil(length(fe_PL)/n_insert_PL);


AL_insert = [];
PL_insert = [];

for i=1:n_AL:length(fe_AL)
    AL_insert = [AL_insert; fe_AL(i)];
end

for i=1:n_PL:length(fe_PL)
    PL_insert = [PL_insert; fe_PL(i)];
end


%% reorder 3D PM insertions for matching with leaflet insertions
PMPM_3D = PMPM_3D(1:end-1,:);

ALPM_3D = ALPM_3D(1:end-1,:);
ALPM_3D = flipud(ALPM_3D);

PM_3D = [ALPM_3D(8:end,:); PMPM_3D; ALPM_3D(1:7,:)];


end

