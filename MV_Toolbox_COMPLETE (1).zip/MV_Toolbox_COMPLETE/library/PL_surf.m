function [PL_area_m] = PL_surf(boundary)

% sanity check for PL surface area

%make sure all points are in the edge order
boundary.fe_PA2 = flipud(boundary.fe_PA2);
boundary.fe_PA1 = flipud(boundary.fe_PA1);
boundary.B_comm = flipud(boundary.B_comm);

PL_boundaries = [boundary.a_post(:,1) boundary.a_post(:,2) boundary.a_post(:,3);...
    boundary.B_midPL(2:end,1) boundary.B_midPL(2:end,2) boundary.B_midPL(2:end,3);...
    boundary.fe_PA2(2:end,1) boundary.fe_PA2(2:end,2) boundary.fe_PA2(2:end,3);...
    boundary.fe_PA1(2:end,1) boundary.fe_PA1(2:end,2) boundary.fe_PA1(2:end,3);...
    boundary.B_comm(2:end-1,1) boundary.B_comm(2:end-1,2) boundary.B_comm(2:end-1,3)];

%sample before creating surface
[PL_surface] = evenlySampleCurve(PL_boundaries,300,'linear',1);

%create surface
pointSpacing=0.2; %Desired point spacing
resampleCurveOpt=0;
interpMethod='linear'; %or 'natural'
regionCell={PL_surface};
[PL_F,PL_V]=regionTriMesh3D(regionCell,pointSpacing,resampleCurveOpt,interpMethod);

%calculate total element area
PL_area_m=sum(patch_area(PL_F,PL_V));

end

