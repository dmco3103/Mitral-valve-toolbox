function [transition_shell,node_list,insert2,insertion_nodes] = define_transition_el(V,element_shell,node_list,fe_AL,fe_PL,AL_insert,PL_insert)

tol = 1e-30;

insertion_nodes = [AL_insert; PL_insert];

free_edge_nodes = [fe_AL; fe_PL];

new_insert = [];
el_left = [];
el_right = [];

insert2 = [];
transition_shell = [];
t_id = length(element_shell)+1;
l = length(node_list)+1;

node_left = [];
node_right = [];


for i=1:length(insertion_nodes)
   
        new_insert = [V(insertion_nodes(i),1) V(insertion_nodes(i),2) V(insertion_nodes(i),3)-0.2];

        for j=1:length(free_edge_nodes)

           if ismembertol(V(free_edge_nodes(j),:),V(insertion_nodes(i),:),tol)==1     
            
               if j == 1
                  
    % create left and right nodes
    node_left = [V(free_edge_nodes(end),1) V(free_edge_nodes(end),2) V(free_edge_nodes(end),3)-0.2];
    node_right = [V(free_edge_nodes(j+1),1) V(free_edge_nodes(j+1),2) V(free_edge_nodes(j+1),3)-0.2]; 
                   
    % add new nodes to the node_list and new elements to the element list       
   node_list(l,:) = [l new_insert(1) new_insert(2) new_insert(3)];
     
    l = l+1;
    
   node_list(l,:) = [l node_left(1) node_left(2) node_left(3)];          
 
     % element on the left
    transition_shell = [transition_shell; t_id 5 l l-1 insertion_nodes(i) free_edge_nodes(end)];
    
    t_id = t_id+1;
    
    l = l+1;
    
    
    node_list(l,:) = [l node_right(1) node_right(2) node_right(3)];

    % element on the right
    transition_shell = [transition_shell; t_id 5 l-2 l free_edge_nodes(j+1) insertion_nodes(i)];  
    
    
     else
                
    % create left and right nodes
    node_left = [V(free_edge_nodes(j-1),1) V(free_edge_nodes(j-1),2) V(free_edge_nodes(j-1),3)-0.2];
    node_right = [V(free_edge_nodes(j+1),1) V(free_edge_nodes(j+1),2) V(free_edge_nodes(j+1),3)-0.2]; 
    
    % add new nodes to the node_list and new elements to the element list       
   node_list(l,:) = [l new_insert(1) new_insert(2) new_insert(3)];
     
    l = l+1;
    
   node_list(l,:) = [l node_left(1) node_left(2) node_left(3)];          
 
     % element on the left
    transition_shell = [transition_shell; t_id 5 l l-1 insertion_nodes(i) free_edge_nodes(j-1)];
    
    t_id = t_id+1;
    
    l = l+1;
    
    
    node_list(l,:) = [l node_right(1) node_right(2) node_right(3)];

    % element on the right
    transition_shell = [transition_shell; t_id 5 l-2 l free_edge_nodes(j+1) insertion_nodes(i)];
    
    
    
               end
               
            
           end
        end
    
        
        
    insert2 = [insert2; l-2];
    t_id = t_id+1;
    l = l+1;
        
        
end

end

