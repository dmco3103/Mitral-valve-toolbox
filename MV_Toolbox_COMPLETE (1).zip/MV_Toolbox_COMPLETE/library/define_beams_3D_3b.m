function [element_list,node_list] = define_beams_3D_3b(node_list,n_b,PM_nodepos,AL_branch_nodepos,PL_branch_nodepos,element_shell,insert2)  

branch_pos = [AL_branch_nodepos; PL_branch_nodepos];

element_list = [];

el_post = [];
el_pre = [];


%el_ID = transition_shell(end,1)+1;

el_ID = element_shell(end,1)+1;

position = length(node_list)+1;
extra_nodes_position = [];
%total_length = 67;

for i=n_b:n_b:72
       extra_nodes_position = [];

       PM = PM_nodepos(i/3);
       
        % branch node
         node_branch = branch_pos(i/3);

         % PRE CHORDAE: interpolate to create 3 beams between coordinates
         x = [node_list(PM,2); node_list(node_branch,2)];
         y = [node_list(PM,3); node_list(node_branch,3)];
         z = [node_list(PM,4); node_list(node_branch,4)];
         
         xyz = interparc(7,x,y,z,'linear');
         
         % add extra nodes to node list
         for j=2:length(xyz)-1
             
         node_list(position,:) = [position xyz(j,1) xyz(j,2) xyz(j,3)];
         extra_nodes_position = [extra_nodes_position; position];
         position = position + 1;
         end
    
         
     el_pre = [el_pre; PM extra_nodes_position(1);...
               extra_nodes_position(1) extra_nodes_position(2);...
            extra_nodes_position(2) extra_nodes_position(3);...
             extra_nodes_position(3) node_branch];
    
    
                  extra_nodes_position = [];
  
         
         % insertion nodes
         %node5 = insert2(i-4);
         %node4 = insert2(i-3);
         node3 = insert2(i-2);
         node2 = insert2(i);
         node1 = insert2(i-1);

         
         
         % POST CHORDAE: interpolate to create 3 beams between coordinates
         
      
                  % node 3
         x = [node_list(node_branch,2); node_list(node3,2)];
         y = [node_list(node_branch,3); node_list(node3,3)];
         z = [node_list(node_branch,4); node_list(node3,4)];
         
         xyz = interparc(7,x,y,z,'linear');
         
         % add extra nodes to node list
         for j=2:length(xyz)-1
             
         node_list(position,:) = [position xyz(j,1) xyz(j,2) xyz(j,3)];
         extra_nodes_position = [extra_nodes_position; position];
         position = position + 1;
         end
         
       
         el_post = [el_post; node_branch extra_nodes_position(1);...
               extra_nodes_position(1) extra_nodes_position(2);...
            extra_nodes_position(2) extra_nodes_position(3);...
             extra_nodes_position(3) node3];
         
           
         extra_nodes_position = [];

         
         
         % node 2
         x = [node_list(node_branch,2); node_list(node2,2)];
         y = [node_list(node_branch,3); node_list(node2,3)];
         z = [node_list(node_branch,4); node_list(node2,4)];
         
         xyz = interparc(7,x,y,z,'linear');
         
         % add extra nodes to node list
         for j=2:length(xyz)-1
             
         node_list(position,:) = [position xyz(j,1) xyz(j,2) xyz(j,3)];
         extra_nodes_position = [extra_nodes_position; position];
         position = position + 1;
         end
         
       
         el_post = [el_post; node_branch extra_nodes_position(1);...
               extra_nodes_position(1) extra_nodes_position(2);...
            extra_nodes_position(2) extra_nodes_position(3);...
             extra_nodes_position(3) node2];
         
           
         extra_nodes_position = [];
         
          % node 1
         x = [node_list(node_branch,2); node_list(node1,2)];
         y = [node_list(node_branch,3); node_list(node1,3)];
         z = [node_list(node_branch,4); node_list(node1,4)];
         
         xyz = interparc(7,x,y,z,'linear');
         
         % add extra nodes to node list
         for j=2:length(xyz)-1
             
         node_list(position,:) = [position xyz(j,1) xyz(j,2) xyz(j,3)];
         extra_nodes_position = [extra_nodes_position; position];
         position = position + 1;
         end
         
         
         el_post = [el_post; node_branch extra_nodes_position(1);...
               extra_nodes_position(1) extra_nodes_position(2);...
            extra_nodes_position(2) extra_nodes_position(3);...
             extra_nodes_position(3) node1];
         
         
    
end




%%
    
  % add to element list (part 3 - pre; part 4 - post)
for i=1:length(el_pre)
    element_list = [element_list; el_ID 3 el_pre(i,1) el_pre(i,2)];
    el_ID = el_ID+1;   
end

for i=1:length(el_post)
    element_list = [element_list; el_ID 4 el_post(i,1) el_post(i,2)];
    el_ID = el_ID+1;   
end



end

