function [node_list,annode_ID,ann_vector,centroid,annular_disp] = other_input1_before(node_list,AP_w)

%% Annular displacement input

% define group of annular nodes
annode_ID = [node_list(1,1)];

for i=2:length(node_list)

    if abs(node_list(i,4)-node_list(i-1,4)) > 3
 
        annode_ID = [annode_ID; i];
        
    end
end      



%%


% define radial vectors for each annular node

% find centroid of annular points
x = 0; y = 0; z = 0;

for i=1:length(annode_ID)
x = x + node_list(annode_ID(i),2);
y = y + node_list(annode_ID(i),3);    
z = z + node_list(annode_ID(i),4);   
end

% from here, we will retrieve (x,y)
centroid = [x/length(annode_ID) y/length(annode_ID) z/length(annode_ID)];

ann_vector = [];

for i=1:length(annode_ID)

    ann_vector = [ann_vector; node_list(annode_ID(i),2) node_list(annode_ID(i),3)...
        node_list(annode_ID(i),4) centroid(1) centroid(2) node_list(annode_ID(i),4)];
    
end

percentage_difference = 0.11;

diff_AP = AP_w - AP_w*(1-percentage_difference);
annular_disp = diff_AP/2;

 
end

