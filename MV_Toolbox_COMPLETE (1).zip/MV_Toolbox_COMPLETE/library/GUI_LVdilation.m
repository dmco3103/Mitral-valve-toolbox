%% GUI for the MV toolbox
% - Input all dimensions needed to build the model

%clc; clear all; close all;

function [w_w,l_w] = GUI_LVdilation()

dlg_title = 'LV dimensions';

prompt = {'Width [mm]','Length [mm]'};
num_lines = 1;
defaultans = {'40','80'};
answer2 = inputdlg(prompt,dlg_title,num_lines,defaultans);

    w_w = str2num(answer2{1,1});
    l_w = str2num(answer2{2,1});


end



