function [ALPM_vector,PMPM_vector,ALPM_mag,PMPM_mag] = other_input2(ALPM,PMPM,point,ann_s,ann_CW)

RT = point.RT;

% find position of each annular point (trigone, commissure, PL midpoint)
      mid_PL_p = 201;
      CW_p = 80;

     % mid_AL_p = 1;

tol=1e-1;

RT_p = [];

for i=1:length(ann_s)
    if ismembertol(ann_s(i,:),RT,tol)==1
        RT_p = i;
    end
end


%% PM displacement input

% INITIAL DISTANCES FROM TIPS TO LANDMARKS (Dagum, 2000)

%PMPM
PMPM_RT = sqrt((ann_s(RT_p,1)-PMPM(1))^2 + (ann_s(RT_p,2)-PMPM(2))^2 + (ann_s(RT_p,3)-PMPM(3))^2);

PMPM_midPL = sqrt((ann_s(mid_PL_p,1)-PMPM(1))^2 + (ann_s(mid_PL_p,2)-PMPM(2))^2 + (ann_s(mid_PL_p,3)-PMPM(3))^2);

PMPM_CW = sqrt((ann_s(CW_p,1)-PMPM(1))^2 + (ann_s(CW_p,2)-PMPM(2))^2 + (ann_s(CW_p,3)-PMPM(3))^2);


%PMPM_midAL = sqrt((ann_s(mid_AL_p,1)-PMPM(1))^2 + (ann_s(mid_AL_p,2)-PMPM(2))^2 + (ann_s(mid_AL_p,3)-PMPM(3))^2);


%% NEW LANDMARKS WITH ANNULAR CONTRACTION

RT_new = ann_CW(RT_p,:);
midPL_new = ann_CW(mid_PL_p,:);
%midAL_new = ann_CW(mid_AL_p,:);
CW_new = ann_CW(CW_p,:);



% FINAL PM COORDINATES
syms x1 y1 z1 x2 y2 z2;

%PMPM

eqn4 = PMPM_RT == sqrt((RT_new(1)-x2)^2 + (RT_new(2)-y2)^2 + (RT_new(3)-z2)^2);

eqn5 = PMPM_CW == sqrt((CW_new(1) - x2)^2 + (CW_new(2) - y2)^2 + (CW_new(3) - z2)^2);

%eqn5 = PMPM_midAL == sqrt((midAL_new(1) - x2)^2 + (midAL_new(2) - y2)^2 + (midAL_new(3) - z2)^2);

eqn6 = PMPM_midPL == sqrt((midPL_new(1) - x2)^2 + (midPL_new(2) - y2)^2 + (midPL_new(3) - z2)^2);

[sx2, sy2, sz2] = vpasolve(eqn4,eqn5,eqn6);


% obtain new 3D position of PM tips
PMPM_new = [double(sx2) double(sy2) double(sz2)];


%% PM vectors and magnitudes
%ALPM_vector = [ALPM(1) ALPM(2) ALPM(3)...
 %       ALPM_new(1) ALPM_new(2) ALPM_new(3)];
    
%PMPM_vector = [PMPM(1) PMPM(2) PMPM(3)...
 %       PMPM_new(1) PMPM_new(2) PMPM_new(3)];
   
    
%PAP_AA = sqrt((PMPM(1)-point.mid_AL(1))^2+(PMPM(2)-point.mid_AL(2))^2+(PMPM(3)-point.mid_AL(3))^2);
%PAP_AA2=PAP_AA;

%while 100*abs(PAP_AA2-PAP_AA)/PAP_AA<4 % total PM shortening of 8%
 %   PMPM_new(3) = PMPM_new(3)+0.1;
 %   PAP_AA2 = sqrt((PMPM_new(1)-point.mid_AL(1))^2+(PMPM_new(2)-point.mid_AL(2))^2+(PMPM_new(3)-point.mid_AL(3))^2);  
%end
    


%figure;

%scatter3(PMPM(1),PMPM(2),PMPM(3));
%hold on;
%scatter3(PMPM_new(1),PMPM_new(2),PMPM_new(3));

ALPM_new = [-PMPM_new(1) PMPM_new(2) PMPM_new(3)];


    
    %%
PMPM_vector = [PMPM(1) PMPM(2) PMPM(3)...
        PMPM_new(1) PMPM_new(2) PMPM_new(3)];

ALPM_vector = [ALPM(1) ALPM(2) ALPM(3)...
        ALPM_new(1) ALPM_new(2) ALPM_new(3)];
    
ALPM_mag = sqrt((ALPM(1)-ALPM_new(1))^2 + (ALPM(2)-ALPM_new(2))^2 + (ALPM(3)-ALPM_new(3))^2);
PMPM_mag = sqrt((PMPM(1)-PMPM_new(1))^2 + (PMPM(2)-PMPM_new(2))^2 + (PMPM(3)-PMPM_new(3))^2);

 
end

