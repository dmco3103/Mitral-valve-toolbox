function [boundary,point] = PL_parameterize_PS(boundary,point,dimensions)
%% define posterior part including faces right after commissure
% the intact free edge commissural point will be added to the posterior
% free edge vertex group for proper manipulation

boundary.a_post = [point.ann_comm; boundary.a_post];

boundary.a_PA1 = [point.ann_comm; boundary.a_PA1];
boundary.a_ant = boundary.a_ant(1:end-1,:);


boundary.fe_PA1 = [point.fe_comm; boundary.fe_PA1];
boundary.fe_ant = boundary.fe_ant(1:end-1,:);


% first thing, fit the fe_PA1 with the new commissural boundary



%% dimension definitions

% get current PAC, PA1 and PA2 annular lengths
PAC = 2*max(pathLength(boundary.a_post));
%PA1_annl_m=max(pathLength(boundary.a_PA1));
%PA2_annl_m=max(pathLength(boundary.a_PA2)); 


% wanted dimensions

% all scallop annular lengths respect Golden Proportion
%PA1_annl_w = 1/3*(2*PAC);
%PA1_annl_w = PL_length_w;
%PA1_annl_w = 0.2764*PAC;

%PA2_annl_w = 1/3*(2*PAC); % we multiply by 2, because we have half PL
%PA2_annl_w = 1.618*PA1_annl_w;
PA2_annl_w = 0.4472*PAC;

PA2_annl_w = 1/2*PA2_annl_w; % get back to half model


%%

% locate new paracommissural boundary, based on wanted PA1 and PA2 annular lengths
[boundary,point] = B_paracom_locate(boundary,point,PA2_annl_w);

% fit posterior free edges (PA1 and PA2) on current model
[boundary] = fit_PA1_fe(boundary);
[boundary] = fit_PA2_fe(boundary);


%fe_s(:,1) = 0.98*fe_s(:,1);
%fe_s(:,2) = 0.98*fe_s(:,2);


%function to calculate current TOTAL PL surface area
PL_area_m = PL_surf(boundary);
tol=1e-1;
paracom_f = 1;



%% AREA WANTED

% parameterize

PL_area_w = dimensions.PL_area;

% paracommissure - rotate to get (y,z)
Br_paracom = rot90(boundary.B_paracom); 
Br_paracom = Br_paracom';

p_paracom = polyfit(Br_paracom(:,1),Br_paracom(:,2),2);
z4 = Br_paracom(:,1);
y4 = polyval(p_paracom,z4);

%%
if PL_area_w > PL_area_m
  
while PL_area_m < PL_area_w

B_paracom2 = boundary.B_paracom;    
       
% paracommissural boundary treatment
y44 = y4; z44 = z4;

y44 = paracom_f*y44;
z44 = paracom_f*z44;

%rotate all back
B_paracom2 = rot90([z44 y44 paracom_f*Br_paracom(:,3)]); 
B_paracom2 = B_paracom2';

% translate points to match annular beginning
t_vector2 = [point.ann_paracom(1)-B_paracom2(1,1)...
    point.ann_paracom(2)-B_paracom2(1,2)...
    point.ann_paracom(3)-B_paracom2(1,3)];

B_paracom2(:,1) = t_vector2(1) + B_paracom2(:,1);
B_paracom2(:,2) = t_vector2(2) + B_paracom2(:,2);
B_paracom2(:,3) = t_vector2(3) + B_paracom2(:,3);


% fit posterior free edge between predefined boundaries
[boundary] = fit_PA1_fe2(boundary,B_paracom2);
[boundary] = fit_PA2_fe2(boundary,B_paracom2);


% create temporary quad mesh for the PL and calculate surface area
PL_area_m = PL_surf(boundary);


% change scaling factor for commissural boundary and start again
paracom_f = paracom_f + tol;

end
    
elseif PL_area_w < PL_area_m
   
while PL_area_m > PL_area_w

B_paracom2 = boundary.B_paracom;    
       
% paracommissural boundary treatment
y44 = y4; z44 = z4;

y44 = paracom_f*y44;
z44 = paracom_f*z44;

%rotate all back
B_paracom2 = rot90([z44 y44 paracom_f*Br_paracom(:,3)]); 
B_paracom2 = B_paracom2';

% translate points to match annular beginning
t_vector2 = [point.ann_paracom(1)-B_paracom2(1,1)...
    point.ann_paracom(2)-B_paracom2(1,2)...
    point.ann_paracom(3)-B_paracom2(1,3)];

B_paracom2(:,1) = t_vector2(1) + B_paracom2(:,1);
B_paracom2(:,2) = t_vector2(2) + B_paracom2(:,2);
B_paracom2(:,3) = t_vector2(3) + B_paracom2(:,3);


% fit posterior free edge between predefined boundaries
[boundary] = fit_PA1_fe2(boundary,B_paracom2);
[boundary] = fit_PA2_fe2(boundary,B_paracom2);


% create temporary quad mesh for the PL and calculate surface area
PL_area_m = PL_surf(boundary);

% change scaling factor for commissural boundary and start again
paracom_f = paracom_f - tol;
     
end

end

boundary.B_paracom = B_paracom2;
point.fe_paracom = boundary.B_paracom(end,:);

boundary.a_post = [boundary.a_PA1; boundary.a_PA2];


end

