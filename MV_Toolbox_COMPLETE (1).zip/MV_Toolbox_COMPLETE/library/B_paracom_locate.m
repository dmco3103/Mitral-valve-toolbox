function [boundary,point] = B_paracom_locate(boundary,point,PA2_annl_w)
%% locate new paracommissural boundary, based on wanted PA1 and PA2 annular lengths

% based on wanted annular lengths for posterior parts, locate annular starting
% point and split in PA1 and PA2 again

% get wanted vertex for each side (start from bottom up to get PA2 first)
boundary.a_PA1 = [];
boundary.a_PA2 = [];

i = length(boundary.a_post);

% get inverted sum of lengths of edges
a_post_i = flipud(boundary.a_post);
PAC_alcum_i=pathLength(a_post_i);


while i >= 1   
    if PAC_alcum_i(i,1) < PA2_annl_w       
        boundary.a_PA2 = [boundary.a_PA2; a_post_i(i,:)];                    
    else    
         boundary.a_PA1 = [boundary.a_PA1; a_post_i(i,:)];
    end    
    i=i-1;    
end

% get new annular paracomm point
point.ann_paracom = boundary.a_PA2(1,:);


% translate paracomm boundary as it is, to match new annular starting point
t_vector = [point.ann_paracom(1)-boundary.B_paracom(1,1)...
    point.ann_paracom(2)-boundary.B_paracom(1,2)...
    point.ann_paracom(3)-boundary.B_paracom(1,3)];

boundary.B_paracom(:,1) = t_vector(1) + boundary.B_paracom(:,1);
boundary.B_paracom(:,2) = t_vector(2) + boundary.B_paracom(:,2);
boundary.B_paracom(:,3) = t_vector(3) + boundary.B_paracom(:,3);

end

