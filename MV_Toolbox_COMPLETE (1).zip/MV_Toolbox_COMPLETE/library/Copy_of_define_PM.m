function [ALPM,PMPM] = define_PM(point)
%% data needed for tip

% retrieve annular points from struct
mid_AA = point.mid_AL;
RT = point.RT;
LT = point.LT;
P4 = point.ann_paracom;
P8 = [-P4(1) P4(2) P4(3)];

% define o'clock distances (unique PM tip, inter-PM = 16.9299 mm)
%ALPM_tet = 27.1;
%PMPM_tet = 27.1;
%dRT = 23;
%dLT = 23;
%d4 = 20.9;
%d8 = 20.9;


% o'clock distances (PM 3D position 2, inter-PM = 17.0886) (Yamaura, 2008)
%ALPM_tet = 28.5;
%PMPM_tet = 28.5;
%dRT = 24;
%dLT = 24;
%d4 = 20.5;
%d8 = 20.5;



% o'clock distances (inter-PM = 23.3243)
ALPM_tet = 32;
PMPM_tet = 32;
dRT = 27;
dLT = 27;
d4 = 24;
d8 = 24;



% define o'clock distances (FOR DILATED CASE)
%ALPM_tet = 1.3*27.1;
%PMPM_tet = 1.3*27.1;
%dRT = 1.3*23;
%dLT = 1.3*23;
%d4 = 1.3*20.9;
%d8 = 1.3*20.9;



% define coordinates for ALPM, PMPM
syms x1 y1 z1 x2 y2 z2;


%% define equations to solve (tip)

% ALPM
eqn1 = ALPM_tet == sqrt((mid_AA(1)-x1)^2 + (mid_AA(2)-y1)^2 + (mid_AA(3)-z1)^2);

eqn2 = dLT == sqrt((LT(1) - x1)^2 + (LT(2) - y1)^2 + (LT(3) - z1)^2);

eqn3 = d8 == sqrt((P8(1) - x1)^2 + (P8(2) - y1)^2 + (P8(3) - z1)^2);


[sx1, sy1, sz1] = vpasolve(eqn1,eqn2,eqn3);


%PMPM

eqn4 = PMPM_tet == sqrt((mid_AA(1)-x2)^2 + (mid_AA(2)-y2)^2 + (mid_AA(3)-z2)^2);

eqn5 = dRT == sqrt((RT(1) - x2)^2 + (RT(2) - y2)^2 + (RT(3) - z2)^2);

eqn6 = d4 == sqrt((P4(1) - x2)^2 + (P4(2) - y2)^2 + (P4(3) - z2)^2);

[sx2, sy2, sz2] = vpasolve(eqn4,eqn5,eqn6);


% obtain 3D position of PM tips
ALPM = [double(sx1) double(sy1) double(sz1)]; PMPM = [double(sx2) double(sy2) double(sz2)];

% (used for PM 3D position 3)
%ALPM(1) = ALPM(1) - 1;
%PMPM(1) = PMPM(1) + 1;
%ALPM(3) = ALPM(3) - 1;
%PMPM(3) = PMPM(3) - 1;


% (used for PM 3D position 2)
%ALPM(3) = ALPM(3) - 2;
%PMPM(3) = PMPM(3) - 2;
%ALPM(2) = ALPM(2) + 1;
%PMPM(2) = PMPM(2) + 1;

% find inter-PM distance
inter_PM = sqrt((ALPM(1)-PMPM(1))^2+(ALPM(2)-PMPM(2))^2+(ALPM(3)-PMPM(3))^2);


end

