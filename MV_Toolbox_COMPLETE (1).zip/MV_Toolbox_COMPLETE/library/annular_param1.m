function [ann_s] = annular_param1(ann_s,AP_w,CW_w)

% place CW at y = 0 again
%y = ann_s(80,2);
%ann_s(:,2) = ann_s(:,2)-y;


%divide CW (half model)
CW_w = CW_w/2;

%find model current dimensions
CW_m = abs(ann_s(122,1));

AP_m = max(ann_s(:,2)) - min(ann_s(:,2));

%factors to apply
CW_f = CW_w/CW_m;
AP_f = AP_w/AP_m;


%%
%function to fit annular curve

%split into 4 parts
ann_1 = ann_s((ann_s(:,2) > 0 & ann_s(:,1) >= -14),:);
ann_2 = ann_s((ann_s(:,2) < 0 & ann_s(:,1) >= -15),:);
ann_3 = ann_s((ann_s(:,2) > 0 & ann_s(:,2) < 6 & ann_s(:,1) < -14),:);
ann_4 = ann_s((ann_s(:,2) > 6.5 & ann_s(:,1) < -14),:);




%reorder points according to continuous curve description before fittings
%[a1_sorted, a1_order] = sort(ann_1(:,1),'descend');
%[a4_sorted, a4_order] = sort(ann_4(:,1),'descend');

%[a3_sorted, a3_order] = sort(ann_3(:,1),'ascend');

%[a2_sorted, a2_order] = sort(ann_2(:,1),'ascend');


%ann_1 = ann_1(a1_order,:); 
%ann_2 = ann_2(a2_order,:); 
%ann_3 = ann_3(a3_order,:); 
%ann_4 = ann_4(a4_order,:); 

%%
% fit functions for x, y plane (used for ALPM and AP transformations)
p_ann1 = polyfit(ann_1(:,1),ann_1(:,2),3);
p_ann2 = polyfit(ann_2(:,1),ann_2(:,2),4);
p_ann3 = polyfit(ann_3(:,1),ann_3(:,2),3);


x1 = ann_1(:,1);
y1 = polyval(p_ann1,x1);
y1 = AP_f*y1;
x1 = CW_f*x1; 

x2 = ann_2(:,1);
y2 = polyval(p_ann2,x2);
y2 = AP_f*y2;
x2 = CW_f*x2;

x3 = ann_3(:,1);
y3 = polyval(p_ann3,x3);
y3 = AP_f*y3;
x3 = CW_f*x3;


%%
p_ann4 = polyfit(ann_4(:,1),ann_4(:,2),3);


x4 = ann_4(:,1);
y4 = polyval(p_ann4,x4);
y4 = AP_f*y4;
x4 = CW_f*x4;



%%
%save points after transformation and smooth curve
ann_s = [x1 y1 ann_1(:,3); x4 y4 ann_4(:,3); x3 y3 ann_3(:,3);  x2 y2 ann_2(:,3)];

[ann_s] = evenlySampleCurve(ann_s,200,0.95,0);

%save curve with anterior midpoint as starting point
ann_s = flipud(ann_s);


end

