function [node_list,element_beam,ALPM_nodepos,PMPM_nodepos,transition_shell,ALPM_marginal_nodepos,PMPM_marginal_nodepos] = chordae_input_3D_3b(ALPM_3D,PMPM_3D,node_list,element_shell,V,fe_s,fe_comm1,fe_comm2,fe_comm1_pos,fe_comm2_pos,ALPM,PMPM,fe_el,point)

RT = point.RT;
LT = point.LT;


% Add strut chordae and translate 3D point cloud of insertions to the correct position

% translate to correct position based on central tip
xALPM_3D = mean(ALPM_3D(:,1));
yALPM_3D = mean(ALPM_3D(:,2));

%ALPM_3D(end,1) = xALPM_3D;
%ALPM_3D(end,2) = yALPM_3D;


xPMPM_3D = mean(PMPM_3D(:,1));
yPMPM_3D = mean(PMPM_3D(:,2));

%PMPM_3D(end,1) = xPMPM_3D;
%PMPM_3D(end,2) = yPMPM_3D;



t_vectorALPM = [ALPM(1)-xALPM_3D...
    ALPM(2)-yALPM_3D...
    ALPM(3)-max(ALPM_3D(:,3))];

ALPM_3D(:,1) = t_vectorALPM(1) + ALPM_3D(:,1);
ALPM_3D(:,2) = t_vectorALPM(2) + ALPM_3D(:,2);
ALPM_3D(:,3) = t_vectorALPM(3) + ALPM_3D(:,3);

t_vectorPMPM = [PMPM(1)-xPMPM_3D...
    PMPM(2)-yPMPM_3D...
    PMPM(3)-max(PMPM_3D(:,3))];

PMPM_3D(:,1) = t_vectorPMPM(1) + PMPM_3D(:,1);
PMPM_3D(:,2) = t_vectorPMPM(2) + PMPM_3D(:,2);
PMPM_3D(:,3) = t_vectorPMPM(3) + PMPM_3D(:,3);


[z_max,pos_z] = max(ALPM_3D(:,3));
diff_z = z_max-ALPM(3);
ALPM_3D(1:end-1,3) = ALPM_3D(1:end-1,3)-diff_z;

[z_max,pos_z] = max(PMPM_3D(:,3));
diff_z = z_max-PMPM(3);

PMPM_3D(1:end-1,3) = PMPM_3D(1:end-1,3)-diff_z;




strut_PMALPM = ALPM_3D(end,:);
strut_PMPMPM = PMPM_3D(end,:);



%%
tol = 1e-30;

% split free edge nodes (positions) into AL and PL
fe_AL = [];
fe_PL = [];

for i=1:length(fe_el)
   
    if ismembertol(fe_el(i),fe_comm1_pos,tol)==0
        fe_AL = [fe_AL; fe_el(i)];
        
    else
        fe_AL = [fe_AL; fe_el(i)];
        break
    end
end




for k=i+1:length(fe_el)
      
    if ismembertol(V(fe_el(k),:),fe_comm2,tol)==0
   
        fe_PL = [fe_PL; fe_el(k)];   
   
    else
      %  fe_PL = [fe_PL; fe_el(k)];
        break
    end   
end


fe_AL1 = [];

for j = k:length(fe_el)
    fe_AL1 = [fe_AL1; fe_el(j)];
end

fe_AL = [fe_AL1;fe_AL];


%%
% Chordae definitions
[AL_insert,PL_insert,n_b,PM_3D] = number_chordae_3D_3b(V,fe_AL,fe_PL,ALPM_3D,PMPM_3D);


%% Create additional transition elements for chordae insertion (AL)
[transition_shell,node_list,insert2,insertion_nodes] = define_transition_el(V,element_shell,node_list,fe_AL,fe_PL,AL_insert,PL_insert);

%%
% Fing branching nodes
AL_midway1 = [];
PL_midway1 = [];
AL_branch = [];
PL_branch = [];


% for AL chordae
for i=n_b:n_b:length(AL_insert)
    
    node2 = V(AL_insert(i),:);
    node1 = V(AL_insert(i-2),:);
    
    AL_midway1 = [AL_midway1; (node2(:) + node1(:)).'/2];
end


for i=1:length(AL_midway1)
    
    node = AL_midway1(i,:);
    PM = PM_3D(i,:);
    
    mid_d = (PM(:) + node(:)).'/2;
    
    AL_branch = [AL_branch; mid_d];  
           
end
    
k = i+1;


% for PL chordae
for i=n_b:n_b:length(PL_insert)
    
    node2 = V(PL_insert(i),:);
    node1 = V(PL_insert(i-2),:);
    
    PL_midway1 = [PL_midway1; (node2(:) + node1(:)).'/2];
end



for i=1:length(PL_midway1)
    
    node = PL_midway1(i,:);
    PM = PM_3D(k,:);

    mid_d = (PM(:) + node(:)).'/2;

    PL_branch = [PL_branch; mid_d];  
    
   k = k+1;
              
end



%% Define inputs for LS-DYNA

% add chordae branching nodes to node list
i = length(node_list);
i = i+1;
AL_branch_nodepos = [];
PL_branch_nodepos = [];

for j=1:length(AL_branch)
   node_list(i,:) = [i AL_branch(j,1) AL_branch(j,2) AL_branch(j,3)];
   AL_branch_nodepos = [AL_branch_nodepos; i];
   i = i+1;
end

for j=1:length(PL_branch)
   node_list(i,:) = [i PL_branch(j,1) PL_branch(j,2) PL_branch(j,3)];
   PL_branch_nodepos = [PL_branch_nodepos; i];
   i = i+1;
end
   

PM_nodepos = [];


% insert 3D PMs in node list and store position
for j=1:length(PM_3D)
   node_list(i,:) = [i PM_3D(j,1) PM_3D(j,2) PM_3D(j,3)];
   PM_nodepos = [PM_nodepos; i];
   i = i+1;
end


%% Divide again in ALPM and PMPM
ALPM_marginal_nodepos = [];
PMPM_marginal_nodepos = [];

for i=1:length(PM_nodepos)
if node_list(PM_nodepos(i),2) > 0
    ALPM_marginal_nodepos = [ALPM_marginal_nodepos; PM_nodepos(i)];

else 
    PMPM_marginal_nodepos = [PMPM_marginal_nodepos; PM_nodepos(i)];
   
end
end


%% Create beam element list   

[element_list,node_list] = define_beams_3D_3b(node_list,n_b,PM_nodepos,AL_branch_nodepos,PL_branch_nodepos,element_shell,insert2);  


element_beam = element_list;


%% Create strut chordae

%[transition_shell,node_list,element_beam] = define_strut(V,element_beam,transition_shell,node_list,RT,LT,fe_comm1_pos,fe_comm2_pos,ALPM_nodepos,PMPM_nodepos);

[transition_shell,node_list,element_beam,ALPM_nodepos,PMPM_nodepos] = define_strut2_3D(V,element_beam,transition_shell,node_list,RT,LT,fe_comm1_pos,fe_comm2_pos,strut_PMALPM,strut_PMPMPM);

%% PLOTS
%plot settings
fontSize=20;
%markerSize1=45;
%lineWidth1=4;
%faceAlpha=0.5;

hfig=cFigure;
title('Chordal points','FontSize',fontSize);
xlabel('X axis','FontSize',fontSize);ylabel('Y axis','FontSize',fontSize); zlabel('Z axis','FontSize',fontSize);

hold on;

%scatter3(ann_s(:,1),ann_s(:,2),ann_s(:,3));
scatter3(fe_s(:,1),fe_s(:,2),fe_s(:,3));


scatter3(ALPM_3D(:,1),ALPM_3D(:,2),ALPM_3D(:,3),'g','filled');
scatter3(PMPM_3D(:,1),PMPM_3D(:,2),PMPM_3D(:,3),'k','filled');


for i=1:length(AL_branch)
if i==1
    scatter3(AL_branch(i,1),AL_branch(i,2),AL_branch(i,3),'r','filled');
else
    h = scatter3(AL_branch(i,1),AL_branch(i,2),AL_branch(i,3),'r','filled');
    h.Annotation.LegendInformation.IconDisplayStyle = 'off';
end
end


for i=1:length(PL_branch)
if i==1
scatter3(PL_branch(i,1),PL_branch(i,2),PL_branch(i,3),'b','filled');
else
    h = scatter3(PL_branch(i,1),PL_branch(i,2),PL_branch(i,3),'b','filled');
    h.Annotation.LegendInformation.IconDisplayStyle = 'off';
end
end


for i=1:length(insertion_nodes)
    if i == 1
scatter3(V(insertion_nodes(i),1),V(insertion_nodes(i),2),V(insertion_nodes(i),3),'m','filled');
    else
    h = scatter3(V(insertion_nodes(i),1),V(insertion_nodes(i),2),V(insertion_nodes(i),3),'m','filled');
    h.Annotation.LegendInformation.IconDisplayStyle = 'off';
    end
end



lgd = legend;
lgd.FontSize = 20;
legend(...
    'Free edge',...
    'Anterolateral PM insertions',...
    'Posteromedial PM insertions',...
    'AL chordae branching',...
    'PL chordae branching',...
    'Free edge insertion nodes');


%color = get(hfig,'Color');
%set(gca,'XColor',color,'YColor',color,'ZColor',color,'TickDir','out')

axis equal; view(3); axis tight;  grid on;  set(gca,'FontSize',fontSize);
camlight headlight;
drawnow;





end

