function [F,V,ann_s,fe_s] = meshing_model1(ann_s,fe_s,ALPM,PMPM)
% final processing of all points with x near zero
    for i=1:length(ann_s)
       if abs(ann_s(i,1))<1e-1
          ann_s(i,1) = 0; 
       end
    end
    
   
% include remaining half of the boundaries

ann_include = [-ann_s(:,1) ann_s(:,2) ann_s(:,3)];
ann_include = flipud(ann_include);

fe_include = [-fe_s(:,1) fe_s(:,2) fe_s(:,3)];
fe_include = flipud(fe_include);

ann_s2 = [ann_s; ann_include];
fe_s2 = [fe_s; fe_include];   


  % Remove repetitions
ann_s2 = ann_s2(1:end-1,:);
fe_s2 = fe_s2(1:end-1,:);

  
  
%% Meshing process

n_divisions = 450;

% MAKE SURE TO SAMPLE AT A LARGE RATE - otherwise, the loft feature does
% not work properly - this will define how spaced the mesh elements are
[ann_s2] = evenlySampleCurve(ann_s2,n_divisions,0.01,1);

[fe_s2] = evenlySampleCurve(fe_s2,n_divisions,0.01,1);

fe_s2(:,1) = 0.95*fe_s2(:,1);
fe_s2(:,2) = 0.95*fe_s2(:,2);



ann_s = ann_s2;
fe_s = fe_s2;

% final processing of all points with x near zero
    for i=1:length(ann_s)
       if abs(ann_s(i,1))<1e-1
          ann_s(i,1) = 0; 
       end
    end
    
    for i=1:length(fe_s)
       if abs(fe_s(i,1))<1e-1
          fe_s(i,1) = 0; 
       end
    end
    
   % ann_s = ann_s(1:end-1,:);
   % fe_s = fe_s(1:end-1,:);
   
    
    % create mesh surface
cPar.closeLoopOpt=1;
cPar.patchType='quad';
[F,V]=polyLoftLinear(ann_s,fe_s,cPar);


%% visualize the final model
%plot settings
fontSize=20;

hfig=cFigure;
title('The meshed model','FontSize',fontSize);
xlabel('X axis','FontSize',fontSize);ylabel('Y axis','FontSize',fontSize); zlabel('Z axis','FontSize',fontSize);
hold on;

%scatter3(ann_s(:,1),ann_s(:,2),ann_s(:,3),'b','filled')

%scatter3(ALPM_3D(:,1),ALPM_3D(:,2),ALPM_3D(:,3),'filled');
%scatter3(PMPM_3D(:,1),PMPM_3D(:,2),PMPM_3D(:,3),'filled');


h1 = scatter3(ALPM(:,1),ALPM(:,2),ALPM(:,3),'filled');
h2 = scatter3(PMPM(:,1),PMPM(:,2),PMPM(:,3),'filled');

h1.SizeData = 80; 
h2.SizeData = 80; 

%for i=1:length(AL_branch)
%scatter3(AL_branch(i,1),AL_branch(i,2),AL_branch(i,3),'r','filled');
%end

%for i=1:length(PL_branch)
%scatter3(PL_branch(i,1),PL_branch(i,2),PL_branch(i,3),'b','filled');
%end

%for i=1:length(AL_insert)
%scatter3(V(AL_insert(i),1),V(AL_insert(i),2),V(AL_insert(i),3),'m','filled');
%end


%for i=1:length(PL_insert)
%scatter3(V(PL_insert(i),1),V(PL_insert(i),2),V(PL_insert(i),3),'k','filled');
%end


patch('Faces',F,'Vertices',V,'FaceColor','r');
%color = get(hfig,'Color');
%set(gca,'XColor',color,'YColor',color,'ZColor',color,'TickDir','out')

lgd = legend;
lgd.FontSize = 20;
legend(...
    'Anterolateral PM tip',...
    'Posteromedial PM tip',...
    'Leaflet surface mesh');

%chleg = get(lgd,'children');

%set(chleg(1),'color','g')
%set(chleg(2),'color','g')
%set(chleg(3),'color','r')
%set(chleg(4),'color','b')
%set(chleg(5),'color','m')
%set(chleg(6),'color','k')

%plotV(V_newmesh,'b-','LineWidth',2);

axis equal; view(3); axis tight;  
grid on;  
set(gca,'FontSize',fontSize);
%camlight headlight;
drawnow;

end

