function [boundary,point] = leaflet_define_boundaries1(ann_s,fe_s)

  for i=1:length(ann_s)
       if abs(ann_s(i,1))<1e-1
          ann_s(i,1) = 0; 
       end
  end
    
  for i=1:length(fe_s)
       if abs(fe_s(i,1))<1e-1
          fe_s(i,1) = 0; 
       end
  end




%%
AC_path = pathLength(ann_s);

% get vertex for each side (annulus)
a_post = [];
a_ant = [];

% use proportions from literature to obtain AAC and PAC
AC = 2*max(AC_path);
AAC_w = 2/5*AC;
%AAC_w = 0.4174*AC;
AAC_w = 1/2*AAC_w;

i=1;
tol=1e-30;

while AC_path(i,:) < AAC_w
   a_ant=[a_ant; ann_s(i,:)];
i = i+1;
end

ann_comm = ann_s(i-1,:);


for k=i:length(ann_s)
        a_post=[a_post; ann_s(k,:)];
end

% translate the model to have the commissural point at z coordinate = 0
z_comm = ann_comm(3);
ann_comm(3) = ann_comm(3) - z_comm;
a_ant(:,3) = a_ant(:,3) - z_comm; 
a_post(:,3) = a_post(:,3) - z_comm;
ann_s(:,3) = ann_s(:,3) - z_comm;



%% commissural point - lowest z coordinate
%[ann_minx,posmin1] = min(ann_s(:,3));
%ann_comm = ann_s(posmin1,:); 

%find comm points on annulus and split between anterior and posterior parts
%i=1;
%tol=1e-30;

%while abs(ann_s(i,3) - ann_comm(1,3)) > tol
%a_ant=[a_ant; ann_s(i,:)];
%i = i+1;
%end

%a_ant=[a_ant; ann_s(i,:)];
%i = i+1;

 %for k=i:length(ann_s)
  %      a_post=[a_post; ann_s(k,:)];
 %end


%figure; scatter3(a_ant(:,1),a_ant(:,2),a_ant(:,3)); hold on;
%scatter3(a_post(:,1),a_post(:,2),a_post(:,3));



%% Trigones

% INVESTIGATE - Okamoto says that trigones should be located at 1/4 from
% normal mitral annulus...

% find left; right trigones based on distance of 28 mm (14mm on half model)

AC_totalpath = max(AC_path);
IT = 1/4*AC_totalpath;

IT_v = [];

i = 1;

% get vertex corresponding to IT distance
while i < length (AC_path)   
    if AC_path(i,1) < IT       
        IT_v = [IT_v; ann_s(i,:)];                        
    end    
    i=i+1;    
end

RT = IT_v(end,:);
LT = [-RT(1) RT(2) RT(3)];






%% find comm point on new quad mesh
% get quad representation 

cPar.closeLoopOpt=0;
cPar.patchType='quad';
[F1,V1]=polyLoftLinear(ann_s,fe_s,cPar);

comm_pos=1;
tol=1e-30;

while ismembertol(V1(comm_pos,3),ann_comm(1,3),tol)==0
        comm_pos=comm_pos+1;
end

% get starting point for commissural boundary (annular point)
B_comm = V1(comm_pos,:);

i = comm_pos+1;

while abs(V1(i,3)-V1(i-1,3)) < 3
  %  V1(i,3) < 0
        B_comm = [B_comm; V1(i,:)];
        i = i+1;
end      

% commissural point on free edge
fe_comm = V1(i-1,:);


%% get mid leaflet boundaries

% find mid AAC point on quad mesh (greatest z coordinate)
% it will be the first on the list (x = 0)
mid_AL = V1(1,:);

% get AL length boundary
B_midAL = mid_AL;

j = 2;

while V1(j,1) == 0
        B_midAL = [B_midAL; V1(j,:)];
        j = j+1;
end    


% find mid PAC point on quad mesh
% boundary will be the last piece on the list with x = 0

while V1(j,1) ~= 0
    j = j+1;              
end    

B_midPL = [];

for i=j:length(V1)
    B_midPL = [B_midPL; V1(i,:)];
end

mid_PL = B_midPL(1,:);



% split free edge in anterior and posterior parts
fe_post = [];
fe_ant = [];
i=1;
tol=1e-30;

while abs(fe_s(i,1) - fe_comm(1,1)) > tol
fe_ant=[fe_ant; fe_s(i,:)];
i = i+1;
end

fe_ant=[fe_ant; fe_s(i,:)];
i = i+1;

 for k=i:length(fe_s)
        fe_post=[fe_post; fe_s(k,:)];
 end



%figure; scatter3(fe_ant(:,1),fe_ant(:,2),fe_ant(:,3)); hold on;
%scatter3(fe_post(:,1),fe_post(:,2),fe_post(:,3)); 
 
%figure; scatter3(fe_s(:,1),fe_s(:,2),fe_s(:,3)); hold on;...
 %   scatter3(ann_s(:,1),ann_s(:,2),ann_s(:,3));...
  %  scatter3(ann_comm(1),ann_comm(2),ann_comm(3),'filled');...
   % scatter3(fe_comm(1),fe_comm(2),fe_comm(3),'filled');
   
   

   
%% find paracommissural split

% start with free edge point with greatest z
[fe_postz,fe_posmax] = max(fe_post(:,3));
fe_paracom = fe_post(fe_posmax,:); 

% find paracomm point on new quad mesh
comm_pos=1;
tol=1e-30;

while ismembertol(V1(comm_pos,3),fe_paracom(3),tol)==0
        comm_pos=comm_pos+1;
end

% get paracommissural boundary
B_paracom = V1(comm_pos,:);

i = comm_pos-1;


while abs(V1(i,3)-V1(i-1,3)) < 3
B_paracom = [B_paracom; V1(i,:)];
i = i-1;
end

%while ismembertol(V1(i,:),a_post(:),tol)==0
 %       B_paracom = [B_paracom; V1(i,:)];
  %      i = i-1;
%end      

B_paracom = [B_paracom; V1(i,:)];

B_paracom = flipud(B_paracom);

ann_paracom = B_paracom(1,:);



%% split posterior leaflet in PA1 and PA2

% free edge
fe_PA1 = [];
fe_PA2 = [];
i=1;
tol=1e-30;

while abs(fe_post(i,1) - fe_paracom(1,1)) > tol
fe_PA1=[fe_PA1; fe_post(i,:)];
i = i+1;
end


 for k=i:length(fe_post)
        fe_PA2=[fe_PA2; fe_post(k,:)];
 end

 
% posterior annulus
a_PA1 = [];
a_PA2 = [];
i=1;
tol=1e-30;

while abs(a_post(i,1) - ann_paracom(1,1)) > tol
a_PA1=[a_PA1; a_post(i,:)];
i = i+1;
end


 for k=i:length(a_post)
        a_PA2=[a_PA2; a_post(k,:)];
 end
 
 
%% Create output structure for points and boundaries
boundary.a_ant = a_ant ;
boundary.a_post = a_post ;
boundary.a_PA1 = a_PA1 ;
boundary.a_PA2 = a_PA2 ;
boundary.fe_ant = fe_ant ;
boundary.fe_post = fe_post ;
boundary.fe_PA1 = fe_PA1 ;
boundary.fe_PA2 = fe_PA2 ;
boundary.B_midAL = B_midAL ;
boundary.B_midPL = B_midPL ;
boundary.B_comm = B_comm ;
boundary.B_paracom = B_paracom ;

%boundary.B_rad_ant = B_rad_ant ;
%boundary.B_rad_post = B_rad_post ;


point.mid_AL = mid_AL ;
point.mid_PL = mid_PL ;
point.ann_comm = ann_comm ;
point.fe_comm = fe_comm ;
point.ann_paracom = ann_paracom ;
point.fe_paracom = fe_paracom ;
point.RT = RT ;
point.LT = LT ;


%% plot settings
figure;
scatter3(boundary.a_ant(:,1),boundary.a_ant(:,2),boundary.a_ant(:,3),...
    'MarkerEdgeColor',[0 .75 .75],'MarkerFaceColor',[0 .75 .75]); hold on;
scatter3(boundary.a_PA1(:,1),boundary.a_PA1(:,2),boundary.a_PA1(:,3),...
    'MarkerEdgeColor',[1 0 1],'MarkerFaceColor',[1 0 1]); hold on;
scatter3(boundary.a_PA2(:,1),boundary.a_PA2(:,2),boundary.a_PA2(:,3),...
    'MarkerEdgeColor',[1 0 0],'MarkerFaceColor',[1 0 0]); hold on;
scatter3(boundary.B_midAL(:,1),boundary.B_midAL(:,2),boundary.B_midAL(:,3),...
    'MarkerEdgeColor','g','MarkerFaceColor','g'); hold on;
scatter3(boundary.B_midPL(:,1),boundary.B_midPL(:,2),boundary.B_midPL(:,3),...
    'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0 0 0]); hold on;
scatter3(boundary.fe_ant(:,1),boundary.fe_ant(:,2),boundary.fe_ant(:,3),'filled');
scatter3(boundary.fe_PA1(:,1),boundary.fe_PA1(:,2),boundary.fe_PA1(:,3),'filled');
scatter3(boundary.fe_PA2(:,1),boundary.fe_PA2(:,2),boundary.fe_PA2(:,3),'filled');
scatter3(boundary.B_paracom(:,1),boundary.B_paracom(:,2),boundary.B_paracom(:,3),...
    'MarkerEdgeColor','y','MarkerFaceColor','y'); hold on;
scatter3(boundary.B_comm(:,1),boundary.B_comm(:,2),boundary.B_comm(:,3),'filled');

%scatter3(boundary.B_rad_ant(:,1),boundary.B_rad_ant(:,2),boundary.B_rad_ant(:,3),'filled');
%scatter3(boundary.B_rad_post(:,1),boundary.B_rad_post(:,2),boundary.B_rad_post(:,3),'filled');

%scatter3(B_radius(:,1),B_radius(:,2),B_radius(:,3),'filled');

%scatter3(V2(:,1),V2(:,2),V2(:,3));

%scatter3(PMPM(1),PMPM(2),PMPM(3));

xlabel('x axis');
ylabel('y axis');
zlabel('z axis');

ax = gca;
ax.FontSize = 16;

hold off

lgd = legend;
lgd.FontSize = 20;
legend(...
    'Anterior annular circumference',...
    'Posterior annular circumference (lateral scallop)',...
    'Posterior annular circumference (middle scallop)',...
    'Anterior mid-length boundary',...
    'Posterior mid-length boundary',...
    'Anterior free edge',...
    'Posterior free edge (lateral scallop)',...
    'Posterior free edge (middle scallop)',...
    'Cleft boundary',...
    'Commissural boundary');



end

