tic

clear; close all; clc;
warning off;

%% Mitral Valve Model 
% This toolbox generates a geometric model of the mitral valve, including:
% annulus, anterior and posterior leaflets, papillary muscles and chordae
% tendineae. 

%
% 
%   for more information or any queries: 
%   Diana Oliveira, DMC795@student.bham.ac.uk


fprintf('----------------MV generator: MITRAL VALVE MODEL GENERATOR---------------\n\n\n')


%% Dimensions for parameterization

[dimensions] = GUI_import; 



% 0 = no change; 0.5 = max acceptable concavity
concave_parameter = dimensions.concave_parameter;

AP_w = dimensions.AP_w; % mm
AH_w = dimensions.AH_w; % mm

CW_w = dimensions.CW_w;

AL_length_w = dimensions.AL_length_w; % mm
ann_comm_w = dimensions.ann_comm_w; % mm

PL_length_w = dimensions.PL_length_w; % mm
ann_PA1_w = dimensions.ann_PA1_w; %mm
paracom_l_w = dimensions.paracom_l_w; % mm


if strcmpi(dimensions.answer, 'average')
radius = dimensions.radius; % mm
end



% Choosing the model
     
      load('starting_boundaries3.mat');
         
      
      
      %
      
       %   for i=1:length(ann_s)
       %   if ann_s(i,2)<0
     % ann_s(i,2) = 0.75*ann_s(i,2);
     % ann_s(i,3) = 0.95*ann_s(i,3);

      %    end
       %   end
      
      
%
fprintf('-----------------Build geometrical model--------------------\n');


% Parameterize the annulus and leaflets
%
% define annular ring concavity
[ann_s] = define_concavity(ann_s,concave_parameter);

% parameterize AH
[ann_s] = annular_param2(ann_s,AH_w);

% parameterize AP and CW distances
[ann_s] = annular_param1(ann_s,AP_w,CW_w);

%
[PL_endpoint,annPA1_endpoint,paracom_endpoint,AL_endpoint,comm_endpoint] = leaflet_define_boundaries0(PL_length_w,ann_PA1_w,paracom_l_w,AL_length_w,ann_comm_w,ann_s);

% improve free edge height
[fe_s] = create_FE(ann_s,FE_source,AL_endpoint, comm_endpoint, annPA1_endpoint, paracom_endpoint, PL_endpoint);

%
% define boundaries of importance
[boundary,point] = leaflet_define_boundaries1(ann_s,fe_s); 



%
if strcmpi(dimensions.answer, 'average')

% parameterize anterior leaflet
[boundary,point] = AL_parameterize_avg(boundary,point,radius);

% parameterize posterior leaflet
[boundary,point] = PL_parameterize_avg(boundary,point,radius);

ann_s = [boundary.a_ant; boundary.a_PA1; boundary.a_PA2];
fe_s = [boundary.fe_ant; boundary.fe_PA1; boundary.fe_PA2];

else
 % parameterize anterior leaflet
[boundary,point] = AL_parameterize_PS(boundary,point,dimensions);

% parameterize posterior leaflet
[boundary,point] = PL_parameterize_PS(boundary,point,dimensions);

ann_s = [boundary.a_ant; boundary.a_PA1; boundary.a_PA2];
fe_s = [boundary.fe_ant; boundary.fe_PA1; boundary.fe_PA2];

end


%% Papillary muscle definitions

% define papillary muscle coordinates
[ALPM,PMPM] = define_PM(point,AP_w,dimensions);

% define settings for papillary muscle displacement
[answer] = GUI_PMpos();


% define papillary muscle new positions based on previous GUI
if strcmpi(answer, 'symmetric medial') || strcmpi(answer, 'posterior medial')...
        || strcmpi(answer, 'anterior medial')...
        || strcmpi(answer, 'posterior apical') || strcmpi(answer, 'anterior apical')

    [inter_PM_w] = GUI_interPM();
    
    [ALPM,PMPM] = define_PM_displacement1(answer,ALPM,PMPM,inter_PM_w);
     

elseif strcmpi(answer, 'posterior dilation') || strcmpi(answer, 'anterior dilation') || strcmpi(answer, 'total dilation')

    load('LV_altered2.mat');
    
    [w_w,l_w] = GUI_LVdilation();
    
    
[ALPM,PMPM] = define_PM_displacement3D(answer,ALPM,PMPM,LV,w_w,l_w,CW_w,ann_s);

end



% choose model output
[answer,answer_PM,mat] = GUI_output();

   
%% CREATE FILE FOR LS-DYNA SIMULATION
if answer == 0

fprintf('-----------------Create input file for LS-DYNA--------------------\n');
  
%list of mat properties & thicknesses
AL_Ex = mat.AL_Ex; % MPa
AL_Ey = mat.AL_Ey; % MPa
PL_Ex = mat.PL_Ex; % MPa
PL_Ey = mat.PL_Ey; % MPa
AL_T = mat.AL_T; % mm
PL_T = mat.PL_T; % mm

    % mesh the model
[F,V,ann_s,fe_s] = meshing_model1(ann_s,fe_s,ALPM,PMPM);

% develop mesh and chordae parts for input file
[V,fe_s,fe_comm1,fe_comm2,node_list,element_shell,fe_el,fe_comm1_pos,fe_comm2_pos] = leaflet_meshinput(ann_s,fe_s,F,V);

%[node_list,annode_ID,ann_vector,centroid,annular_disp] = other_input1(node_list,AP_w);

[annode_ID,ann_vector,annular_disp2,ann_CW] = other_input1(node_list,ann_s,AH_w);

[ALPM_vector,PMPM_vector,ALPM_mag,PMPM_mag] = other_input2(ALPM,PMPM,point,ann_s,ann_CW);


if answer_PM == 0
    
%% PM unique tip

[node_list,element_beam,ALPM_nodepos,PMPM_nodepos,transition_shell] = chordae_input_split(node_list,element_shell,V,fe_s,fe_comm1,fe_comm2,fe_comm1_pos,fe_comm2_pos,ALPM,PMPM,fe_el,point);

run LSDYNA_input_create.m
%run LSDYNA_input_create2.m

%run LSDYNA_input_create_hyper.m

%run LSDYNA_input_create_hyper_partcomposite.m


%Set main folder and fileName
defaultFolder = fileparts(fileparts(mfilename('fullpath')));
pathName_source=fullfile(defaultFolder,'library');
source=fullfile(pathName_source,'LSDyna_inputfile_MV.k');
pathName_destination=fullfile(defaultFolder,'library','Exported_files');
destination=fullfile(pathName_destination,'LSDyna_inputfile_MV.k');

movefile(source,destination);


else
%% 3D insertion in PM with 3 branches each
%[node_list,element_beam,ALPM_nodepos,PMPM_nodepos,transition_shell,ALPM_marginal_nodepos,PMPM_marginal_nodepos] = chordae_input_3D(ALPM_3D,PMPM_3D,node_list,element_shell,V,fe_s,fe_comm1,fe_comm2,fe_comm1_pos,fe_comm2_pos,ALPM,PMPM,fe_el,point);

[node_list,element_beam,ALPM_nodepos,PMPM_nodepos,transition_shell,ALPM_marginal_nodepos,PMPM_marginal_nodepos] = chordae_input_3D_3b(ALPM_3D,PMPM_3D,node_list,element_shell,V,fe_s,fe_comm1,fe_comm2,fe_comm1_pos,fe_comm2_pos,ALPM,PMPM,fe_el,point);

%[ALPM_vector,PMPM_vector,ALPM_mag,PMPM_mag] = other_input2(ALPM,PMPM,point,centroid,annular_disp);

run LSDYNA_input_create_PM3D.m

%run LSDYNA_input_create_hyper3D.m


%Set main folder and fileName
defaultFolder = fileparts(fileparts(mfilename('fullpath')));
pathName_source=fullfile(defaultFolder,'library');
source=fullfile(pathName_source,'LSDyna_inputfile_MV.k');
pathName_destination=fullfile(defaultFolder,'library','Exported_files');
destination=fullfile(pathName_destination,'LSDyna_inputfile_MV.k');

movefile(source,destination);


end



%% PREPARE OUTPUTS FOR MODEL EXPORT 
elseif answer == 1

[n_sampling] = GUI_output_mesh();
    
model_output(ann_s,fe_s,ALPM,PMPM,ALPM_3D,ALPM_3D,n_sampling);

end


%%
toc