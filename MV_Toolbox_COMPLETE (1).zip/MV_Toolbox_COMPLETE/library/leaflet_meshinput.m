function [V,fe_s,fe_comm1,fe_comm2,node_list,element_shell,fe_el,fe_comm1_pos,fe_comm2_pos] = leaflet_meshinput(ann_s,fe_s,F,V)

%% DEFINE PARTS NEEDED ON MESH
% get vertex for each side (annulus)
AC_path = pathLength(ann_s);
%a_post = [];
a_ant1 = [];
a_ant2 = [];

% use proportions from literature to obtain AAC and PAC
AC = max(AC_path);
AAC_w = 2/5*AC;
AAC_w = 1/2*AAC_w;

i=1;
tol=1e-30;

% get posteromedial commissure point (annulus)
while AC_path(i,:) < AAC_w
   a_ant1=[a_ant1; ann_s(i,:)];
i = i+1;
end

ann_comm1 = ann_s(i-1,:);



%for k=i:length(ann_s)
 %       a_post=[a_post; ann_s(k,:)];
%end

% translate the model to have the commissural point at z coordinate = 0
z_comm = ann_comm1(3);
ann_comm1(3) = ann_comm1(3) - z_comm;
%a_ant(:,3) = a_ant(:,3) - z_comm; 
%a_post(:,3) = a_post(:,3) - z_comm;
ann_s(:,3) = ann_s(:,3) - z_comm;
fe_s(:,3) = fe_s(:,3) - z_comm;

V(:,3) = V(:,3) - z_comm;



% get anterolateral commissural point (annulus)
i=length(ann_s);
tol=1e-30;
AC_path = flipud(AC_path);

while AC_path(i,:) < AAC_w
   a_ant2=[a_ant2; ann_s(i,:)];
i = i-1;
end

ann_comm2 = ann_s(i+1,:);



%% find comm points on new quad mesh

% POSTEROMEDIAL 
comm_pos1=1;
tol=1e-30;

while ismembertol(V(comm_pos1,3),ann_comm1(1,3),tol)==0
        comm_pos1=comm_pos1+1;
end

% get starting point for commissural boundary (annular point)
B_comm1 = V(comm_pos1,:);

i = comm_pos1+1;

while abs(V(i,3)-V(i-1,3)) < 3
  %  V1(i,3) < 0
        B_comm1 = [B_comm1; V(i,:)];
        i = i+1;
end      

% commissural point on free edge
fe_comm1 = V(i-1,:);
fe_comm1_pos = i-1;


% ANTEROLATERAL 
comm_pos2=1;
tol=1e-30;

while ismembertol(V(comm_pos2,3),ann_comm2(1,3),tol)==0
        comm_pos2=comm_pos2+1;
end

% get starting point for commissural boundary (annular point)
B_comm2 = V(comm_pos2,:);

i = comm_pos2+1;

while abs(V(i,3)-V(i-1,3)) < 3
  %  V1(i,3) < 0
        B_comm2 = [B_comm2; V(i,:)];
        i = i+1;
end      

% commissural point on free edge
fe_comm2 = V(i-1,:);
fe_comm2_pos = i-1;



%% SPLIT ANTERIOR/POSTERIOR PARTS - element/vertex matrices

% change element node order for LS-DYNA input
F2 = [];
for i=1:length(F)
    F2 = [F2; F(i,4) F(i,3) F(i,2) F(i,1)];
end

element_list = [];
for i=1:length(F2)
    element_list = [element_list; i 0 F2(i,1) F2(i,2) F2(i,3) F2(i,4)];
end


% create matrix of nodes for LS-Dyna
node_list = [];

for i=1:length(V)
    node_list = [node_list; i V(i,1) V(i,2) V(i,3)];
end


% add part ID based on AL and PL
% AL = part 1
% PL = part 2
% transition = part 7



for i=1:length(element_list)
    
    local_node = node_list(element_list(i,4),2:4);
    
    if ismembertol(local_node,fe_comm1,tol)==0
    element_list(i,2) = 1;
    
    else
        element_list(i,2) = 1;
        break
    end   
end

i = i+1;

for k=i:length(element_list)
    
    local_node = node_list(element_list(k,4),2:4);
    
    if ismembertol(local_node,fe_comm2,tol)==0
    element_list(k,2) = 2;
    
    else
        element_list(k,2) = 2;
        break
    end   
end

k = k+1;

for j = k:length(element_list)
    element_list(j,2) = 1;
end



%%
tol=1e-30;
fe_el = [];

    for j=2:length(V)
         
      if abs(V(j,3)-V(j-1,3)) > 3
  
   fe_el = [fe_el; j-1];
          
      end
                     
    end
    
       fe_el = [fe_el; j];

    
    
%% get parts 6 and 7 (free edge different thickness)

el_list_fepos = [];

for i=1:length(element_list)
    
    for j=1:length(fe_el)

if ismembertol(fe_el(j),element_list(i,4),tol)==1
       
    el_list_fepos = [el_list_fepos; i];
    
end
    end
end
        


% fill all free edge positions with a 6 for part
for i=1:length(el_list_fepos)
    element_list(el_list_fepos,2) = 6;
end


i = 1;
while ismembertol(fe_comm1,V(element_list(i,4),:),tol)==0
i = i+1;
end

% position on element list for posterior commisure
k = i+1;    
  

i = 1;
while ismembertol(fe_comm2,V(element_list(i,4),:),tol)==0
i = i+1;
end

% position on element list for anterior commisure
l = i+1; 

    
    for i = 1:length(el_list_fepos)
        
        for j=k:l
        
        if j == el_list_fepos(i)
    
    element_list(j,2) = 7;
    
        end
        end
    end
 
    
    
   element_shell = element_list;
    
end

