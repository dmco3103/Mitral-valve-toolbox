%% GUI for the MV toolbox
% - Input all dimensions needed to build the model

%clc; clear all; close all;

function [n_sampling] = GUI_output_mesh()

dlg_title = 'MV output mesh';

% 1. select the type of model
prompt = {'Select the number of element divisions wanted (a greater number yields a more refined mesh)'};
num_lines = 1;
defaultans = {'400'};
answer3 = inputdlg(prompt,dlg_title,num_lines,defaultans);

n_sampling = str2num(answer3{1,1});


end 


