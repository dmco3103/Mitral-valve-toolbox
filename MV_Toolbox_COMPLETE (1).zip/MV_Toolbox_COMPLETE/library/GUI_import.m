%% GUI for the MV toolbox
% - Input all dimensions needed to build the model

%clc; clear all; close all;

function [dimensions] = GUI_import

dlg_title = 'MV input: select model type';

% 1. select the type of model
prompt = {'Select the type of model: 0 for average dimensions, 1 for patient-specific measurements'};
num_lines = 1;
defaultans = {'0'};
answer = inputdlg(prompt,dlg_title,num_lines,defaultans);

%% AVERAGE MODEL CREATION
if(str2num(answer{1,1})==0)

dlg_title = 'MV input: insert AP diameter';

prompt = {'AP diameter [mm]'};
    num_lines = 1;
    defaultans = {'25'};
    
    answer2 = inputdlg(prompt,dlg_title,num_lines,defaultans);
    
    AP_w = str2num(answer2{1,1});
  
    % get average dimensions based on AP diameter
    [dimensions] = avg_dim(AP_w);
    
    dimensions.answer = 'average';
    
    
    %
    dlg_title = 'Annular concavity';

prompt = {'Do you wish to include anterior annular concavity? 0 for D-shaped annulus, 0.5 for maximum concavity'};
    num_lines = 1;
    defaultans = {'0'};
    
    answer3 = inputdlg(prompt,dlg_title,num_lines,defaultans);
    
    dimensions.concave_parameter = str2num(answer3{1,1});
       
    

%% PATIENT-SPECIFIC MODEL CREATION 
elseif str2num(answer{1,1})==1 

    dimensions.answer = 'PS_input';
    
    dlg_title = 'MV input: patient-specific dimensions';

    % 3. input wanted dimensions
   
    prompt = {'AP diameter [mm]','CW [mm]',...
        'AH [mm]','AL length [mm]','AL surface area [mm2]',...
        'mid-PL length [mm]','PA1 length [mm]','PL surface area [mm2]',...
        'ALPM_0 [mm]','ALPM_10 [mm]','ALPM_8 [mm]',...
        'PMPM_0 [mm]','PMPM_2 [mm]','PMPM_4 [mm]'};
    num_lines = 1;
    defaultans = {'25','30.9','6','25','350','15.45','7','300',...
        '31.5','27','24','31.5','27','24'};
    
    answer5 = inputdlg(prompt,dlg_title,num_lines,defaultans);
    
    dimensions.AP_w = str2num(answer5{1,1});
    dimensions.CW_w = str2num(answer5{2,1});
    dimensions.AH_w = str2num(answer5{3,1});
    dimensions.AL_length_w = str2num(answer5{4,1});
    dimensions.AL_area = str2num(answer5{5,1});
    dimensions.PL_length_w = str2num(answer5{6,1});
    dimensions.ann_PA1_w = str2num(answer5{7,1});
    dimensions.PL_area = str2num(answer5{8,1});
    dimensions.ann_comm_w = 8;
    dimensions.paracom_l_w = 7;

    
    dimensions.ALPM_0 = str2num(answer5{9,1});
    dimensions.ALPM_10 = str2num(answer5{10,1});
    dimensions.ALPM_8 = str2num(answer5{11,1});
    dimensions.PMPM_0 = str2num(answer5{12,1});
    dimensions.PMPM_2 = str2num(answer5{13,1});
    dimensions.PMPM_4 = str2num(answer5{14,1});

    
    %
    dlg_title = 'Annular concavity';

prompt = {'Do you wish to include anterior annular concavity? 0 for D-shaped annulus, 0.5 for maximum concavity'};
    num_lines = 1;
    defaultans = {'0.1'};
    
    answer6 = inputdlg(prompt,dlg_title,num_lines,defaultans);
    
    dimensions.concave_parameter = str2num(answer6{1,1});
    
    
    
else
     error('Assign the flag for average dimensions (0) or subject-specific dimensions (1)');
end 
    
end


